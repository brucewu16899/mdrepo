import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import service
 

###THANK YOU TO THE PEOPLE THAT ORIGINALY WROTE SOME OF THIS CODE WITHOUT YOU I STILL PROBABLY WOULDNT HAVE A CLUE WHERE TO START###
