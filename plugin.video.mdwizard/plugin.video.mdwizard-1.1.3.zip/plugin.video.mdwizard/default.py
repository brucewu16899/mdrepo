import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
from addon.common.addon import Addon
from addon.common.net import Net
 

###THANK YOU TO THE PEOPLE THAT ORIGINALY WROTE SOME OF THIS CODE WITHOUT YOU I STILL PROBABLY WOULDNT HAVE A CLUE WHERE TO START###

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.mdwizard'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonTitle="MD Wizard" 
net = Net()
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.1.3"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Mucky Ducks Wizard"            
BASEURL = "http://kodimediaportal.ml"
H = 'http://'


exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("NDQgMTY5KCk6CgkzMSgnN2UgMTYxJywnMWQnLDEsMmUrJzdlLjMwJyxlLCcnKQoJMzEoJzEzMiAxNGEnLDFjYSsnLzE5Yy8xNTcuMWEzPzE2Zj0zLjAnLDE5LDJlKydjZi4zMCcsZSwnJykKCTMxKCdlOCAxNmMnLDFjYSwyLDJlKydlOC4zMCcsZSwnJykKCTMxKCcyNScsMWNhLDMsMmUrJzI1LjMwJyxlLCcnKQoJMzEoJzU2IDc4IDJmJywxY2EsNCwyZSsnMmYuMzAnLGUsJycpCiMJMzEoJzEyZSBmMyBkOCcsJ2U4JywxNSwyZSsnYTguMzAnLGUsJycpCgk1MignNjAnLCAnOWQnKQoKNDQgMjUoKToKCTFjOCgnMzYgOGMnLCcxZCcsMTQsMmUrJzI1LjMwJyxlLCcnKQoJMWM4KCczNiA2YicsJzFkJyw2LDJlKycyNS4zMCcsZSwnJykKCTFjOCgnMTY3IGIxJywnMWQnLDEwLDJlKycyNS4zMCcsZSwnMTViIDEyMiAxOWUgMTU5JykKIwkzMSgnMTgwIDE0MiBmMCAxNjAgYTcnLCcxZCcsOSwyZSsnMS4xOWInLGUsJzFhZiAxMWMgZmQnKQoJMWM4KCdhYiAxYjcgMWMxJywnMWQnLDEyLDJlKycyNS4zMCcsZSwnJykKCTFjOCgnYjQgZjYgMzYgZWUuMTc2JmViIDEyYycsJzFkJywxMywyZSsnMjUuMzAnLGUsJzE3YSAxNzEgMTgyIDEyNSAxODIgMTIwIDFjMiAxMWUgMTBhIGVjIDE0NyAxOTcgMTg2IDFhOCAxYzkgMTM3IDhhLmRiJykKCTUyKCc2MCcsICc5ZCcpCgoKNDQgZDYoKToKCTFjOCgnYWIgNTYgMmYnLDFjYSw4LDJlKycyZi4zMCcsZSwnJykKCTFjOCgnYzggMmYnLDFjYSsnLzQxL2M5LjViJyw3LDJlKycyZi4zMCcsZSwnJykKCTFjOCgnYmQgMmYnLDFjYSsnLzQxLzE0Ni41YicsNywyZSsnMmYuMzAnLGUsJycpCgkxYzgoJzkzIDJmJywxY2ErJy80MS9lNi41YicsNywyZSsnMmYuMzAnLGUsJycpCgkxYzgoJ2NiIDJmJywxY2ErJy80MS8xNTMuNWInLDcsMmUrJzJmLjMwJyxlLCcnKQoJMWM4KCdkMCA1MCAxODcnLDFjYSsnLzQxLzEwYy41YicsNywyZSsnMmYuMzAnLGUsJycpCgkxYzgoJ2QwIDUwIDE4OCcsMWNhKycvNDEvMTBiLjViJyw3LDJlKycyZi4zMCcsZSwnJykKCTFjOCgnMzYgMmYnLDFjYSwxMSwyZSsnMmYuMzAnLGUsJycpCgk1MignNjAnLCAnOWQnKQoKNDQgZjIoKToKCTMxKCcxMWIgZjMgZDggMWFjIDE2NCA4ZSBmNScsMWNhKycvNDEvOTIvMTAzLTk3LjEzYScsNSwyZSsnYTguMzAnLGUsJycpCgkxYzgoJzk1IDE1YSAxOWEgNzgnLDFjYSsnLzQxLzkyLzEwNy41YicsMTcsMmUrJ2E4LjMwJyxlLCcnKQoJMWM4KCc5NSAxMTguMWEwIDE0MyAxNTgnLCcxNzg6Ly9lZi4xMjQuMWE0LzEyMy4xOWQnLDE2LDJlKydhOC4zMCcsZSwnJykKCTFjOCgnMTY2IGYzIGZlJywnMWQnLDE4LDJlKydhOC4zMCcsZSwnJykKCQoKCjQ0IDE0YigpOgoJNDYgPSA2YSgxY2ErMWIxKzFhYSkuNjUoJ1wxYmMnLCcnKS42NSgnXDFiNicsJycpCgk1NSA9IGY5LjcxKCcxYT0iKC4rPykiLis/MTc1PSIoLis/KSIuKz8xN2I9IiguKz8pIi4rP2U1PSIoLis/KSIuKz84Nj0iKC4rPykiJykuNzQoNDYpCgljIDFhLDFkLDQyLDQ3LDFjIDE5NSA1NToKCQkJMzEoMWEsMWQsNSw0Miw0NywxYykKCTUyKCc2MCcsICc5ZCcpCgkKCjQ0IDdlKCk6Cgk1YToKCQk0NiA9IDZhKDFkMSsxYmUrMWJiKzFhYSkuNjUoJ1wxYmMnLCcnKS42NSgnXDFiNicsJycpCgkJNTUgPSBmOS43MSgnMWE9IiguKz8pIi4rPzE3NT0iKC4rPykiLis/MTdiPSIoLis/KSIuKz9lNT0iKC4rPykiLis/ODY9IiguKz8pIicpLjc0KDQ2KQoJCWMgMWEsMWQsNDIsNDcsMWMgMTk1IDU1OgoJCQkzMSgxYSwxZCw1LDQyLDQ3LDFjKQoJMmM6IDIzCgk1MignNjAnLCAnZmYnKQoKCjQ0IDEyZigxYSwxZCwxYyk6CgkxYjUgPSAxYi4xZDIoMWNkLjFiNS4xODEoJzZjOi8vNTgvOTcnLCdhMicpKQoJZGMgPSAxMzEuYmEoKQoJZGMuMTNkKCIxNjMgMTY1IDM4IiwiZDcgIiwnJywgJzY0IGY3JykKCWNlPTFjZC4xYjUuMTgxKDFiNSwgMWErJy4xM2EnKQoJNWE6CgkgICAxY2QuNmUoY2UpCgkyYzoKCSAgIDIzCgk4OS4xMTEoMWQsIGNlLCBkYykKCTY4ID0gMWIuMWQyKDFjZC4xYjUuMTgxKCc2YzovLycsJzU4JykpCgkxODkuMTZlKDIpCglkYy4xMzkoMCwiIiwgImUyIDE5NiA2NCBmNyIpCgkyOSAnPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09JwoJMjkgNjgKCTI5ICc9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0nCgkxMTcuMTQ4KGNlLDY4LGRjKQoJMWJhID0gMTMxLjFjZSgpCgkxYmEuNmYoIjcwIDRmIiwgIjY0IGUzIDEzNyAxNmIgYjUgMTBlIDE1MSIsIlsyYiA5MV04MSBiNSBkMSAxNDAgNzAgNGZbLzJiXSIpCgoKCjQ0IDE3ZSgxZCk6Cgk0NiA9IDZhKDFkKQoJNTU9ZjkuNzEoJzwxMTIgMWJmPSIuKz8iPjxhIGEwPSIoLis/KSI+KC4rPyk8L2E+PC8xMTI+JykuNzQoNDYpCgljIDFkLDFhIDE5NSA1NToKCQkxMDYgPSAnMTY4PTExLjAnCgkJMWEgPSAxYS42NSgnJjFhOTsnLCcmJykKCQkxY2IgMTA2IDE5ZiAxOTUgMWQ6CgkJCTMxKCdbMmIgMTcyXSUxY2ZbLzJiXScgJTFhLDFkLDIwLDJlKydjZi4zMCcsZSwnJykKCTU5Ljc1KCBjMD0xMzYoIDEzOC4xMDlbIDEgXSApLCA4ND01OS40YiApCgo0NCAxNWYoMWQpOgoJNDYgPSA2YSgxZCkKCTVhOgoJCTU1PWY5LjcxKCcmODM7MWEmODI7KC4rPykmMTkyOyY4MzsxYSY4Mjs8MTA4IC8+JjgzOzFkJjgyOzxhIGEwPSIoLis/KSIgYWE9Ijc5IiA5Nj0iOGYiPi4rPzwvYT4mODM7MWQmODI7PDEwOCAvPiY4MzsxMDQmODI7PGEgYTA9IiguKz8pIiBhYT0iNzkiIDk2PSI4ZiI+Lis/PC9hPiY4MzsxMDQmODI7PDEwOCAvPiY4Mzs0NyY4Mjs8YSBhMD0iKC4rPykiIGFhPSI3OSIgOTY9IjhmIj4uKz88L2E+JjgzOzQ3JjgyOzwxMDggLz4mODM7MWMmODI7KC4rPykmODM7MWMmODI7JykuNzQoNDYpCgkJYyAxYSwxZCw0Miw0NywxYyAxOTUgNTU6CgkJCTMxKDFhLDFkLDUsNDIsNDcsMWMpCgkyYzogMjMKCTUyKCc2MCcsICdmZicpCgk1OS43NSggYzA9MTM2KCAxMzguMTA5WyAxIF0gKSwgODQ9NTkuNGIgKQoKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwlmMCBhNyY4ZQkgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKNDQgYzUoKToKCTFiLjczKCAnOWEnICkKCTFiLjczKCAnOWYnICkKCTFiYSA9IDEzMS4xY2UoKQoJMWJhLjZmKCI4NyAzOCIsICcnLCcJCQkJCQkJCSBiMSBlMSA6KScsICIJCQkJCQkgIFsyYiBjN104MSBiNSBkMSAxNDAgODcgMzhbLzJiXSIpCgk1MwoJCiM0NCBiNigxZCk6CiMJMjkgJyMjIycrMTc3KycgLSA0OCBmYy4xNzYgIyMjJwojCTFiNSA9IDFiLjFkMigxY2QuMWI1LjE4MSgnNmM6Ly8xMGQnLCcnKSkKIwk2Nj0xY2QuMWI1LjE4MSgxYjUsICcxMGYuZGInKQojCTVhOgojCQkxY2QuNmUoNjYpCiMJCTFiYSA9IDEzMS4xY2UoKQojCQkyOSAnPT09IDg3IDM4IC0gNDgJJyszOSg2NikrJwk9PT0nCiMJCTFiYS42ZigxNzcsICIJICAgNzcgMTAyLmRiIDg4IDY0IGQzIGI1IDEwZSAxNTAiKQojCTJjOgojCQkxYmEgPSAxMzEuMWNlKCkKIwkJMWJhLjZmKDE3NywgIgkgICAxNTYgMTk0IGI1IDc3IikKIwk1MwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCWY0IGYwIGE3JjhlICAjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwkgMzYgZDIJCSMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKNDQgYzYoKToKCTVhOgoJCTFjYiAxY2QuMWI1LjI0KGMyKT09M2Y6CgkJCTFiYSA9IDEzMS4xY2UoKQoJCQkxY2IgMWJhLjIyKCIxYzkgOGQiLCAiWzJiIGM3XVtiXSMjIyMjIyMjIyMxMjEgYjQgZjYjIyMjIyMjIyMjWy9iXVsvMmJdIiwgIjEwNSAxMTQgMTI4IDE3MyA5MCAxNGMgNGUgZGYuZGIiLCAiMTk4IDNkIDE5MCAzZCAzMiAxYjIgMWI4IDEyNj8gMTA1IDFhNyAxYTYgYmUgMTMzIik6CgkJCQljIDFkMCwgMWMzLCAxOGQgMTk1IDFjZC4zNChjMik6CgkJCQkJNWUgPSAwCgkJCQkJNWUgKz0gNDUoMThkKQoJCQkJCTFjYiA1ZSA+IDA6CQkJCQoJCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkJCQkgICAKCQljYSA9IDFjZC4xYjUuMTgxKDE0NSwiOGEuZGIiKQkJCSAgIAoJCTFjZC4xYzYoY2EpCgkJMWJhLjZmKCIxMTYgNzAiLCAiNjQgMTFmIDcwIDFiMiAxMWQgOTAgMTFhIikKCTJjOiAKCQkxYmEgPSAxMzEuMWNlKCkKCQkxYmEuNmYoMTc3LCAiZTcgNjkgOGQgMWJkIGRkIDcwIDRmIDE4ZiBhNiIpCgk1MwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAxM2IgMzYgZDIJIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJICAgMzYgOGMJICAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgo0NCBkNSgxZCk6CgkyOSAnIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCSAgIDQ4IDExMyA4YwkJCSAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMnCgk0YyA9IDFjZC4xYjUuMTgxKDFiLjFkMignNmM6Ly81OCcpLCAnMWM3JykKCTFjYiAxY2QuMWI1LjI0KDRjKT09M2Y6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDRjKToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgNzAgMjcgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCQkKCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJNWE6CgkJCQkJCQkxY2QuMWM2KDFjZC4xYjUuMTgxKDFkMCwgZikpCgkJCQkJCTJjOgoJCQkJCQkJMjMKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJNWE6CgkJCQkJCQkxZi4xZSgxY2QuMWI1LjE4MSgxZDAsIGQpKQoJCQkJCQkyYzoKCQkJCQkJCTIzCgkJCQkJCQoJCQkzNToKCQkJCTIzCgkxY2IgMWIuOTkoJzEyZC4xMTAuYmYnKToKCQk3ZCA9IDFjZC4xYjUuMTgxKCcvYWQvMTU1L2MzL2IzL2NkL2FlL2UwLycsICdkOScpCgkJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoN2QpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCQkxY2IgNWUgPiAwOgoKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWNiIDFiYS4yMigiMWM5IGJmIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEgMTk1ICdkOSciLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCQk3YyA9IDFjZC4xYjUuMTgxKCcvYWQvMTU1L2MzL2IzL2NkL2FlL2UwLycsICc3MicpCgkJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoN2MpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCQkxY2IgNWUgPiAwOgoKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWNiIDFiYS4yMigiMWM5IGJmIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEgMTk1ICc3MiciLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCQkJICAjIDUxIDFiNSAxYjIgMTVlIGY4IDFjNyAxOGQKCQkJCQkJCSAKCgkjIDUxIDFiNSAxYjIgMTg0IDFjMCAxN2MgMWM3IDE4ZAoJNTQgPSAxY2QuMWI1LjE4MSgxYi4xZDIoJzZjOi8vMmQvMWM0LzM3LjQwLmQ0LzFjNycpLCAnJykKCTFjYiAxY2QuMWI1LjI0KDU0KT09M2Y6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDU0KToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgMWEyIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCQkJCQoJCQkJIyA1MSAxYjUgMWIyIDE1NCAxYzcgMThkCgkzYz0gMWNkLjFiNS4xODEoMWIuMWQyKCc2YzovLzJkLzFjNC8zNy40MC4xYWQvMWM3JyksICcnKQoJMWNiIDFjZC4xYjUuMjQoM2MpPT0zZjoJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoM2MpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCSMgMzMgMThkIDRlIDNlIDI4IDFiMiA3ZgoJCQkxY2IgNWUgPiAwOgoJCgkJCQkxYmEgPSAxMzEuMWNlKCkKCQkJCTFjYiAxYmEuMjIoIjFjOSAxNTQgMjcgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCQkKCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJMWNkLjFjNigxY2QuMWI1LjE4MSgxZDAsIGYpKQoJCQkJCWMgZCAxOTUgMWMzOgoJCQkJCQkxZi4xZSgxY2QuMWI1LjE4MSgxZDAsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMwoJCQkJCgkJCQkjIDUxIDFiNSAxYjIgMTNjIGI5IDFjNyAxOGQKCTQzPSAxY2QuMWI1LjE4MSgxYi4xZDIoJzZjOi8vMmQvMWM0LzM3LjQwLjEyYi85NCcpLCAnJykKCTFjYiAxY2QuMWI1LjI0KDQzKT09M2Y6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDQzKToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgMTNjIGI5IDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCQkJCQoJCQkJCgkJCQkjIDUxIDFiNSAxYjIgMTkzIDhiIDFjNyAxOGQKCTNiID0gMWNkLjFiNS4xODEoMWIuMWQyKCc2YzovLzJkLzFjNC8xNGQuMTRlLjEzNC44OScpLCAnJykKCTFjYiAxY2QuMWI1LjI0KDNiKT09M2Y6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDNiKToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgMTkzIDhiIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCQkJCQoJCQkJIyA1MSAxYjUgMWIyIDE0MSAxYzcgMThkCgkxYzUgPSAxY2QuMWI1LjE4MSgxYi4xZDIoJzZjOi8vMmQvMWM0LzM3LjQwLjFhZS8xNDknKSwgJycpCgkxY2IgMWNkLjFiNS4yNCgxYzUpPT0zZjoJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoMWM1KToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgMTQxIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCgkJCQkjIDUxIDFiNSAxYjIgOTggMWM3IDE4ZAoJNmQgPSAxY2QuMWI1LjE4MSgxYi4xZDIoJzZjOi8vMmQvMWM0LzM3LjQwLjk4LzFjNycpLCAnJykKCTFjYiAxY2QuMWI1LjI0KDFjNSk9PTNmOgkKCQljIDFkMCwgMWMzLCAxOGQgMTk1IDFjZC4zNCg2ZCk6CgkJCTVlID0gMAoJCQk1ZSArPSA0NSgxOGQpCgkJCgkJIyAzMyAxOGQgNGUgM2UgMjggMWIyIDdmCgkJCTFjYiA1ZSA+IDA6CgkKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWNiIDFiYS4yMigiMWM5IGVhIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCgkJCQkJIyA1MSAxYjUgMWIyIDExNSAxYzcgMThkCgk2MyA9IDFjZC4xYjUuMTgxKDFiLjFkMignNmM6Ly8yZC8xYzQvMzcuNDAuZTkvMjcnKSwgJycpCgkxY2IgMWNkLjFiNS4yNCgxYzUpPT0zZjoJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoNjMpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCSMgMzMgMThkIDRlIDNlIDI4IDFiMiA3ZgoJCQkxY2IgNWUgPiAwOgoJCgkJCQkxYmEgPSAxMzEuMWNlKCkKCQkJCTFjYiAxYmEuMjIoIjFjOSAxMjcgMjcgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCQkKCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJMWNkLjFjNigxY2QuMWI1LjE4MSgxZDAsIGYpKQoJCQkJCWMgZCAxOTUgMWMzOgoJCQkJCQkxZi4xZSgxY2QuMWI1LjE4MSgxZDAsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMwoKCQkJCQkjIDUxIDFiNSAxYjIgODAgMTYyIDFjNyAxOGQKCTYyID0gMWNkLjFiNS4xODEoMWIuMWQyKCc2YzovLzJkLzFjNC8zNy40MC5mMS8xYzcnKSwgJycpCgkxY2IgMWNkLjFiNS4yNCgxYzUpPT0zZjoJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoNjIpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCSMgMzMgMThkIDRlIDNlIDI4IDFiMiA3ZgoJCQkxY2IgNWUgPiAwOgoJCgkJCQkxYmEgPSAxMzEuMWNlKCkKCQkJCTFjYiAxYmEuMjIoIjFjOSBiMiAxNzAgMjcgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCQkKCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJMWNkLjFjNigxY2QuMWI1LjE4MSgxZDAsIGYpKQoJCQkJCWMgZCAxOTUgMWMzOgoJCQkJCQkxZi4xZSgxY2QuMWI1LjE4MSgxZDAsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMwoKCQkJCQkjIDUxIDFiNSAxYjIgNzYgMWM3IDE4ZAoJNGEgPSAxY2QuMWI1LjE4MSgxYi4xZDIoJzZjOi8vMmQvMWM0LzM3LjQwLjc2LzFjNycpLCAnJykKCTFjYiAxY2QuMWI1LjI0KDFjNSk9PTNmOgkKCQljIDFkMCwgMWMzLCAxOGQgMTk1IDFjZC4zNCg0YSk6CgkJCTVlID0gMAoJCQk1ZSArPSA0NSgxOGQpCgkJCgkJIyAzMyAxOGQgNGUgM2UgMjggMWIyIDdmCgkJCTFjYiA1ZSA+IDA6CgkKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWNiIDFiYS4yMigiMWM5IGJjIDI3IDI2IiwgMzkoNWUpICsgIiAxOGQgMmEiLCAiNjcgM2QgMzIgMWIyIDdmIDNhPyIpOgoJCQkJCgkJCQkJYyBmIDE5NSAxOGQ6CgkJCQkJCTFjZC4xYzYoMWNkLjFiNS4xODEoMWQwLCBmKSkKCQkJCQljIGQgMTk1IDFjMzoKCQkJCQkJMWYuMWUoMWNkLjFiNS4xODEoMWQwLCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjMKCgkJCQkJIyA1MSAxYjUgMWIyIGE1LmNjIDFjNyAxOGQKCTVkID0gMWNkLjFiNS4xODEoMWIuMWQyKCc2YzovLzJkLzFjNC8zNy40MC5hNS5jYy8xYzcnKSwgJycpCgkxY2IgMWNkLjFiNS4yNCgxYzUpPT0zZjoJCgkJYyAxZDAsIDFjMywgMThkIDE5NSAxY2QuMzQoNWQpOgoJCQk1ZSA9IDAKCQkJNWUgKz0gNDUoMThkKQoJCQoJCSMgMzMgMThkIDRlIDNlIDI4IDFiMiA3ZgoJCQkxY2IgNWUgPiAwOgoJCgkJCQkxYmEgPSAxMzEuMWNlKCkKCQkJCTFjYiAxYmEuMjIoIjFjOSBmYiAyNyAyNiIsIDM5KDVlKSArICIgMThkIDJhIiwgIjY3IDNkIDMyIDFiMiA3ZiAzYT8iKToKCQkJCQoJCQkJCWMgZiAxOTUgMThkOgoJCQkJCQkxY2QuMWM2KDFjZC4xYjUuMTgxKDFkMCwgZikpCgkJCQkJYyBkIDE5NSAxYzM6CgkJCQkJCTFmLjFlKDFjZC4xYjUuMTgxKDFkMCwgZCkpCgkJCQkJCQoJCQkzNToKCQkJCTIzCgoJCQkJCSMgNTEgMWI1IDFiMiA4MCAxYzcgMThkCgk2MSA9IDFjZC4xYjUuMTgxKDFiLjFkMignNmM6Ly8yZC8xYzQvMzcuNDAuODAvMTM1JyksICcnKQoJMWNiIDFjZC4xYjUuMjQoMWM1KT09M2Y6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDYxKToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKCQoJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkxY2IgMWJhLjIyKCIxYzkgYjIgMjcgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCQkKCQkJCQljIGYgMTk1IDE4ZDoKCQkJCQkJMWNkLjFjNigxY2QuMWI1LjE4MSgxZDAsIGYpKQoJCQkJCWMgZCAxOTUgMWMzOgoJCQkJCQkxZi4xZSgxY2QuMWI1LjE4MSgxZDAsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMwoKCQkJICAgIyA1MSAxYjUgMWIyIDEwMCAxYzcgMThkCgk0ZCA9IDFjZC4xYjUuMTgxKDFiLjFkMignNmM6Ly81OC8xMDAnKSwgJycpCgkxY2IgMWNkLjFiNS4yNCg0ZCk9PTNmOgkKCQljIDFkMCwgMWMzLCAxOGQgMTk1IDFjZC4zNCg0ZCk6CgkJCTVlID0gMAoJCQk1ZSArPSA0NSgxOGQpCgkgICAKCQkjIDMzIDE4ZCA0ZSAzZSAyOCAxYjIgN2YKCQkJMWNiIDVlID4gMDoKICAgCgkJCQkxYmEgPSAxMzEuMWNlKCkKCQkJCTFjYiAxYmEuMjIoIjFjOSAxN2QgMjYiLCAzOSg1ZSkgKyAiIDE4ZCAyYSIsICI2NyAzZCAzMiAxYjIgN2YgM2E/Iik6CgkJCSAgIAoJCQkJCWMgZiAxOTUgMThkOgoJCQkJCQkxY2QuMWM2KDFjZC4xYjUuMTgxKDFkMCwgZikpCgkJCQkJYyBkIDE5NSAxYzM6CgkJCQkJCTFmLjFlKDFjZC4xYjUuMTgxKDFkMCwgZCkpCgoJCQkJCSMgNTEgMWI1IDFiMiBiMCAxYzcgMThkCgkKCTVmID0gMWIuMWQyKCc2YzovL2JiLzFjNC8zNy40MC5iMCcpCgkxYmEgPSAxMzEuMWNlKCkKCTVhOgoJCTFjYiAxYmEuMjIoIjFjOSAxMjkgMjcgMjYiLCAiNjcgM2QgMzIgMWIyIDdmIDFjNyIpOgoJCQk3YiA9IDFjZC4xYjUuMTgxKDVmLCIxYzcuZGIiKQoJCQkxY2QuMWM2KDdiKQoKCTJjOgoJCTIzCgkKCTFiYSA9IDEzMS4xY2UoKQoJMWJhLjZmKCI4NyAzOCIsICIJCQkJCWZhIDY5IDY0IGQzICAiLCAiCQkJCSAgIFsyYiBjN104MSBiNSBkMSAxNDAgODcgMzhbLzJiXSIpCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIDEzYiAzNiA4YwkgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIDM2IDZiCSAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgkKNDQgYWMoMWQpOgoJMjkgJyMjIycrMTc3KycgLSA0OCA2YiMjIycKCTVjID0gMWIuMWQyKDFjZC4xYjUuMTgxKCc2YzovLzU4Lzk3L2EyJywgJycpKQoJNWE6CQoJCWMgMWQwLCAxYzMsIDE4ZCAxOTUgMWNkLjM0KDVjKToKCQkJNWUgPSAwCgkJCTVlICs9IDQ1KDE4ZCkKCQkJCgkJIyAzMyAxOGQgNGUgM2UgMjggMWIyIDdmCgkJCTFjYiA1ZSA+IDA6CgkKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWNiIDFiYS4yMigiMWM5IDExOSAyNyAyNiIsIDM5KDVlKSArICIgMThkIDJhIiwgIjY3IDNkIDMyIDFiMiA3ZiAzYT8iKToKCQkJCQkJCQoJCQkJCWMgZiAxOTUgMThkOgoJCQkJCQkxY2QuMWM2KDFjZC4xYjUuMTgxKDFkMCwgZikpCgkJCQkJYyBkIDE5NSAxYzM6CgkJCQkJCTFmLjFlKDFjZC4xYjUuMTgxKDFkMCwgZCkpCgkJCQkJMWJhID0gMTMxLjFjZSgpCgkJCQkJMWJhLjZmKDE3NywgIgkgICA2OSA3YSAxNDggMTg1IikKCQkJCTM1OgoJCQkJCQkyMwoJCQkzNToKCQkJCTFiYSA9IDEzMS4xY2UoKQoJCQkJMWJhLjZmKDE3NywgIgkgICAxNTYgN2EgMWIyIDM2IikKCTJjOiAKCQkxYmEgPSAxMzEuMWNlKCkKCQkxYmEuNmYoMTc3LCAiZTcgNjkgN2EgMWJkIGRkIDcwIDRmIDE4ZiBhNiIpCgk1MwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCWY0IDM2IDZiICAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJICAgNDkgMmYJICAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIAoJCjQ0IDE5MSgxZCwxYSk6CgkxYjUgPSAxYi4xZDIoMWNkLjFiNS4xODEoJzZjOi8vNTgvNTcnLCcnKSkKCTY2PTFjZC4xYjUuMTgxKDFiNSwgJzIxLjViJykKCTFiYSA9IDEzMS4xY2UoKQoJZWQ9MWNkLjFiNS4xODEoMWI1LCAnMjEuNWIuZWQnKQoJMWNiIDFjZC4xYjUuMjQoZWQpPT0xNWM6IAoJCTFjYiAxYmEuMjIoIjE4YyAxN2YgOWUiLCAnMThhIGQxIDE0NCAxN2YgMTBhIDllPycsJycsICJbYl1bMmIgMWExXQkgMWIwIDE0ZiAxMzAgMWIzIDE3NCAhISFbL2JdWy8yYl0iKToKCQkJMjkgJyMjIycrMTc3KycgLSA1NiAyZiMjIycKCQkJMWI1ID0gMWIuMWQyKDFjZC4xYjUuMTgxKCc2YzovLzU4LzU3JywnJykpCgkJCTY2PTFjZC4xYjUuMTgxKDFiNSwgJzIxLjViJykKCQkJNWE6CgkJCQkxY2QuNmUoNjYpCgkJCQkyOSAnPT09IDg3IDM4IC0gOWMJJyszOSg2NikrJwk9PT0nCgkJCTJjOgoJCQkJMjMKCQkJNDY9MTNlLmEzKDFkKS5hZgoJCQlhID0gYzEoNjYsIjFiNCIpIAoJCQlhLmU0KDQ2KQoJCQlhLmRlKCkKCQkJMjkgJz09PSA4NyAzOCAtIGI3IDE1MgknKzM5KDY2KSsnCT09PScKCQkJMWJhID0gMTMxLjFjZSgpCgkJCTFiYS42ZigxNzcsICIJICAgMTAxIGM0IDEzZiA0OSAyZiIpCgkzNTogCgkJMjkgJyMjIycrMTc3KycgLSA1NiAyZiMjIycKCQkxYjUgPSAxYi4xZDIoMWNkLjFiNS4xODEoJzZjOi8vNTgvNTcnLCcnKSkKCQk2Nj0xY2QuMWI1LjE4MSgxYjUsICcyMS41YicpCgkJNWE6CgkJCTFjZC42ZSg2NikKCQkJMjkgJz09PSA4NyAzOCAtIDljCScrMzkoNjYpKycJPT09JwoJCTJjOgoJCQkyMwoJCTQ2PTEzZS5hMygxZCkuYWYKCQlhID0gYzEoNjYsIjFiNCIpIAoJCWEuZTQoNDYpCgkJYS5kZSgpCgkJMjkgJz09PSA4NyAzOCAtIGI3IDE1MgknKzM5KDY2KSsnCT09PScKCQkxYmEgPSAxMzEuMWNlKCkKCQkxYmEuNmYoMTc3LCAiCSAgIDEwMSBjNCAxM2YgNDkgMmYiKQkKCTUzCgo0NCBhNCgxZCwxYSk6CgkyOSAnIyMjJysxNzcrJyAtIGFiIGI4IDJmIyMjJwoJMWI1ID0gMWIuMWQyKDFjZC4xYjUuMTgxKCc2YzovLzU4LzU3JywnJykpCgk2Nj0xY2QuMWI1LjE4MSgxYjUsICcyMS41YicpCgk1YToKCQlhPWMxKDY2KS4xNzkoKQoJCTFjYiAnMThlJyAxOTUgYToKCQkJMWE9J2JkJwoJCTg1ICcxNmEnIDE5NSBhOgoJCQkxYT0nY2InCgkJODUgJ2M5JyAxOTUgYToKCQkJMWE9J2M4JwoJCTg1ICcxMGMnIDE5NSBhOgoJCQkxYT0nMWE1IGQwIDUwJwoJCTg1ICcxMGInIDE5NSBhOgoJCQkxYT0nMWFiIGQwIDUwJwoJCTg1ICdlNicgMTk1IGE6CgkJCTFhPSc5MycKCTJjOgoJCTFhPSIxY2MgNTYiCgkxYmEgPSAxMzEuMWNlKCkKCTFiYS42ZigxNzcsIlsyYiA5MV0xNGYgMTgzWy8yYl0gIisgMWErIlsyYiA5MV0gMmYgNzggMTZkWy8yYl0iKQoJNTMKCjQ0IDliKDFkKToKCTI5ICcjIyMnKzE3NysnIC0gNDggYjggMmYjIyMnCgkxYjUgPSAxYi4xZDIoMWNkLjFiNS4xODEoJzZjOi8vNTgvNTcnLCcnKSkKCTY2PTFjZC4xYjUuMTgxKDFiNSwgJzIxLjViJykKCTVhOgoJCTFjZC42ZSg2NikKCQkxYmEgPSAxMzEuMWNlKCkKCQkyOSAnPT09IDg3IDM4IC0gNDgJJyszOSg2NikrJwk9PT0nCgkJMWJhLjZmKDE3NywgIgkgICA3NyA0OSBhMSA4OCIpCgkyYzoKCQkxYmEgPSAxMzEuMWNlKCkKCQkxYmEuNmYoMTc3LCAiCSAgIDE1NiA0OSBhMSBiNSA3NyIpCgk1MwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSBmNCA0OSAyZgkgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCjFiYiA9ICcuYTkuMWI5JwoxYWEgPSAnLzQxLjE5OScKMWJlID0gMTVkLmRhKCcxOGInKQoxYjEgPSAnLzEyYSc=")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|8|9|a|B|for|d|FANART|f|10|11|12|13|14|15|16|17|18|19|name|xbmc|description|url|rmtree|shutil|20|advancedsettings|yesno|pass|exists|MAINTENANCE|Files|Cache|option|print|found|COLOR|except|profile|ART|XML|png|addDir|want|Count|walk|else|DELETE|plugin|Wizard|str|them|downloader_cache_path|channel4_cache_path|you|give|True|video|wizard|iconimage|iplayer_cache_path|def|len|link|fanart|DELETING|Advanced|supercartoons_cache_path|SORT_METHOD_VIDEO_TITLE|xbmc_cache_path|temp_cache_path|and|mediaportal|RECOMMENDED|Set|setView|return|wtf_cache_path|match|ADVANCED|userdata|home|xbmcplugin|try|xml|packages_cache_path|tvonline_cache_path|file_count|genesis_cache_path|movies|youtube_cache_path|ytmusic_cache_path|phoenix_cache_path|Please|replace|advance|Do|addonfolder|Deleting|OPEN_URL|PACKAGES|special|m4me_cache_path|remove|ok|KODI|compile|LocalAndRental|executebuiltin|findall|addSortMethod|supercartoons|Remove|SETTINGS|bbc_link|Packages|genesiscache|atv2_cache_b|atv2_cache_a|PREMIUM|delete|youtube|Brought|gt|lt|sortMethod|elif|escription|MD|Sucessfull|downloader|Textures13|Downloader|CACHE|Thumbnails|ADDONS|_blank|thumbnail|yellow|customftv|MIKEY1234|iplayer_http_cache|RENEGADES|target|addons|movies4me|getCondVisibility|UpdateLocalAddons|DELETEADVANCEDXML|REMOVING|MAIN|Original|UpdateAddonRepos|href|Settings|packages|http_GET|CHECKADVANCEDXML|tvonline|facebook|REPOS|ftv|kodimediaportal|class|CHECK|DELETEPACKAGES|private|AppleTV|content|genesis|REFRESH|YouTube|Library|ANDROID|To|FIXREPOSADDONS|WRITING|ADVANCE|iPlayer|DialogProgress|masterprofile|SuperCartoons|0CACHE|Be|ATV2|handle|open|TNPATH|mobile|Adding|UPDATEREPO|DELETETHUMBS|gold|MUCKYS|muckys|text13|TUXENS|cc|Caches|lib|shared|P2P|You|THUMBS|Reboot|whatthefurk|DELETECACHE|ADVANCEDXML|Downloading|GUIDE|Other|getSetting|db|dp|visit|close|textures13|Video|SUCCESSFUL|Extracting|Disconnect|write|anart|mikey|Error|URL|phstreams|Movies4me|THUBMNAIL|Thumnails|bak|TEXTURE13|renegades|FIX|spotitube|CUSTOMFTV|FTV|End|REQUIRED|ONLY|Wait|Archives|re|Finished|TVonline|ADDONS16|Database|DATABASE|INFO|temp|Done|Addona16|ftvguide|icon|This|nono|settings|br|argv|Your|p2p2|p2p1|database|Take|addons16|platform|download|span|STANDARD|feature|phoenix|Restart|extract|ADDONS2|Package|library|INSTALL|Corrupt|rebuild|Deletes|restart|Windows|WARNING|Refresh|addons2|x10host|Android|proceed|Phoenix|deletes|Genesis|freefix|iplayer|FOLDER|system|CUSTOM|WIZARD|CANNOT|xbmcgui|SHARED|Undone|simple|kodion|int|The|sys|update|zip|END|BBC|create|net|new|By|ITV|RESORT|UPDATE|Backed|DBPATH|0cache|Folder|all|Images|BUILDS|URLFIX|folder|script|module|YOU|Affect|Effect|NEW|tuxens|4oD|var|No|index|DAILY|Repos|FIRST|Force|False|ADDON|Cydia|USERL|EMPTY|BUILD|music|Mucky|OTHER|Ducks|RESET|FORCE|topic|INDEX|tuxen|Power|FIXES|SETUP|sleep|board|Music|Works|white|your|BACK|rl|DB|AddonTitle|http|read|Only|mg|Furk|Temp|USER|Up|LAST|join|On|HAVE|What|done|Does|XML1|XML2|time|Have|User|Back|files|zero|on|sure|AXML|quot|Simple|File|in|Zip|But|Are|txt|RUN|jpg|smf|ini|All|not|INI|red|WTF|php|com|1st|NOT|Can|Not|amp|T|2nd|AND|4od|itv|Fix|AS|F|to|GO|w|path|r|MY|do|ml|dialog|N|n|please|U|id|th|IP|It|dirs|addon_data|itv_cache_path|unlink|cache|addDir2|Delete|BASEURL|if|NO|os|Dialog|s|root|H|translatePath".split("|")))

################################
###        CHECK IP          ###
################################
#Thanks to metalkettle for his work on the original IP checker addon        

def IPCHECK(url='http://www.iplocation.net/',inc=1):
    match=re.compile("<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>").findall(net.http_GET(url).content)
    for ip, region, country, isp in match:
        if inc <2: dialog=xbmcgui.Dialog(); dialog.ok('Check My IP',"[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % ip, '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % country, '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % isp)
        inc=inc+1

#################################
###      END CHECK IP         ###
#################################

#################################
###       CUSTOM FTV          ###
#################################

def CUSTOMINI(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                                    Install Latest .ini File'):
        print '###'+AddonTitle+' - CUSTOM FTV INI###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'addons2.ini')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New .ini File")  
    return

def CUSTOMSET(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                               Install Custom Settings'):
        print '###'+AddonTitle+' - CUSTOM FTV SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New Settings")  
    return


def DELETEFTVDB():
    try:
        ftvpath = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        if os.path.exists(ftvpath)==True:
            dialog = xbmcgui.Dialog()
            if dialog.yesno("MD WIzard", "                               Delete FTV Guide Database"):
                ftvsource = os.path.join(ftvpath,"source.db")               
                os.unlink(ftvsource)               
        dialog.ok("MD Wizard", "                                     FTV Database Reset")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "               Error Deleting Database No Database To Delete")
    return

#################################
###      END CUSTOM FTV       ###
#################################
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,description,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    #if addon.get_setting('auto-view') == 'true':

    #    print addon.get_setting(viewType)
    #    if addon.get_setting(viewType) == 'Info':
    #        VT = '515'
    #    elif addon.get_setting(viewType) == 'Wall':
    #        VT = '501'
    #    elif viewType == 'default-view':
    #        VT = addon.get_setting(viewType)

    #    print viewType
    #    print VT
        
    #    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        PREMIUM()

elif mode==2:
        URLFIX()

elif mode==3:
        MAINTENANCE()

elif mode==4:
        ADVANCEDXML()

elif mode==5:
        WIZARD(name,url,description)

elif mode==6:
        DELETEPACKAGES(url)

elif mode==7:
        AXML(url,name)

elif mode==8:
        CHECKADVANCEDXML(url,name)

elif mode==9:
        FIXREPOSADDONS(url)

elif mode==10:
        UPDATEREPO()

elif mode==11:
        DELETEADVANCEDXML(url)

elif mode==12:
        IPCHECK()

elif mode==13:
        DELETETHUMBS()

elif mode==14:
        DELETECACHE(url)

elif mode==15:
        CUSTOMFTV()

elif mode==16:
        CUSTOMINI(url,name)

elif mode==17:
        CUSTOMSET(url,name)

elif mode==18:
        DELETEFTVDB()

elif mode==19:
        USER(url)

elif mode==20:
        USERL(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
