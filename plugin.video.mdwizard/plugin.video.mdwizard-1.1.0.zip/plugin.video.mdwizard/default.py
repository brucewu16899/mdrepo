import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
from addon.common.addon import Addon
from addon.common.net import Net
 

###THANK YOU TO THE PEOPLE THAT ORIGINALY WROTE SOME OF THIS CODE WITHOUT YOU I STILL PROBABLY WOULDNT HAVE A CLUE WHERE TO START###

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.mdwizard'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonTitle="MD Wizard" 
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "1.0.8"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Mucky Ducks Wizard"            
BASEURL = "http://kodimediaportal.ml"
H = 'http://'

def INDEX():
    addDir('PREMIUM BUILD',BASEURL,1,ART+'PREMIUM.png',FANART,'')
    addDir('URL FIXES',BASEURL,2,ART+'URL.png',FANART,'')
    addDir('MAINTENANCE',BASEURL,3,ART+'MAINTENANCE.png',FANART,'')
    addDir('ADVANCED SETTINGS XML',BASEURL,4,ART+'XML.png',FANART,'')
#    addDir('CUSTOM FTV GUIDE','URL',15,ART+'ftv.png',FANART,'')
    setView('movies', 'MAIN')

def MAINTENANCE():
    addDir2('DELETE CACHE','url',14,ART+'MAINTENANCE.png',FANART,'')
    addDir2('DELETE PACKAGES','url',6,ART+'MAINTENANCE.png',FANART,'')
    addDir2('FORCE REFRESH','url',10,ART+'MAINTENANCE.png',FANART,'Force Refresh All Repos')
#    addDir('LAST RESORT FIX EMPTY REPOS','url',9,ART+'1.jpg',FANART,'Fix Corrupt Database')
    addDir2('CHECK MY IP','url',12,ART+'MAINTENANCE.png',FANART,'')
    addDir2('ANDROID ONLY DELETE TEXTURE13.DB&THUBMNAIL FOLDER','url',13,ART+'MAINTENANCE.png',FANART,'Only Works On Android On Windows It Deletes Your Thumnails Folder But Does Not Delete The Textures13.db')
    setView('movies', 'MAIN')


def ADVANCEDXML():
    addDir2('CHECK ADVANCED XML',BASEURL,8,ART+'XML.png',FANART,'')
    addDir2('MUCKYS XML',BASEURL+'/wizard/muckys.xml',7,ART+'XML.png',FANART,'')
    addDir2('0CACHE XML',BASEURL+'/wizard/0cache.xml',7,ART+'XML.png',FANART,'')
    addDir2('MIKEY1234 XML',BASEURL+'/wizard/mikey.xml',7,ART+'XML.png',FANART,'')
    addDir2('TUXENS XML',BASEURL+'/wizard/tuxens.xml',7,ART+'XML.png',FANART,'')
    addDir2('P2P RECOMMENDED XML1',BASEURL+'/wizard/p2p1.xml',7,ART+'XML.png',FANART,'')
    addDir2('P2P RECOMMENDED XML2',BASEURL+'/wizard/p2p2.xml',7,ART+'XML.png',FANART,'')
    addDir2('DELETE XML',BASEURL,11,ART+'XML.png',FANART,'')
    setView('movies', 'MAIN')

def CUSTOMFTV():
    addDir('INSTALL FTV GUIDE AND OTHER ADDONS REQUIRED',BASEURL+'/wizard/customftv/ftvguide-addons.zip',5,ART+'ftv.png',FANART,'')
    addDir2('RENEGADES FIRST RUN SETTINGS',BASEURL+'/wizard/customftv/settings.xml',17,ART+'ftv.png',FANART,'')
    addDir2('RENEGADES ADDONS2.INI UPDATE DAILY','http://renegades.x10host.com/addons2.ini',16,ART+'ftv.png',FANART,'')
    addDir2('RESET FTV DATABASE','url',18,ART+'ftv.png',FANART,'')
    

exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("NWEgZmUoMzgpOgoJNGIgPSA2ZSgxNGMpLjQ2KCdcMTNjJywnJykuNDYoJ1wxM2UnLCcnKQoJNjIgPSBmNC43NSgnMjI9IiguKz8pIi4rP2YzPSIoLis/KSIuKz8xMDc9IiguKz8pIi4rPzkwPSIoLis/KSIuKz82MD0iKC4rPykiJykuNzMoNGIpCgk1YyAyMiwzOCwzYSw1MSwyNiAxMSA2MjoKCQkJN2MoMjIsMzgsNSwzYSw1MSwyNikKCTkzKCdhYycsICcxMjEnKQoJCgkKNWEgZTIoMzgpOgoJNGIgPSA2ZSgxNTQrMTQ5K2IpLjQ2KCdcMTNjJywnJykuNDYoJ1wxM2UnLCcnKQoJNjIgPSBmNC43NSgnMjI9IiguKz8pIi4rP2YzPSIoLis/KSIuKz8xMDc9IiguKz8pIi4rPzkwPSIoLis/KSIuKz82MD0iKC4rPykiJykuNzMoNGIpCgk1YyAyMiwzOCwzYSw1MSwyNiAxMSA2MjoKCQk3YygyMiwzOCw1LDNhLDUxLDI2KQoJNTI6CgkJNGIgPSA2ZSgxNGIrMTQ5KzE1MSkuNDYoJ1wxM2MnLCcnKS40NignXDEzZScsJycpCgkJNjIgPSBmNC43NSgnMjI9IiguKz8pIi4rP2YzPSIoLis/KSIuKz8xMDc9IiguKz8pIi4rPzkwPSIoLis/KSIuKz82MD0iKC4rPykiJykuNzMoNGIpCgkJNWMgMjIsMzgsM2EsNTEsMjYgMTEgNjI6CgkJCTdjKDIyLDM4LDUsM2EsNTEsMjYpCgkyODogMWYKCTkzKCdhYycsICcxMzEnKQoKCjVhIGVlKDIyLDM4LDI2KToKCTE1MyA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vNGEvYTknLCc4YicpKQoJYmEgPSA3LjkyKCkKCWJhLmVmKCIxMWIgMTFlIDJmIiwiYjMgIiwnJywgJzVkIGQ0JykKCWFmPTYuMTUzLjEzYigxNTMsIDIyKycuMTQzJykKCTUyOgoJICAgNi41ZShhZikKCTI4OgoJICAgMWYKCTc5LmQ5KDM4LCBhZiwgYmEpCgk1OSA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vJywnNGEnKSkKCTEzNS4xMWEoMikKCWJhLmVjKDAsIiIsICJiNiAxNDYgNWQgZDQiKQoJMjMgJz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PScKCTIzIDU5CgkyMyAnPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09JwoJZTcuMTBjKGFmLDU5LGJhKQoJMyA9IDcuOSgpCgkzLjVmKCI2MyA0NCIsICI1ZCBiZiAxM2QgMTE5IDllIGNmIDEwMCIsIlsyYSA4MV03MiA5ZSBhZSAxMTMgNjMgNDRbLzJhXSIpCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJZjEgYzEmYWIJICAjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKCjVhIGJjKCk6CgkxNy42NSggJzgzJyApCgkxNy42NSggJzhkJyApCgkzID0gNy45KCkKCTMuNWYoIjdhIDJmIiwgJycsJwkJCQkJCQkJIGRmIGMyIDopJywgIgkJCQkJCSAgWzJhIGFhXTcyIDllIGFlIDExMyA3YSAyZlsvMmFdIikKCTQ1CgkKIzVhIDljKDM4KToKIwkyMyAnIyMjJytmNSsnIC0gM2QgZGEuMTUyICMjIycKIwkxNTMgPSAxNy40KDYuMTUzLjEzYignYzovL2Q2JywnJykpCiMJZT02LjE1My4xM2IoMTUzLCAnZDcuZGInKQojCTUyOgojCQk2LjVlKGUpCiMJCTMgPSA3LjkoKQojCQkyMyAnPT09IDdhIDJmIC0gM2QJJysyZChlKSsnCT09PScKIwkJMy41ZihmNSwgIgkgICA2OSBjZC5kYiA3NiA1ZCAxMTIgOWUgY2YgMTBiIikKIwkyODoKIwkJMyA9IDcuOSgpCiMJCTMuNWYoZjUsICIJICAgMTA5IDEzNCA5ZSA2OSIpCiMJNDUKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwljOSBmMSBjMSZhYiAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIDQ3IGE2CQkjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKCjVhIGEzKCk6Cgk1MjoKCQkxNiA2LjE1My4xZChhNCk9PTM1OgoJCQkzID0gNy45KCkKCQkJMTYgMy4xYygiMTUgN2IiLCAiWzJhIGFhXVtiXSMjIyMjIyMjIyNiOCBlMSAxMzIjIyMjIyMjIyMjWy9iXVsvMmFdIiwgImQwIGRlIGU1IDEyMyA4MCBmNyA0MyBiNy5kYiIsICIxMzggMzMgMTI1IDMzIDI3IDE4IDE0YSBlND8gZDAgMTM5IDE0MSBiZSAxMTEiKToKCQkJCTVjIDgsIDU2LCAxIDExIDYuMmMoYTQpOgoJCQkJCTU1ID0gMAoJCQkJCTU1ICs9IDNjKDEpCgkJCQkJMTYgNTUgPiAwOgkJCQkKCQkJCQkJNWMgZiAxMSAxOgoJCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCQkJICAgCgkJYjIgPSA2LjE1My4xM2IoMTA1LCJiYi5kYiIpCQkJICAgCgkJNi4xNChiMikKCQkzLjVmKCJlMyA2MyIsICI1ZCBkYyA2MyAxOCBlOSA4MCBlMCIpCgkyODogCgkJMyA9IDcuOSgpCgkJMy41ZihmNSwgIjE0ZCA1YiA3YiBhNSBiZCA2MyA0NCAxMmIgODYiKQoJNDUKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwkgMTBhIDQ3IGE2CSMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAgIDQ3IDhlCSAgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKNWEgYjUoMzgpOgoJMjMgJyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwkgICAzZCBkNSA4ZQkJCSAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMnCgk0MSA9IDYuMTUzLjEzYigxNy40KCdjOi8vNGEnKSwgJzEzJykKCTE2IDYuMTUzLjFkKDQxKT09MzU6CQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoNDEpOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCQkKCQkjIDI5IDEgNDMgMzQgMjEgMTggYTAKCQkJMTYgNTUgPiAwOgoJCgkJCQkzID0gNy45KCkKCQkJCTE2IDMuMWMoIjE1IDYzIDFlIDIwIiwgMmQoNTUpICsgIiAxIDI0IiwgIjU4IDMzIDI3IDE4IGEwIDMwPyIpOgoJCQkJCgkJCQkJNWMgZiAxMSAxOgoJCQkJCQk1MjoKCQkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCQkyODoKCQkJCQkJCTFmCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJNTI6CgkJCQkJCQkxOS4xYSg2LjE1My4xM2IoOCwgZCkpCgkJCQkJCTI4OgoJCQkJCQkJMWYKCQkJCQkJCgkJCTJiOgoJCQkJMWYKCTE2IDE3LjgyKCcxMTAuY2IuYTInKToKCQk2YSA9IDYuMTUzLjEzYignLzk1L2VkL2IxLzlhL2E3LzlkL2MzLycsICdiOScpCgkJCgkJNWMgOCwgNTYsIDEgMTEgNi4yYyg2YSk6CgkJCTU1ID0gMAoJCQk1NSArPSAzYygxKQoJCQoJCQkxNiA1NSA+IDA6CgoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSBhMiAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCAxMSAnYjknIiwgIjU4IDMzIDI3IDE4IGEwIDMwPyIpOgoJCQkJCgkJCQkJNWMgZiAxMSAxOgoJCQkJCQk2LjE0KDYuMTUzLjEzYig4LCBmKSkKCQkJCQk1YyBkIDExIDU2OgoJCQkJCQkxOS4xYSg2LjE1My4xM2IoOCwgZCkpCgkJCQkJCQoJCQkyYjoKCQkJCTFmCgkJNmIgPSA2LjE1My4xM2IoJy85NS9lZC9iMS85YS9hNy85ZC9jMy8nLCAnNjQnKQoJCQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoNmIpOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCQkKCQkJMTYgNTUgPiAwOgoKCQkJCTMgPSA3LjkoKQoJCQkJMTYgMy4xYygiMTUgYTIgMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQgMTEgJzY0JyIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoJCQkgICMgNDggMTUzIDE4IDExYyAxMmYgMTMgMQoJCQkJCQkJIAoKCSMgNDggMTUzIDE4IDEyNyAxNDggMTIwIDEzIDEKCTQ5ID0gNi4xNTMuMTNiKDE3LjQoJ2M6Ly8yNS8xMi8yZS4zNy5iNC8xMycpLCAnJykKCTE2IDYuMTUzLjFkKDQ5KT09MzU6CQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoNDkpOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCQkKCQkjIDI5IDEgNDMgMzQgMjEgMTggYTAKCQkJMTYgNTUgPiAwOgoJCgkJCQkzID0gNy45KCkKCQkJCTE2IDMuMWMoIjE1IDE0NCAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoJCQkJCgkJCQkjIDQ4IDE1MyAxOCBmOCAxMyAxCgkzMj0gNi4xNTMuMTNiKDE3LjQoJ2M6Ly8yNS8xMi8yZS4zNy4xNDUvMTMnKSwgJycpCgkxNiA2LjE1My4xZCgzMik9PTM1OgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDMyKToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCgkJIyAyOSAxIDQzIDM0IDIxIDE4IGEwCgkJCTE2IDU1ID4gMDoKCQoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSBmOCAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoJCQkJCgkJCQkjIDQ4IDE1MyAxOCAxMGQgOTcgMTMgMQoJMzk9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvMmUuMzcuZTgvN2UnKSwgJycpCgkxNiA2LjE1My4xZCgzOSk9PTM1OgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDM5KToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCgkJIyAyOSAxIDQzIDM0IDIxIDE4IGEwCgkJCTE2IDU1ID4gMDoKCQoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSAxMGQgOTcgMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCQkKCQkJCQk1YyBmIDExIDE6CgkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCTVjIGQgMTEgNTY6CgkJCQkJCTE5LjFhKDYuMTUzLjEzYig4LCBkKSkKCQkJCQkJCgkJCTJiOgoJCQkJMWYKCQkJCQoJCQkJCgkJCQkjIDQ4IDE1MyAxOCBhOCA3OCAxMyAxCgkzMSA9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvZjIuZmYuZjYuNzknKSwgJycpCgkxNiA2LjE1My4xZCgzMSk9PTM1OgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDMxKToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCgkJIyAyOSAxIDQzIDM0IDIxIDE4IGEwCgkJCTE2IDU1ID4gMDoKCQoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSBhOCA3OCAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoJCQkJCgkJCQkjIDQ4IDE1MyAxOCBmYSAxMyAxCgkxMCA9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvMmUuMzcuMTNmLzEwMicpLCAnJykKCTE2IDYuMTUzLjFkKDEwKT09MzU6CQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoMTApOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCQkKCQkjIDI5IDEgNDMgMzQgMjEgMTggYTAKCQkJMTYgNTUgPiAwOgoJCgkJCQkzID0gNy45KCkKCQkJCTE2IDMuMWMoIjE1IGZhIDFlIDIwIiwgMmQoNTUpICsgIiAxIDI0IiwgIjU4IDMzIDI3IDE4IGEwIDMwPyIpOgoJCQkJCgkJCQkJNWMgZiAxMSAxOgoJCQkJCQk2LjE0KDYuMTUzLjEzYig4LCBmKSkKCQkJCQk1YyBkIDExIDU2OgoJCQkJCQkxOS4xYSg2LjE1My4xM2IoOCwgZCkpCgkJCQkJCQoJCQkyYjoKCQkJCTFmCgoJCQkJIyA0OCAxNTMgMTggN2YgMTMgMQoJNjEgPSA2LjE1My4xM2IoMTcuNCgnYzovLzI1LzEyLzJlLjM3LjdmLzEzJyksICcnKQoJMTYgNi4xNTMuMWQoMTApPT0zNToJCgkJNWMgOCwgNTYsIDEgMTEgNi4yYyg2MSk6CgkJCTU1ID0gMAoJCQk1NSArPSAzYygxKQoJCQoJCSMgMjkgMSA0MyAzNCAyMSAxOCBhMAoJCQkxNiA1NSA+IDA6CgkKCQkJCTMgPSA3LjkoKQoJCQkJMTYgMy4xYygiMTUgY2EgMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCQkKCQkJCQk1YyBmIDExIDE6CgkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCTVjIGQgMTEgNTY6CgkJCQkJCTE5LjFhKDYuMTUzLjEzYig4LCBkKSkKCQkJCQkJCgkJCTJiOgoJCQkJMWYKCgkJCQkJIyA0OCAxNTMgMTggZWEgMTMgMQoJNTMgPSA2LjE1My4xM2IoMTcuNCgnYzovLzI1LzEyLzJlLjM3LmM3LzFlJyksICcnKQoJMTYgNi4xNTMuMWQoMTApPT0zNToJCgkJNWMgOCwgNTYsIDEgMTEgNi4yYyg1Myk6CgkJCTU1ID0gMAoJCQk1NSArPSAzYygxKQoJCQoJCSMgMjkgMSA0MyAzNCAyMSAxOCBhMAoJCQkxNiA1NSA+IDA6CgkKCQkJCTMgPSA3LjkoKQoJCQkJMTYgMy4xYygiMTUgZTYgMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCQkKCQkJCQk1YyBmIDExIDE6CgkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCTVjIGQgMTEgNTY6CgkJCQkJCTE5LjFhKDYuMTUzLjEzYig4LCBkKSkKCQkJCQkJCgkJCTJiOgoJCQkJMWYKCgkJCQkJIyA0OCAxNTMgMTggNzQgMTE1IDEzIDEKCTU0ID0gNi4xNTMuMTNiKDE3LjQoJ2M6Ly8yNS8xMi8yZS4zNy5jNS8xMycpLCAnJykKCTE2IDYuMTUzLjFkKDEwKT09MzU6CQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoNTQpOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCQkKCQkjIDI5IDEgNDMgMzQgMjEgMTggYTAKCQkJMTYgNTUgPiAwOgoJCgkJCQkzID0gNy45KCkKCQkJCTE2IDMuMWMoIjE1IDk4IDExNiAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoKCQkJCQkjIDQ4IDE1MyAxOCA2NyAxMyAxCgkzZiA9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvMmUuMzcuNjcvMTMnKSwgJycpCgkxNiA2LjE1My4xZCgxMCk9PTM1OgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDNmKToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCgkJIyAyOSAxIDQzIDM0IDIxIDE4IGEwCgkJCTE2IDU1ID4gMDoKCQoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSBhMSAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoKCQkJCQkjIDQ4IDE1MyAxOCA4OS5jYyAxMyAxCgk0ZSA9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvMmUuMzcuODkuY2MvMTMnKSwgJycpCgkxNiA2LjE1My4xZCgxMCk9PTM1OgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDRlKToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCgkJIyAyOSAxIDQzIDM0IDIxIDE4IGEwCgkJCTE2IDU1ID4gMDoKCQoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSBkMyAxZSAyMCIsIDJkKDU1KSArICIgMSAyNCIsICI1OCAzMyAyNyAxOCBhMCAzMD8iKToKCQkJCQoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoJCQkJCQkKCQkJMmI6CgkJCQkxZgoKCQkJCQkjIDQ4IDE1MyAxOCA3NCAxMyAxCgk1MCA9IDYuMTUzLjEzYigxNy40KCdjOi8vMjUvMTIvMmUuMzcuNzQvMTA0JyksICcnKQoJMTYgNi4xNTMuMWQoMTApPT0zNToJCgkJNWMgOCwgNTYsIDEgMTEgNi4yYyg1MCk6CgkJCTU1ID0gMAoJCQk1NSArPSAzYygxKQoJCQoJCSMgMjkgMSA0MyAzNCAyMSAxOCBhMAoJCQkxNiA1NSA+IDA6CgkKCQkJCTMgPSA3LjkoKQoJCQkJMTYgMy4xYygiMTUgOTggMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCQkKCQkJCQk1YyBmIDExIDE6CgkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCTVjIGQgMTEgNTY6CgkJCQkJCTE5LjFhKDYuMTUzLjEzYig4LCBkKSkKCQkJCQkJCgkJCTJiOgoJCQkJMWYKCgkJCSAgICMgNDggMTUzIDE4IGNlIDEzIDEKCTQyID0gNi4xNTMuMTNiKDE3LjQoJ2M6Ly80YS9jZScpLCAnJykKCTE2IDYuMTUzLjFkKDQyKT09MzU6CQoJCTVjIDgsIDU2LCAxIDExIDYuMmMoNDIpOgoJCQk1NSA9IDAKCQkJNTUgKz0gM2MoMSkKCSAgIAoJCSMgMjkgMSA0MyAzNCAyMSAxOCBhMAoJCQkxNiA1NSA+IDA6CiAgIAoJCQkJMyA9IDcuOSgpCgkJCQkxNiAzLjFjKCIxNSAxMzMgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCSAgIAoJCQkJCTVjIGYgMTEgMToKCQkJCQkJNi4xNCg2LjE1My4xM2IoOCwgZikpCgkJCQkJNWMgZCAxMSA1NjoKCQkJCQkJMTkuMWEoNi4xNTMuMTNiKDgsIGQpKQoKCQkJCQkjIDQ4IDE1MyAxOCA5MSAxMyAxCgkKCTRmID0gMTcuNCgnYzovLzlmLzEyLzJlLjM3LjkxJykKCTMgPSA3LjkoKQoJNTI6CgkJMTYgMy4xYygiMTUgZWIgMWUgMjAiLCAiNTggMzMgMjcgMTggYTAgMTMiKToKCQkJNmYgPSA2LjE1My4xM2IoNGYsIjEzLmRiIikKCQkJNi4xNCg2ZikKCgkyODoKCQkxZgoJCgkzID0gNy45KCkKCTMuNWYoIjdhIDJmIiwgIgkJCQkJCQkgICBkMiA1YiAxZSAiLCAiCQkJCQkJICBbMmEgYWFdNzIgOWUgYWUgMTEzIDdhIDJmWy8yYV0iKQoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAxMGEgNDcgOGUJICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSA0NyA2OAkgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoJCjVhIDliKDM4KToKCTIzICcjIyMnK2Y1KycgLSAzZCA2OCMjIycKCTRkID0gMTcuNCg2LjE1My4xM2IoJ2M6Ly80YS9hOS84YicsICcnKSkKCTUyOgkKCQk1YyA4LCA1NiwgMSAxMSA2LjJjKDRkKToKCQkJNTUgPSAwCgkJCTU1ICs9IDNjKDEpCgkJCQoJCSMgMjkgMSA0MyAzNCAyMSAxOCBhMAoJCQkxNiA1NSA+IDA6CgkKCQkJCTMgPSA3LjkoKQoJCQkJMTYgMy4xYygiMTUgZGQgMWUgMjAiLCAyZCg1NSkgKyAiIDEgMjQiLCAiNTggMzMgMjcgMTggYTAgMzA/Iik6CgkJCQkJCQkKCQkJCQk1YyBmIDExIDE6CgkJCQkJCTYuMTQoNi4xNTMuMTNiKDgsIGYpKQoJCQkJCTVjIGQgMTEgNTY6CgkJCQkJCTE5LjFhKDYuMTUzLjEzYig4LCBkKSkKCQkJCQkzID0gNy45KCkKCQkJCQkzLjVmKGY1LCAiCSAgIDViIDZjIDEwYyAxMjQiKQoJCQkJMmI6CgkJCQkJCTFmCgkJCTJiOgoJCQkJMyA9IDcuOSgpCgkJCQkzLjVmKGY1LCAiCSAgIDEwOSA2YyAxOCA0NyIpCgkyODogCgkJMyA9IDcuOSgpCgkJMy41ZihmNSwgIjE0ZCA1YiA2YyBhNSBiZCA2MyA0NCAxMmIgODYiKQoJNDUKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwljOSA0NyA2OCAgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAgIDQwIDY2CSAgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyAKCQo1YSAxMzAoMzgsMjIpOgoJMTUzID0gMTcuNCg2LjE1My4xM2IoJ2M6Ly80YS80YycsJycpKQoJZT02LjE1My4xM2IoMTUzLCAnMWIuN2QnKQoJMyA9IDcuOSgpCgljOD02LjE1My4xM2IoMTUzLCAnMWIuN2QuYzgnKQoJMTYgNi4xNTMuMWQoYzgpPT0xMWY6IAoJCTE2IDMuMWMoIjEyOCAxMmEgODgiLCAnMTM3IGFlIDEwZiAxMmEgMTJkIDg4PycsJycsICJbYl1bMmEgMTQwXQkgMTRlIGZjIDEwNiAxNDcgMTJjICEhIVsvYl1bLzJhXSIpOgoJCQkyMyAnIyMjJytmNSsnIC0gNzAgNjYjIyMnCgkJCTE1MyA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vNGEvNGMnLCcnKSkKCQkJZT02LjE1My4xM2IoMTUzLCAnMWIuN2QnKQoJCQk1MjoKCQkJCTYuNWUoZSkKCQkJCTIzICc9PT0gN2EgMmYgLSA4NQknKzJkKGUpKycJPT09JwoJCQkyODoKCQkJCTFmCgkJCTRiPTEwMS44YSgzOCkuOTQKCQkJYSA9IGIwKGUsIjE1MCIpIAoJCQlhLmM0KDRiKQoJCQlhLmMwKCkKCQkJMjMgJz09PSA3YSAyZiAtIDk2IDEwMwknKzJkKGUpKycJPT09JwoJCQkzID0gNy45KCkKCQkJMy41ZihmNSwgIgkgICBkOCBhZCBmOSA0MCA2NiIpCgkyYjogCgkJMjMgJyMjIycrZjUrJyAtIDcwIDY2IyMjJwoJCTE1MyA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vNGEvNGMnLCcnKSkKCQllPTYuMTUzLjEzYigxNTMsICcxYi43ZCcpCgkJNTI6CgkJCTYuNWUoZSkKCQkJMjMgJz09PSA3YSAyZiAtIDg1CScrMmQoZSkrJwk9PT0nCgkJMjg6CgkJCTFmCgkJNGI9MTAxLjhhKDM4KS45NAoJCWEgPSBiMChlLCIxNTAiKSAKCQlhLmM0KDRiKQoJCWEuYzAoKQoJCTIzICc9PT0gN2EgMmYgLSA5NiAxMDMJJysyZChlKSsnCT09PScKCQkzID0gNy45KCkKCQkzLjVmKGY1LCAiCSAgIGQ4IGFkIGY5IDQwIDY2IikJCgk0NQoKNWEgODcoMzgsMjIpOgoJMjMgJyMjIycrZjUrJyAtIDExOCA5OSA2NiMjIycKCTE1MyA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vNGEvNGMnLCcnKSkKCWU9Ni4xNTMuMTNiKDE1MywgJzFiLjdkJykKCTUyOgoJCWE9YjAoZSkuMTM2KCkKCQkxNiAnMTI5JyAxMSBhOgoJCQkyMj0nZmInCgkJNzcgJzExZCcgMTEgYToKCQkJMjI9J2ZkJwoJCTc3ICcxMGUnIDExIGE6CgkJCTIyPSdmMCcKCQk3NyAnMTIyJyAxMSBhOgoJCQkyMj0nMTNhIDEwOCA3MScKCQk3NyAnMTI2JyAxMSBhOgoJCQkyMj0nMTQyIDEwOCA3MScKCQk3NyAnMTE3JyAxMSBhOgoJCQkyMj0nYzYnCgkyODoKCQkyMj0iMTRmIDcwIgoJMyA9IDcuOSgpCgkzLjVmKGY1LCJbMmEgODFdZmMgMTJlWy8yYV0gIisgMjIrIlsyYSA4MV0gNjYgZDEgMTE0Wy8yYV0iKQoJNDUKCjVhIDg0KDM4KToKCTIzICcjIyMnK2Y1KycgLSAzZCA5OSA2NiMjIycKCTE1MyA9IDE3LjQoNi4xNTMuMTNiKCdjOi8vNGEvNGMnLCcnKSkKCWU9Ni4xNTMuMTNiKDE1MywgJzFiLjdkJykKCTUyOgoJCTYuNWUoZSkKCQkzID0gNy45KCkKCQkyMyAnPT09IDdhIDJmIC0gM2QJJysyZChlKSsnCT09PScKCQkzLjVmKGY1LCAiCSAgIDY5IDQwIDhjIDc2IikKCTI4OgoJCTMgPSA3LjkoKQoJCTMuNWYoZjUsICIJICAgMTA5IDQwIDhjIDllIDY5IikKCTQ1CgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIGM5IDQwIDY2CSAjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKMTRiID0gNmQuM2UoJzM2PScpCjE1MSA9IDZkLjNlKCc4Zj0nKQpiID0gNmQuM2UoJzU3PT0nKQoxNGMgPSA2ZC4zZSgnM2InKQ==")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|files|2|dialog|translatePath|5|os|xbmcgui|root|Dialog|a|B|special|d|advance|f|itv_cache_path|in|addon_data|cache|unlink|Delete|if|xbmc|to|shutil|rmtree|advancedsettings|yesno|exists|Cache|pass|Files|option|name|print|found|profile|description|want|except|Count|COLOR|else|walk|str|plugin|Wizard|them|downloader_cache_path|channel4_cache_path|you|give|True|aHR0cDovL3d3dy5rb2RpbWVkaWFwb3J0YWwuYnlldGhvc3Q5LmNvbS8|video|url|iplayer_cache_path|iconimage|aHR0cDovL2ZyZWVmaXguYnlldGhvc3Q5LmNvbS93aXphcmQudHh0|len|DELETING|decodestring|supercartoons_cache_path|Advanced|xbmc_cache_path|temp_cache_path|and|mediaportal|return|replace|DELETE|Set|wtf_cache_path|home|link|userdata|packages_cache_path|tvonline_cache_path|genesis_cache_path|youtube_cache_path|fanart|try|phoenix_cache_path|ytmusic_cache_path|file_count|dirs|LmJ5ZXRob3N0OS5jb20vd2l6YXJkLnR4dA|Do|addonfolder|def|Deleting|for|Please|remove|ok|escription|m4me_cache_path|match|KODI|LocalAndRental|executebuiltin|XML|supercartoons|PACKAGES|Remove|atv2_cache_a|atv2_cache_b|Packages|base64|OPEN_URL|genesiscache|ADVANCED|RECOMMENDED|Brought|findall|youtube|compile|Sucessfull|elif|Downloader|downloader|MD|Thumbnails|addDir|xml|iplayer_http_cache|movies4me|thumbnail|yellow|getCondVisibility|UpdateLocalAddons|DELETEADVANCEDXML|REMOVING|facebook|CHECKADVANCEDXML|Original|tvonline|http_GET|packages|Settings|UpdateAddonRepos|CACHE|L3dpemFyZC50eHQ|anart|genesis|DialogProgress|setView|content|private|WRITING|iPlayer|YouTube|ADVANCE|Library|DELETEPACKAGES|FIXREPOSADDONS|AppleTV|To|masterprofile|delete|SuperCartoons|ATV2|DELETETHUMBS|TNPATH|please|THUMBS|Caches|Simple|addons|gold|ADDONS|movies|Adding|You|lib|open|mobile|text13|Downloading|whatthefurk|DELETECACHE|Extracting|textures13|WARNING|Other|dp|Textures13|UPDATEREPO|visit|Be|Disconnect|close|REPOS|SUCCESSFUL|Video|write|spotitube|MIKEY1234|phstreams|bak|End|Movies4me|platform|cc|Addona16|temp|Take|This|SETTINGS|Finished|TVonline|Wait|STANDARD|database|addons16|Done|download|ADDONS16|db|restart|Package|feature|REFRESH|library|ANDROID|PREMIUM|Restart|proceed|deletes|Phoenix|extract|iplayer|rebuild|phoenix|Genesis|update|var|WIZARD|create|MUCKYS|FIX|script|rl|re|AddonTitle|simple|folder|4oD|new|ITV|0CACHE|YOU|TUXENS|URLFIX|module|Effect|net|Images|NEW|kodion|DBPATH|CANNOT|mg|P2P|No|END|Affect|all|BBC|muckys|Backed|system|Undone|Reboot|By|SETUP|music|Music|mikey|CHECK|Power|sleep|Mucky|Cydia|tuxen|Ducks|False|Furk|MAIN|p2p1|your|done|sure|p2p2|What|Back|zero|Up|on|BACK|Your|HAVE|Archives|AXML|INFO|ONLY|Temp|File|time|read|Have|Are|Can|1st|join|n|The|r|itv|red|NOT|2nd|zip|WTF|4od|Zip|GO|th|U|do|N|F|Error|AS|NO|w|T|DB|path|H".split("|")))

################################
###        CHECK IP          ###
################################
#Thanks to metalkettle for his work on the original IP checker addon        

def IPCHECK(url='http://www.iplocation.net/',inc=1):
    match=re.compile("<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>").findall(net.http_GET(url).content)
    for ip, region, country, isp in match:
        if inc <2: dialog=xbmcgui.Dialog(); dialog.ok('Check My IP',"[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % ip, '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % country, '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % isp)
        inc=inc+1

#################################
###      END CHECK IP         ###
#################################

#################################
###       CUSTOM FTV          ###
#################################

def CUSTOMINI(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                                    Install Latest .ini File'):
        print '###'+AddonTitle+' - CUSTOM FTV INI###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'addons2.ini')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New .ini File")  
    return

def CUSTOMSET(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                               Install Custom Settings'):
        print '###'+AddonTitle+' - CUSTOM FTV SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New Settings")  
    return


def DELETEFTVDB():
    try:
        ftvpath = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        if os.path.exists(ftvpath)==True:
            dialog = xbmcgui.Dialog()
            if dialog.yesno("MD WIzard", "                               Delete FTV Guide Database"):
                ftvsource = os.path.join(ftvpath,"source.db")               
                os.unlink(ftvsource)               
        dialog.ok("MD Wizard", "                                     FTV Database Reset")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "               Error Deleting Database No Database To Delete")
    return

#################################
###      END CUSTOM FTV       ###
#################################
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,description,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    #if addon.get_setting('auto-view') == 'true':

    #    print addon.get_setting(viewType)
    #    if addon.get_setting(viewType) == 'Info':
    #        VT = '515'
    #    elif addon.get_setting(viewType) == 'Wall':
    #        VT = '501'
    #    elif viewType == 'default-view':
    #        VT = addon.get_setting(viewType)

    #    print viewType
    #    print VT
        
    #    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        PREMIUM(url)

elif mode==2:
        URLFIX(url)

elif mode==3:
        MAINTENANCE()

elif mode==4:
        ADVANCEDXML()

elif mode==5:
        WIZARD(name,url,description)

elif mode==6:
        DELETEPACKAGES(url)

elif mode==7:
        AXML(url,name)

elif mode==8:
        CHECKADVANCEDXML(url,name)

elif mode==9:
        FIXREPOSADDONS(url)

elif mode==10:
        UPDATEREPO()

elif mode==11:
        DELETEADVANCEDXML(url)

elif mode==12:
        IPCHECK()

elif mode==13:
        DELETETHUMBS()

elif mode==14:
        DELETECACHE(url)

elif mode==15:
        CUSTOMFTV()

elif mode==16:
        CUSTOMINI(url,name)

elif mode==17:
        CUSTOMSET(url,name)

elif mode==18:
        DELETEFTVDB()
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
