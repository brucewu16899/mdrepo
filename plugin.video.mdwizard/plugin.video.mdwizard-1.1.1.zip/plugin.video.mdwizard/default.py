import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
from addon.common.addon import Addon
from addon.common.net import Net
 

###THANK YOU TO THE PEOPLE THAT ORIGINALY WROTE SOME OF THIS CODE WITHOUT YOU I STILL PROBABLY WOULDNT HAVE A CLUE WHERE TO START###

exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("ZGUgPSAnMTIwLzUuMCAoN2E7IDFhNTsgN2EgMWFhIDUuMTsgMWJjLTFiZDsgMWI5OjEuOS4wLjMpIDE1ZC9kZCAxMjkvMy4wLjMnCjUxID0gJzJkLjNhLjEwYScKZTAgPSBmNy4xNTgoMWI3PTUxKQpjPSI3OSAyOCIgCmU5ID0gMTk4KCkKZSA9IDFhZC4xYzYoMWM1LjFhOS4xNjUoJ2I2Oi8vNDMvNTkvJyArIDUxICwgJzZkLmVlJykpCjE4YiA9IDFhZC4xYzYoMWM1LjFhOS4xNjUoJ2I2Oi8vNDMvNTkvJyArIDUxLCAnMTZjLjMzJykpCjJiID0gMWFkLjFjNigxYzUuMWE5LjE2NSgnYjY6Ly80My81OS8nICsgNTEgKyAnL2VkLzFhMy8nKSkKMTFkID0gIjEuMS4xIgpjNyA9IDFhZC4xYzYoJ2I2Oi8vOTcnKQo4ZiA9IDFhZC4xYzYoJ2I2Oi8vZDInKTsKMTcwID0gImRmIGUzIDI4IiAgICAgICAgICAgIAoxYSA9ICJjMzovLzZiLjE3OCIKMWJmID0gJ2MzOi8vJwoKNDkgMTUzKCk6CgkzYignN2MgMTU0JywnMzInLDEsMmIrJzdjLjMzJyxlLCcnKQoJM2IoJzlmIGY0IDEzOScsJzMyJywxNzQsMmIrJzEuZWUnLGUsJycpCgkzYignZjYgMTVhJywxYSwyLDJiKydmNi4zMycsZSwnJykKCTNiKCcyMycsMWEsMywyYisnMjMuMzMnLGUsJycpCgkzYignNTMgNzQgMmEnLDFhLDQsMmIrJzJhLjMzJyxlLCcnKQojCTNiKCcxNDQgZWMgZGMnLCdmNicsMTUsMmIrJ2EwLjMzJyxlLCcnKQoJNWYoJzY4JywgJzljJykKCjQ5IDIzKCk6CgkxYjUoJzM3IDgyJywnMzInLDE0LDJiKycyMy4zMycsZSwnJykKCTFiNSgnMzcgNjYnLCczMicsNiwyYisnMjMuMzMnLGUsJycpCgkxYjUoJzE1NyBiMScsJzMyJywxMCwyYisnMjMuMzMnLGUsJzE2NCAxMjMgMWEyIDE2OCcpCiMJM2IoJzE4NyAxNGEgZjIgMTU2IGEyJywnMzInLDksMmIrJzEuZWUnLGUsJzE5YiAxMjIgMTAxJykKCTFiNSgnYTEgMWFjIDFjMicsJzMyJywxMiwyYisnMjMuMzMnLGUsJycpCgkxYjUoJ2IyIDEwNCAzNyBlZi4xNzYmZWEgMTRjJywnMzInLDEzLDJiKycyMy4zMycsZSwnMTgzIDE1MiAxN2YgMTFlIDE3ZiA3YSAxYzEgMTI1IDEwYiBmNSAxM2UgMTlmIDE4ZCAxYTEgMWIxIDEyYiA3ZS5kYicpCgk1ZignNjgnLCAnOWMnKQoKCjQ5IDE3MygpOgoJMWI1KCdhMSA1MyAyYScsMWEsOCwyYisnMmEuMzMnLGUsJycpCgkxYjUoJ2I4IDJhJywxYSsnLzQxL2JjLjU0Jyw3LDJiKycyYS4zMycsZSwnJykKCTFiNSgnY2EgMmEnLDFhKycvNDEvMTMwLjU0Jyw3LDJiKycyYS4zMycsZSwnJykKCTFiNSgnOGEgMmEnLDFhKycvNDEvZDYuNTQnLDcsMmIrJzJhLjMzJyxlLCcnKQoJMWI1KCdiZiAyYScsMWErJy80MS8xNGIuNTQnLDcsMmIrJzJhLjMzJyxlLCcnKQoJMWI1KCdjNiA0ZCAxNzInLDFhKycvNDEvMTBjLjU0Jyw3LDJiKycyYS4zMycsZSwnJykKCTFiNSgnYzYgNGQgMTcxJywxYSsnLzQxLzEwZC41NCcsNywyYisnMmEuMzMnLGUsJycpCgkxYjUoJzM3IDJhJywxYSwxMSwyYisnMmEuMzMnLGUsJycpCgk1ZignNjgnLCAnOWMnKQoKNDkgZTcoKToKCTNiKCcxMTEgZWMgZGMgMTk1IDE2MSA4YiAxMDInLDFhKycvNDEvOGMvMTAzLTU5LjE0MScsNSwyYisnYTAuMzMnLGUsJycpCgkxYjUoJzg3IDE1ZiAxOTYgNzQnLDFhKycvNDEvOGMvZmIuNTQnLDE3LDJiKydhMC4zMycsZSwnJykKCTFiNSgnODcgMTI4LjE5OSAxNDcgMTViJywnYzM6Ly9lOC4xMjQuMTljLzExOC4xOGYnLDE2LDJiKydhMC4zMycsZSwnJykKCTFiNSgnMTYwIGVjIDEwMCcsJzMyJywxOCwyYisnYTAuMzMnLGUsJycpCgkKCgo0OSAxMzMoKToKCTYzID0gOTQoMWErMWJhKzE5ZSkuNzAoJ1wxYzQnLCcnKS43MCgnXDFhOCcsJycpCgk4MCA9IDE4MS5hMygnMmY9IiguKz8pIi4rPzE4Mj0iKC4rPykiLis/MTc3PSIoLis/KSIuKz9jMj0iKC4rPykiLis/ODQ9IiguKz8pIicpLmFiKDYzKQoJNjUgMmYsMzIsNWQsNmQsNDAgMWIzIDgwOgoJCQkzYigyZiwzMiw1LDVkLDZkLDQwKQoJNWYoJzY4JywgJzljJykKCQoKNDkgN2MoKToKCTVjOgoJCTYzID0gOTQoMWJmKzFhNSsxYzMrMTllKS43MCgnXDFjNCcsJycpLjcwKCdcMWE4JywnJykKCQk4MCA9IDE4MS5hMygnMmY9IiguKz8pIi4rPzE4Mj0iKC4rPykiLis/MTc3PSIoLis/KSIuKz9jMj0iKC4rPykiLis/ODQ9IiguKz8pIicpLmFiKDYzKQoJCTY1IDJmLDMyLDVkLDZkLDQwIDFiMyA4MDoKCQkJM2IoMmYsMzIsNSw1ZCw2ZCw0MCkKCTJlOiAyMgoJNWYoJzY4JywgJzE4NCcpCgoKNDkgMTM1KDJmLDMyLDQwKToKCTFhOSA9IDFhZC4xYzYoMWM1LjFhOS4xNjUoJ2I2Oi8vNDMvNTknLCc5NScpKQoJZDkgPSAxNDYuYTgoKQoJZDkuMTNiKCJkZiBlMyAyOCIsImNkICIsJycsICc2NyBmZicpCgliZD0xYzUuMWE5LjE2NSgxYTksIDJmKycuMTQxJykKCTVjOgoJICAgMWM1LjZhKGJkKQoJMmU6CgkgICAyMgoJN2YuZjgoMzIsIGJkLCBkOSkKCTYyID0gMWFkLjFjNigxYzUuMWE5LjE2NSgnYjY6Ly8nLCc0MycpKQoJMTg2LjE1NSgyKQoJZDkuMTQ4KDAsIiIsICJkNSAxYTAgNjcgZmYiKQoJMjYgJz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PScKCTI2IDYyCgkyNiAnPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09JwoJMTFiLjEyZShiZCw2MixkOSkKCTE3NSA9IDE0Ni4xYTYoKQoJMTc1LjY5KCI2ZSA0YyIsICI2NyBkMCAxMmIgMTVjIGIzIGZkIDE0ZCIsIlszMCA4ZF03ZCBiMyBjMSAxNGUgNmUgNGNbLzMwXSIpCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJZjIgYTImOGIJICAjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKCjQ5IGRhKCk6CgkxYWQuNzEoICc5MCcgKQoJMWFkLjcxKCAnOWUnICkKCTE3NSA9IDE0Ni4xYTYoKQoJMTc1LjY5KCI3OSAyOCIsICcnLCcJCQkJCQkJCSBiMSBkMyA6KScsICIJCQkJCQkgIFszMCBjYl03ZCBiMyBjMSAxNGUgNzkgMjhbLzMwXSIpCgk1MAoJCiM0OSBhYygzMik6CiMJMjYgJyMjIycrYysnIC0gNDUgMTEwLjE3NiAjIyMnCiMJMWE5ID0gMWFkLjFjNigxYzUuMWE5LjE2NSgnYjY6Ly85NycsJycpKQojCTYxPTFjNS4xYTkuMTY1KDFhOSwgJzEwZi5kYicpCiMJNWM6CiMJCTFjNS42YSg2MSkKIwkJMTc1ID0gMTQ2LjFhNigpCiMJCTI2ICc9PT0gNzkgMjggLSA0NQknKzM2KDYxKSsnCT09PScKIwkJMTc1LjY5KGMsICIJICAgNzMgZmEuZGIgODMgNjcgMTQ5IGIzIGZkIDE0MCIpCiMJMmU6CiMJCTE3NSA9IDE0Ni4xYTYoKQojCQkxNzUuNjkoYywgIgkgICAxMzYgMTZmIGIzIDczIikKIwk1MAoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCWYwIGYyIGEyJjhiICAjIyMKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwkgMzcgYmEJCSMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKNDkgYzQoKToKCTVjOgoJCTE5IDFjNS4xYTkuMjAoOGYpPT0zZToKCQkJMTc1ID0gMTQ2LjFhNigpCgkJCTE5IDE3NS4xZigiMWIxIDg2IiwgIlszMCBjYl1bYl0jIyMjIyMjIyMjMTE3IGIyIDEwNCMjIyMjIyMjIyNbL2JdWy8zMF0iLCAiMTBlIDEyMSAxMmEgMTZhIDg5IDE0MyA0YSBlMi5kYiIsICIxYTQgM2MgMTZiIDNjIDJjIDFlIDFiNiAxMWY/IDEwZSAxOTcgMTlhIGJlIDE1MSIpOgoJCQkJNjUgMWM3LCAxYWYsIDEwNiAxYjMgMWM1LjM0KDhmKToKCQkJCQk1NiA9IDAKCQkJCQk1NiArPSA0NCgxMDYpCgkJCQkJMTkgNTYgPiAwOgkJCQkKCQkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQkJCSAgIAoJCWM5ID0gMWM1LjFhOS4xNjUoYzcsIjdlLmRiIikJCQkgICAKCQkxYzUuMWIyKGM5KQoJCTE3NS42OSgiMTFjIDZlIiwgIjY3IDExNSA2ZSAxZSAxMjYgODkgMTEyIikKCTJlOiAKCQkxNzUgPSAxNDYuMWE2KCkKCQkxNzUuNjkoYywgImUxIDY0IDg2IGI3IGU0IDZlIDRjIDE3YyA5YiIpCgk1MAoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAxNDIgMzcgYmEJIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJICAgMzcgODIJICAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgo0OSBjZSgzMik6CgkyNiAnIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCSAgIDQ1IDEwOSA4MgkJCSAjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMnCgk0YiA9IDFjNS4xYTkuMTY1KDFhZC4xYzYoJ2I2Oi8vNDMnKSwgJzFiNCcpCgkxOSAxYzUuMWE5LjIwKDRiKT09M2U6CQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCg0Yik6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSA2ZSAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJNWM6CgkJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJCTJlOgoJCQkJCQkJMjIKCQkJCQk2NSBkIDFiMyAxYWY6CgkJCQkJCTVjOgoJCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJMmU6CgkJCQkJCQkyMgoJCQkJCQkKCQkJMzU6CgkJCQkyMgoJMTkgMWFkLjkxKCcxMzguZmUuMWE3Jyk6CgkJNzggPSAxYzUuMWE5LjE2NSgnL2E3LzEzNC9jMC9hZi9jNS9hNS9kNy8nLCAnZDEnKQoJCQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCg3OCk6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJCTE5IDU2ID4gMDoKCgkJCQkxNzUgPSAxNDYuMWE2KCkKCQkJCTE5IDE3NS4xZigiMWIxIDFhNyAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IDFiMyAnZDEnIiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQoJCQkJCTY1IGQgMWIzIDFhZjoKCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjIKCQk3NyA9IDFjNS4xYTkuMTY1KCcvYTcvMTM0L2MwL2FmL2M1L2E1L2Q3LycsICc2ZicpCgkJCgkJNjUgMWM3LCAxYWYsIDEwNiAxYjMgMWM1LjM0KDc3KToKCQkJNTYgPSAwCgkJCTU2ICs9IDQ0KDEwNikKCQkKCQkJMTkgNTYgPiAwOgoKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgMWE3IDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjcgMWIzICc2ZiciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoJCQkgICMgNGYgMWE5IDFlIDE2MiAxMDUgMWI0IDEwNgoJCQkJCQkJIAoKCSMgNGYgMWE5IDFlIDE3OSAxYjggMTdiIDFiNCAxMDYKCTRlID0gMWM1LjFhOS4xNjUoMWFkLjFjNignYjY6Ly8yOS8xYWUvMmQuM2EuY2YvMWI0JyksICcnKQoJMTkgMWM1LjFhOS4yMCg0ZSk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNGUpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJCQoJCSMgMzEgMTA2IDRhIDNmIDI1IDFlIDE2ZQoJCQkxOSA1NiA+IDA6CgkKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgMTk0IDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoJCQkJCgkJCQkjIDRmIDFhOSAxZSAxMzIgMWI0IDEwNgoJM2Q9IDFjNS4xYTkuMTY1KDFhZC4xYzYoJ2I2Oi8vMjkvMWFlLzJkLjNhLjE5Mi8xYjQnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDNkKT09M2U6CQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCgzZCk6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSAxMzIgMjEgMjQiLCAzNig1NikgKyAiIDEwNiAyNyIsICI2MCAzYyAyYyAxZSAxNmUgMzg/Iik6CgkJCQkKCQkJCQk2NSBmIDFiMyAxMDY6CgkJCQkJCTFjNS4xYjIoMWM1LjFhOS4xNjUoMWM3LCBmKSkKCQkJCQk2NSBkIDFiMyAxYWY6CgkJCQkJCTFkLjFjKDFjNS4xYTkuMTY1KDFjNywgZCkpCgkJCQkJCQoJCQkzNToKCQkJCTIyCgkJCQkKCQkJCSMgNGYgMWE5IDFlIDE1MCBhOSAxYjQgMTA2Cgk0Mj0gMWM1LjFhOS4xNjUoMWFkLjFjNignYjY6Ly8yOS8xYWUvMmQuM2EuMTE2LzhlJyksICcnKQoJMTkgMWM1LjFhOS4yMCg0Mik9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNDIpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJCQoJCSMgMzEgMTA2IDRhIDNmIDI1IDFlIDE2ZQoJCQkxOSA1NiA+IDA6CgkKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgMTUwIGE5IDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoJCQkJCgkJCQkKCQkJCSMgNGYgMWE5IDFlIGM4IDgxIDFiNCAxMDYKCTM5ID0gMWM1LjFhOS4xNjUoMWFkLjFjNignYjY6Ly8yOS8xYWUvMTNmLjEyYy4xM2QuN2YnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDM5KT09M2U6CQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCgzOSk6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSBjOCA4MSAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQoJCQkJCTY1IGQgMWIzIDFhZjoKCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjIKCQkJCQoJCQkJIyA0ZiAxYTkgMWUgMTM3IDFiNCAxMDYKCTFiMCA9IDFjNS4xYTkuMTY1KDFhZC4xYzYoJ2I2Oi8vMjkvMWFlLzJkLjNhLjE4ZS8xNGYnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDFiMCk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoMWIwKToKCQkJNTYgPSAwCgkJCTU2ICs9IDQ0KDEwNikKCQkKCQkjIDMxIDEwNiA0YSAzZiAyNSAxZSAxNmUKCQkJMTkgNTYgPiAwOgoJCgkJCQkxNzUgPSAxNDYuMWE2KCkKCQkJCTE5IDE3NS4xZigiMWIxIDEzNyAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQoJCQkJCTY1IGQgMWIzIDFhZjoKCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjIKCgkJCQkjIDRmIDFhOSAxZSA4OCAxYjQgMTA2Cgk2YyA9IDFjNS4xYTkuMTY1KDFhZC4xYzYoJ2I2Oi8vMjkvMWFlLzJkLjNhLjg4LzFiNCcpLCAnJykKCTE5IDFjNS4xYTkuMjAoMWIwKT09M2U6CQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCg2Yyk6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSBmMyAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQoJCQkJCTY1IGQgMWIzIDFhZjoKCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjIKCgkJCQkJIyA0ZiAxYTkgMWUgMTE5IDFiNCAxMDYKCTVlID0gMWM1LjFhOS4xNjUoMWFkLjFjNignYjY6Ly8yOS8xYWUvMmQuM2EuZTYvMjEnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDFiMCk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNWUpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJCQoJCSMgMzEgMTA2IDRhIDNmIDI1IDFlIDE2ZQoJCQkxOSA1NiA+IDA6CgkKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgMTFhIDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoKCQkJCQkjIDRmIDFhOSAxZSA3YiAxNjcgMWI0IDEwNgoJNWEgPSAxYzUuMWE5LjE2NSgxYWQuMWM2KCdiNjovLzI5LzFhZS8yZC4zYS5lYi8xYjQnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDFiMCk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNWEpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJCQoJCSMgMzEgMTA2IDRhIDNmIDI1IDFlIDE2ZQoJCQkxOSA1NiA+IDA6CgkKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgYWUgMTY2IDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoKCQkJCQkjIDRmIDFhOSAxZSA3MiAxYjQgMTA2Cgk0NiA9IDFjNS4xYTkuMTY1KDFhZC4xYzYoJ2I2Oi8vMjkvMWFlLzJkLjNhLjcyLzFiNCcpLCAnJykKCTE5IDFjNS4xYTkuMjAoMWIwKT09M2U6CQoJCTY1IDFjNywgMWFmLCAxMDYgMWIzIDFjNS4zNCg0Nik6CgkJCTU2ID0gMAoJCQk1NiArPSA0NCgxMDYpCgkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSBiNCAyMSAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJCQoJCQkJCTY1IGYgMWIzIDEwNjoKCQkJCQkJMWM1LjFiMigxYzUuMWE5LjE2NSgxYzcsIGYpKQoJCQkJCTY1IGQgMWIzIDFhZjoKCQkJCQkJMWQuMWMoMWM1LjFhOS4xNjUoMWM3LCBkKSkKCQkJCQkJCgkJCTM1OgoJCQkJMjIKCgkJCQkJIyA0ZiAxYTkgMWUgOTYuY2MgMWI0IDEwNgoJNTUgPSAxYzUuMWE5LjE2NSgxYWQuMWM2KCdiNjovLzI5LzFhZS8yZC4zYS45Ni5jYy8xYjQnKSwgJycpCgkxOSAxYzUuMWE5LjIwKDFiMCk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNTUpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJCQoJCSMgMzEgMTA2IDRhIDNmIDI1IDFlIDE2ZQoJCQkxOSA1NiA+IDA6CgkKCQkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkJMTkgMTc1LjFmKCIxYjEgZmMgMjEgMjQiLCAzNig1NikgKyAiIDEwNiAyNyIsICI2MCAzYyAyYyAxZSAxNmUgMzg/Iik6CgkJCQkKCQkJCQk2NSBmIDFiMyAxMDY6CgkJCQkJCTFjNS4xYjIoMWM1LjFhOS4xNjUoMWM3LCBmKSkKCQkJCQk2NSBkIDFiMyAxYWY6CgkJCQkJCTFkLjFjKDFjNS4xYTkuMTY1KDFjNywgZCkpCgkJCQkJCQoJCQkzNToKCQkJCTIyCgoJCQkJCSMgNGYgMWE5IDFlIDdiIDFiNCAxMDYKCTU4ID0gMWM1LjFhOS4xNjUoMWFkLjFjNignYjY6Ly8yOS8xYWUvMmQuM2EuN2IvMTJkJyksICcnKQoJMTkgMWM1LjFhOS4yMCgxYjApPT0zZToJCgkJNjUgMWM3LCAxYWYsIDEwNiAxYjMgMWM1LjM0KDU4KToKCQkJNTYgPSAwCgkJCTU2ICs9IDQ0KDEwNikKCQkKCQkjIDMxIDEwNiA0YSAzZiAyNSAxZSAxNmUKCQkJMTkgNTYgPiAwOgoJCgkJCQkxNzUgPSAxNDYuMWE2KCkKCQkJCTE5IDE3NS4xZigiMWIxIGFlIDIxIDI0IiwgMzYoNTYpICsgIiAxMDYgMjciLCAiNjAgM2MgMmMgMWUgMTZlIDM4PyIpOgoJCQkJCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoJCQkJCQkKCQkJMzU6CgkJCQkyMgoKCQkJICAgIyA0ZiAxYTkgMWUgZjkgMWI0IDEwNgoJNDggPSAxYzUuMWE5LjE2NSgxYWQuMWM2KCdiNjovLzQzL2Y5JyksICcnKQoJMTkgMWM1LjFhOS4yMCg0OCk9PTNlOgkKCQk2NSAxYzcsIDFhZiwgMTA2IDFiMyAxYzUuMzQoNDgpOgoJCQk1NiA9IDAKCQkJNTYgKz0gNDQoMTA2KQoJICAgCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKICAgCgkJCQkxNzUgPSAxNDYuMWE2KCkKCQkJCTE5IDE3NS4xZigiMWIxIDE3ZCAyNCIsIDM2KDU2KSArICIgMTA2IDI3IiwgIjYwIDNjIDJjIDFlIDE2ZSAzOD8iKToKCQkJICAgCgkJCQkJNjUgZiAxYjMgMTA2OgoJCQkJCQkxYzUuMWIyKDFjNS4xYTkuMTY1KDFjNywgZikpCgkJCQkJNjUgZCAxYjMgMWFmOgoJCQkJCQkxZC4xYygxYzUuMWE5LjE2NSgxYzcsIGQpKQoKCQkJCQkjIDRmIDFhOSAxZSBiMCAxYjQgMTA2CgkKCTViID0gMWFkLjFjNignYjY6Ly9iNS8xYWUvMmQuM2EuYjAnKQoJMTc1ID0gMTQ2LjFhNigpCgk1YzoKCQkxOSAxNzUuMWYoIjFiMSAxMTQgMjEgMjQiLCAiNjAgM2MgMmMgMWUgMTZlIDFiNCIpOgoJCQk3NSA9IDFjNS4xYTkuMTY1KDViLCIxYjQuZGIiKQoJCQkxYzUuMWIyKDc1KQoKCTJlOgoJCTIyCgkKCTE3NSA9IDE0Ni4xYTYoKQoJMTc1LjY5KCI3OSAyOCIsICIJCQkJCQkJICAgMTA3IDY0IDIxICIsICIJCQkJCQkgIFszMCBjYl03ZCBiMyBjMSAxNGUgNzkgMjhbLzMwXSIpCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIDE0MiAzNyA4MgkgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwojIyMJIDM3IDY2CSAgIyMjCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCgkKNDkgYTQoMzIpOgoJMjYgJyMjIycrYysnIC0gNDUgNjYjIyMnCgk1NyA9IDFhZC4xYzYoMWM1LjFhOS4xNjUoJ2I2Oi8vNDMvNTkvOTUnLCAnJykpCgk1YzoJCgkJNjUgMWM3LCAxYWYsIDEwNiAxYjMgMWM1LjM0KDU3KToKCQkJNTYgPSAwCgkJCTU2ICs9IDQ0KDEwNikKCQkJCgkJIyAzMSAxMDYgNGEgM2YgMjUgMWUgMTZlCgkJCTE5IDU2ID4gMDoKCQoJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkxOSAxNzUuMWYoIjFiMSAxMjcgMjEgMjQiLCAzNig1NikgKyAiIDEwNiAyNyIsICI2MCAzYyAyYyAxZSAxNmUgMzg/Iik6CgkJCQkJCQkKCQkJCQk2NSBmIDFiMyAxMDY6CgkJCQkJCTFjNS4xYjIoMWM1LjFhOS4xNjUoMWM3LCBmKSkKCQkJCQk2NSBkIDFiMyAxYWY6CgkJCQkJCTFkLjFjKDFjNS4xYTkuMTY1KDFjNywgZCkpCgkJCQkJMTc1ID0gMTQ2LjFhNigpCgkJCQkJMTc1LjY5KGMsICIJICAgNjQgNzYgMTJlIDE4OCIpCgkJCQkzNToKCQkJCQkJMjIKCQkJMzU6CgkJCQkxNzUgPSAxNDYuMWE2KCkKCQkJCTE3NS42OShjLCAiCSAgIDEzNiA3NiAxZSAzNyIpCgkyZTogCgkJMTc1ID0gMTQ2LjFhNigpCgkJMTc1LjY5KGMsICJlMSA2NCA3NiBiNyBlNCA2ZSA0YyAxN2MgOWIiKQoJNTAKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwlmMCAzNyA2NiAgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoKIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMKIyMjCSAgIDQ3IDJhCSAgICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyAKCQo0OSAxODUoMzIsMmYpOgoJMWE5ID0gMWFkLjFjNigxYzUuMWE5LjE2NSgnYjY6Ly80My81MicsJycpKQoJNjE9MWM1LjFhOS4xNjUoMWE5LCAnMWIuNTQnKQoJMTc1ID0gMTQ2LjFhNigpCglmMT0xYzUuMWE5LjE2NSgxYTksICcxYi41NC5mMScpCgkxOSAxYzUuMWE5LjIwKGYxKT09MTU5OiAKCQkxOSAxNzUuMWYoIjE4YyAxNjkgOWQiLCAnMTdhIGMxIDEzYSAxNjkgMTBiIDlkPycsJycsICJbYl1bMzAgMTkwXQkgMWMwIDE0NSAxMmYgMWJlIDE4OSAhISFbL2JdWy8zMF0iKToKCQkJMjYgJyMjIycrYysnIC0gNTMgMmEjIyMnCgkJCTFhOSA9IDFhZC4xYzYoMWM1LjFhOS4xNjUoJ2I2Oi8vNDMvNTInLCcnKSkKCQkJNjE9MWM1LjFhOS4xNjUoMWE5LCAnMWIuNTQnKQoJCQk1YzoKCQkJCTFjNS42YSg2MSkKCQkJCTI2ICc9PT0gNzkgMjggLSA5OQknKzM2KDYxKSsnCT09PScKCQkJMmU6CgkJCQkyMgoJCQk2Mz1lOS45OCgzMikuYWEKCQkJYSA9IGJiKDYxLCIxYmIiKSAKCQkJYS5lNSg2MykKCQkJYS5kOCgpCgkJCTI2ICc9PT0gNzkgMjggLSBhZCAxM2MJJyszNig2MSkrJwk9PT0nCgkJCTE3NSA9IDE0Ni4xYTYoKQoJCQkxNzUuNjkoYywgIgkgICAxMDggYjkgMTMxIDQ3IDJhIikKCTM1OiAKCQkyNiAnIyMjJytjKycgLSA1MyAyYSMjIycKCQkxYTkgPSAxYWQuMWM2KDFjNS4xYTkuMTY1KCdiNjovLzQzLzUyJywnJykpCgkJNjE9MWM1LjFhOS4xNjUoMWE5LCAnMWIuNTQnKQoJCTVjOgoJCQkxYzUuNmEoNjEpCgkJCTI2ICc9PT0gNzkgMjggLSA5OQknKzM2KDYxKSsnCT09PScKCQkyZToKCQkJMjIKCQk2Mz1lOS45OCgzMikuYWEKCQlhID0gYmIoNjEsIjFiYiIpIAoJCWEuZTUoNjMpCgkJYS5kOCgpCgkJMjYgJz09PSA3OSAyOCAtIGFkIDEzYwknKzM2KDYxKSsnCT09PScKCQkxNzUgPSAxNDYuMWE2KCkKCQkxNzUuNjkoYywgIgkgICAxMDggYjkgMTMxIDQ3IDJhIikJCgk1MAoKNDkgOWEoMzIsMmYpOgoJMjYgJyMjIycrYysnIC0gYTEgYTYgMmEjIyMnCgkxYTkgPSAxYWQuMWM2KDFjNS4xYTkuMTY1KCdiNjovLzQzLzUyJywnJykpCgk2MT0xYzUuMWE5LjE2NSgxYTksICcxYi41NCcpCgk1YzoKCQlhPWJiKDYxKS4xOGEoKQoJCTE5ICcxODAnIDFiMyBhOgoJCQkyZj0nY2EnCgkJODUgJzE1ZScgMWIzIGE6CgkJCTJmPSdiZicKCQk4NSAnYmMnIDFiMyBhOgoJCQkyZj0nYjgnCgkJODUgJzEwYycgMWIzIGE6CgkJCTJmPScxOTEgYzYgNGQnCgkJODUgJzEwZCcgMWIzIGE6CgkJCTJmPScxOWQgYzYgNGQnCgkJODUgJ2Q2JyAxYjMgYToKCQkJMmY9JzhhJwoJMmU6CgkJMmY9IjFhYiA1MyIKCTE3NSA9IDE0Ni4xYTYoKQoJMTc1LjY5KGMsIlszMCA4ZF0xNDUgMTZkWy8zMF0gIisgMmYrIlszMCA4ZF0gMmEgNzQgMTYzWy8zMF0iKQoJNTAKCjQ5IDkyKDMyKToKCTI2ICcjIyMnK2MrJyAtIDQ1IGE2IDJhIyMjJwoJMWE5ID0gMWFkLjFjNigxYzUuMWE5LjE2NSgnYjY6Ly80My81MicsJycpKQoJNjE9MWM1LjFhOS4xNjUoMWE5LCAnMWIuNTQnKQoJNWM6CgkJMWM1LjZhKDYxKQoJCTE3NSA9IDE0Ni4xYTYoKQoJCTI2ICc9PT0gNzkgMjggLSA0NQknKzM2KDYxKSsnCT09PScKCQkxNzUuNjkoYywgIgkgICA3MyA0NyA5MyA4MyIpCgkyZToKCQkxNzUgPSAxNDYuMWE2KCkKCQkxNzUuNjkoYywgIgkgICAxMzYgNDcgOTMgYjMgNzMiKQoJNTAKCiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjCiMjIwkgZjAgNDcgMmEJICMjIwojIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwoxYzMgPSAnLjZiLjE3OCcKMTllID0gJy80MS4xOTMnCjFhNSA9IGUwLmQ0KCcxN2UnKQoxYmEgPSAnLzExMyc=")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|8|9|a|B|AddonTitle|d|FANART|f|10|11|12|13|14|15|16|17|18|if|BASEURL|advancedsettings|rmtree|shutil|to|yesno|exists|Cache|pass|MAINTENANCE|Files|option|print|found|Wizard|profile|XML|ART|want|plugin|except|name|COLOR|Count|url|png|walk|else|str|DELETE|them|downloader_cache_path|video|addDir|you|channel4_cache_path|True|give|description|wizard|iplayer_cache_path|home|len|DELETING|supercartoons_cache_path|Advanced|temp_cache_path|def|and|xbmc_cache_path|mediaportal|RECOMMENDED|wtf_cache_path|Set|return|addon_id|userdata|ADVANCED|xml|tvonline_cache_path|file_count|packages_cache_path|youtube_cache_path|addons|ytmusic_cache_path|genesis_cache_path|try|iconimage|phoenix_cache_path|setView|Do|advance|addonfolder|link|Deleting|for|PACKAGES|Please|movies|ok|remove|kodimediaportal|m4me_cache_path|fanart|KODI|LocalAndRental|replace|executebuiltin|supercartoons|Remove|SETTINGS|genesiscache|Packages|atv2_cache_b|atv2_cache_a|MD|Windows|youtube|PREMIUM|Brought|Textures13|downloader|match|Downloader|CACHE|Sucessfull|escription|elif|Thumbnails|RENEGADES|movies4me|thumbnail|MIKEY1234|ADDONS|customftv|yellow|iplayer_http_cache|TNPATH|UpdateLocalAddons|getCondVisibility|DELETEADVANCEDXML|Settings|OPEN_URL|packages|tvonline|database|http_GET|REMOVING|CHECKADVANCEDXML|facebook|MAIN|Original|UpdateAddonRepos|KODIMEDIAPORTAL|ftv|CHECK|REPOS|compile|DELETEPACKAGES|AppleTV|ADVANCE|private|DialogProgress|iPlayer|content|findall|FIXREPOSADDONS|WRITING|YouTube|Library|genesis|REFRESH|ANDROID|To|SuperCartoons|masterprofile|special|please|MUCKYS|Adding|THUMBS|open|muckys|lib|Be|TUXENS|mobile|You|anart|http|DELETETHUMBS|Caches|P2P|DBPATH|Simple|text13|0CACHE|gold|cc|Downloading|DELETECACHE|whatthefurk|Disconnect|Other|thumbnails|SUCCESSFUL|getSetting|Extracting|mikey|Video|close|dp|UPDATEREPO|db|GUIDE|2008092417|USER_AGENT|Mucky|ADDON|Error|textures13|Ducks|visit|write|phstreams|CUSTOMFTV|renegades|net|THUBMNAIL|spotitube|FTV|resources|jpg|TEXTURE13|End|bak|FIX|Movies4me|COMMUNITY|Thumnails|URL|xbmcaddon|download|temp|Addona16|settings|TVonline|Take|platform|Wait|DATABASE|Database|REQUIRED|ftvguide|ONLY|Archives|files|Finished|Done|STANDARD|mdwizard|Your|p2p1|p2p2|This|addons16|ADDONS16|INSTALL|library|freefix|Genesis|restart|iplayer|WARNING|addons2|phoenix|Phoenix|extract|Restart|VERSION|Android|proceed|Mozilla|feature|Corrupt|Refresh|x10host|Deletes|rebuild|Package|ADDONS2|Firefox|deletes|The|module|kodion|all|CANNOT|0cache|new|4oD|URLFIX|var|WIZARD|No|ITV|system|BUILDS|Backed|create|NEW|simple|Folder|script|Affect|zip|END|folder|CUSTOM|YOU|xbmcgui|UPDATE|update|Reboot|RESORT|tuxens|FOLDER|Effect|By|Images|BBC|Undone|Works|INDEX|BUILD|sleep|EMPTY|FORCE|Addon|False|FIXES|DAILY|Power|Gecko|tuxen|FIRST|RESET|OTHER|Cydia|SETUP|Force|join|Music|music|Repos|Up|your|sure|icon|HAVE|delete|File|PATH|XML2|XML1|ADVANCEDXML|None|dialog|DB|mg|ml|What|Have|Furk|on|Temp|User|On|zero|re|rl|Only|INFO|AXML|time|LAST|done|BACK|read|ICON|Back|Does|itv|ini|red|1st|4od|txt|WTF|AND|RUN|Can|Net|INI|NOT|Fix|com|2nd|T|But|Zip|Not|All|art|Are|U|Dialog|ATV2|r|path|NT|NO|MY|xbmc|addon_data|dirs|itv_cache_path|Delete|unlink|in|cache|addDir2|do|id|th|rv|F|w|en|GB|GO|H|AS|It|IP|N|n|os|translatePath|root".split("|")))

################################
###        CHECK IP          ###
################################
#Thanks to metalkettle for his work on the original IP checker addon        

def IPCHECK(url='http://www.iplocation.net/',inc=1):
    match=re.compile("<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>").findall(net.http_GET(url).content)
    for ip, region, country, isp in match:
        if inc <2: dialog=xbmcgui.Dialog(); dialog.ok('Check My IP',"[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % ip, '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % country, '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % isp)
        inc=inc+1

#################################
###      END CHECK IP         ###
#################################

#################################
###       CUSTOM FTV          ###
#################################

def CUSTOMINI(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                                    Install Latest .ini File'):
        print '###'+AddonTitle+' - CUSTOM FTV INI###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'addons2.ini')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New .ini File")  
    return

def CUSTOMSET(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("MD Wizard", '                               Install Custom Settings'):
        print '###'+AddonTitle+' - CUSTOM FTV SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== MD Wizard - WRITING NEW    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding New Settings")  
    return


def DELETEFTVDB():
    try:
        ftvpath = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.ftvguide',''))
        if os.path.exists(ftvpath)==True:
            dialog = xbmcgui.Dialog()
            if dialog.yesno("MD WIzard", "                               Delete FTV Guide Database"):
                ftvsource = os.path.join(ftvpath,"source.db")               
                os.unlink(ftvsource)               
        dialog.ok("MD Wizard", "                                     FTV Database Reset")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "               Error Deleting Database No Database To Delete")
    return

#################################
###      END CUSTOM FTV       ###
#################################
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage,description,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    #if addon.get_setting('auto-view') == 'true':

    #    print addon.get_setting(viewType)
    #    if addon.get_setting(viewType) == 'Info':
    #        VT = '515'
    #    elif addon.get_setting(viewType) == 'Wall':
    #        VT = '501'
    #    elif viewType == 'default-view':
    #        VT = addon.get_setting(viewType)

    #    print viewType
    #    print VT
        
    #    xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        PREMIUM()

elif mode==2:
        URLFIX()

elif mode==3:
        MAINTENANCE()

elif mode==4:
        ADVANCEDXML()

elif mode==5:
        WIZARD(name,url,description)

elif mode==6:
        DELETEPACKAGES(url)

elif mode==7:
        AXML(url,name)

elif mode==8:
        CHECKADVANCEDXML(url,name)

elif mode==9:
        FIXREPOSADDONS(url)

elif mode==10:
        UPDATEREPO()

elif mode==11:
        DELETEADVANCEDXML(url)

elif mode==12:
        IPCHECK()

elif mode==13:
        DELETETHUMBS()

elif mode==14:
        DELETECACHE(url)

elif mode==15:
        CUSTOMFTV()

elif mode==16:
        CUSTOMINI(url,name)

elif mode==17:
        CUSTOMSET(url,name)

elif mode==18:
        DELETEFTVDB()
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
