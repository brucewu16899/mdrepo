import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,base64,random,shutil
import datetime
import time
import urlresolver
from addon.common.addon import Addon
from threading import Timer
import json

PLUGIN = 'plugin.video.streamengine'
ADDON = xbmcaddon.Addon(id=PLUGIN)
ART = xbmc.translatePath(os.path.join('special://home/addons/' + PLUGIN + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + PLUGIN, 'icon.png'))
addon = Addon(PLUGIN, sys.argv)
############################################################################################################################
### ID LIKE TO SAY THAT THIS ADDON WOULD NOT OF BEEN POSSIBLE IF IT WASNT FOR THE WORK ALREADY DONE BY OTHER DEVELOPERS  ###
###     WITHOUT OUT THE GUIDE OF THEIR WORK TO HELP ME UNDERSTAND NONE OF THIS WOULD OF BEEN POSSIBLE SO I THANK YOU     ###
############################################################################################################################
def INDEX():
    addLink('[B][COLOR red]ADDON CLOSED UNTILL FURTHER NOTICE[/COLOR][/B]','url',None,ART+'twitter.png','') 
    addLink('[B][COLOR red]THANK YOU FOR YOUR SUPPORT[/COLOR][/B]','url',None,ART+'twitter.png','')
    addLink('[B][COLOR red]TO MUCH WORK GOES IN TO THIS ADDON[/COLOR][/B]','url',None,ART+'twitter.png','')
    addLink('[B][COLOR red]TO JUST ALLOW AAA TO STEAL IT[/COLOR][/B]','url',None,ART+'twitter.png','')
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS            
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
    
def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
params=get_params()
url=None
name=None
mode=None
iconimage=None
date=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        play=urllib.unquote_plus(params["play"])
except:
        pass
try:
        date=urllib.unquote_plus(params["date"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
   
        
if mode==None or url==None or len(url)<1:
        INDEX()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
