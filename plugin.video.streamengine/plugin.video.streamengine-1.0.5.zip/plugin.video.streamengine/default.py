import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,base64
import datetime
import time
import urlresolver

from threading import Timer
import json

PLUGIN = 'plugin.video.streamengine'
ADDON = xbmcaddon.Addon(id=PLUGIN)
ART = xbmc.translatePath(os.path.join('special://home/addons/' + PLUGIN + '/resources/art/'))

############################################################################################################################
### ID LIKE TO SAY THAT THIS ADDON WOULD NOT OF BEEN POSSIBLE IF IT WASNT FOR THE WORK ALREADY DONE BY OTHER DEVELOPERS  ###
###     WITHOUT OUT THE GUIDE OF THEIR WORK TO HELP ME UNDERSTAND NONE OF THIS WOULD OF BEEN POSSIBLE SO I THANK YOU     ###
############################################################################################################################

def INDEX():
    try:
        import random
        text=''
        twit = 'http://twitrss.me/twitter_user_to_rss/?user=@StreamEngine85 '
        link = OPEN_URL(twit)
            
        match=re.compile("<description><!\[CDATA\[(.+?)\]\]></description>",re.DOTALL).findall(link)
        status = cleanHex(match[0])
        addDir('[B][COLOR red]Twitter >>>[/COLOR][/B] - [COLOR white]'+status.strip()+'[/COLOR]','url','',ART+'twitter.png','','','','')
    except:pass 
    link = OPEN_URL(U)
    fanart = re.compile('<fanart>(.+?)</fanart>').findall(link)[0]
    match = re.compile('<name>(.+?)</name>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>',re.DOTALL).findall(link)
    for name, url, iconimage in match:
        addDir('[B]%s[/B]' %name,url,1,iconimage,fanart,'','','')
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))



def FETCH(url):
    link = OPEN_URL(url)
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_TITLE )
    fanart = re.compile('<fanart>(.+?)</fanart>').findall(link)[0]
    if '<name>' in link:
        LINK=link.split('<name')
        for p in LINK:
            try:
                name=re.compile('>(.+?)</name>').findall(p)[0]
                iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(p)[0]
                url=re.compile('<link>(.+?)</link>').findall(p)[0]
                addDir('[B]%s[/B]' %name,url,1,iconimage,fanart,'','','','')        
            except:pass
            
    if '<item>' in link:
        LINKS=link.split('<item>')
        for p in LINKS:
            try:
                name=re.compile('title>(.+?)<').findall(p)[0]
                iconimage=re.compile('thumbnail>(.+?)<').findall(p)[0]
                p=p.replace('\n','').replace(' ','')
                url=re.compile('<link>(.+?)</link>').findall(p)[0]
                addDir('[B]%s[/B]' %name,url,2,iconimage,fanart,'','','','')        
            except:pass

def RESOLVE(name,url,iconimage):
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        



def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent' , "Magic Browser")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

            
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS        
#AAA ARE THIEVING BASTARDS
#AAA ARE THIEVING BASTARDS            
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



def addDir(name,url,mode,iconimage,fanart,play,date,description,page=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&play="+urllib.quote_plus(play)+"&date="+urllib.quote_plus(date)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Premiered":date,"Plot":description} )
        liz.setProperty('fanart_image', fanart)
        if mode==2 :
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok



def addLink(name,url,iconimage, fanart):
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true")
        liz.setProperty("Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)

        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':#<<<----see here if auto-view is enabled(true) 
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )#<<<-----then get the view type
                  
U=base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LnBocD9pPW5UOGpVREFR')               
params=get_params()
url=None
name=None
mode=None
iconimage=None
date=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        play=urllib.unquote_plus(params["play"])
except:
        pass
try:
        date=urllib.unquote_plus(params["date"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
   
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        FETCH(url)
        
elif mode==2:
        RESOLVE(name,url,iconimage)    


             
xbmcplugin.endOfDirectory(int(sys.argv[1]))
