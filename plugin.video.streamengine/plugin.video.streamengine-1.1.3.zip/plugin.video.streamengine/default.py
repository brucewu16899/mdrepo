import sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,service


############################################################################################################################
### ID LIKE TO SAY THAT THIS ADDON WOULD NOT OF BEEN POSSIBLE IF IT WASNT FOR THE WORK ALREADY DONE BY OTHER DEVELOPERS  ###
###     WITHOUT OUT THE GUIDE OF THEIR WORK TO HELP ME UNDERSTAND NONE OF THIS WOULD OF BEEN POSSIBLE SO I THANK YOU     ###
############################################################################################################################

