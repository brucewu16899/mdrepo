# -*- coding: utf-8 -*-

###you've never messaged me once to resolve this cedric
###and to say this addon has only ever scraped movies25 is just another lie 
###i gave you the chance to remove my stuff and i would remove your's
###but you said you were going to carry it on and keep pushing it further by adding more blocks with unpleasant remarks
###leaving me no choice but to do the same

'''
    MaaaDstream Add-on
    Special Thanks to the following developers for their contribution to the current code,
	               any future modifications, and to the KODI XBMC Community as a whole.  AAA
				   Mikey1234 Mettlekettle Kinkin Lambda spoyser Voinage Jasonpc
				   Highways Eldorado Blazetamer eleazer coding The-one Coolwave Muckyduck
				   
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Everyone should benefit from the GPL & opensource Programming
	
	H@k@M@c
	
'''

###totaly copied and pasted from another copied and pasted addon by mucky duck
###but to be fare hackamac this coding has changed alot from when i last looked 
###its just a shame they are intent on creating trouble for a newbie trying to learn

#aaastreamversion = "V2.0"
#aaastreamdate = "23/05/2015 14:00hrs GMT"

import urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, time, base64
import re,urllib2, datetime
import xbmcplugin,random,urlparse,urlresolver
from t0mm0.common.addon import Addon
from metahandler import metahandlers
from addon.common.net import Net
from threading import Timer

PlaylistUrl = "http://aaastream.com"
AddonID = 'plugin.video.MaaaDstream'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString

LocalisedReplay = 'aHR0cDovL2xpdmVmb290YmFsbHZpZGVvLmNvbS8='
Raw = base64.decodestring('aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcucGhwP2k9')
ChinaServer = base64.decodestring('aHR0cDovL2FhYXJlcG8ueHl6L2RvY3Mv')
LibDBLink = base64.decodestring('aHR0cDovL2ltdmRiLmNvbS8=')

EvoUrl = str(' http://aaarepo.xyz/evo/')

resolve_url=['180upload', 'my.mail.ru','streamin.to', '2gbhosting', 'alldebrid', 'allmyvideos', 'auengine', 'bayfiles', 'bestreams', 'billionuploads', 'castamp', 'cheesestream', 'clicktoview', 'cloudy', 'crunchyroll', 'cyberlocker', 'daclips', 'dailymotion', 'divxstage', 'donevideo', 'ecostream', 'entroupload', 'exashare', 'facebook', 'filebox', 'filenuke', 'flashx', 'gorillavid', 'hostingbulk', 'hostingcup', 'hugefiles', 'jumbofiles', 'lemuploads', 'limevideo', 'megarelease', 'megavids', 'mightyupload', 'mooshare_biz', 'movdivx', 'movpod', 'movreel', 'movshare', 'movzap', 'mp4stream', 'mp4upload', 'mrfile', 'muchshare', 'nolimitvideo', 'nosvideo', 'novamov', 'nowvideo', 'ovfile', 'play44_net', 'played', 'playwire', 'premiumize_me', 'primeshare', 'promptfile', 'purevid', 'putlocker', 'rapidvideo', 'realdebrid', 'rpnet', 'seeon', 'sharedsx', 'sharefiles', 'sharerepo', 'sharesix', 'sharevid', 'skyload', 'slickvid', 'sockshare', 'stagevu', 'stream2k', 'streamcloud', 'teramixer', 'thefile', 'thevideo', 'trollvid', 'tubeplus', 'tunepk', 'ufliq', 'uploadc', 'uploadcrazynet', 'veeHD', 'veoh', 'vidbull', 'vidcrazynet', 'video44', 'videobb', 'videoboxone', 'videofun', 'videomega', 'videoraj', 'videotanker', 'videovalley', 'videoweed', 'videozed', 'videozer', 'vidhog', 'vidpe', 'vidplay', 'vidspot', 'vidstream', 'vidto', 'vidup_org', 'vidxden', 'vidzi', 'vidzur', 'vimeo', 'vk', 'vodlocker', 'vureel', 'watchfreeinhd', 'xvidstage', 'yourupload', 'youwatch', 'zalaa', 'zooupload', 'zshare']
g_ignoreSetResolved=['plugin.video.dramasonline','plugin.video.f4mTester','plugin.video.shahidmbcnet','plugin.video.SportsDevil','plugin.stream.vaughnlive.tv','plugin.video.ZemTV-shani']

FacebookLink = 'Ud_kEL3bGWY'
DirectoryMSG = "[B][COLOR gold]The AAA Song(16+)[/COLOR][/B]"

net = Net(user_agent='Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36')
headers = {
    'Accept'    :   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
    }
AddonName = Addon.getAddonInfo("name")
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.MaaaDstream/fanart.jpg'))
artpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.MaaaDstream/resources/art/'))
icon = Addon.getAddonInfo('icon')
addonDir = Addon.getAddonInfo('path').decode("utf-8")
LibCommon = len(PlaylistUrl)
libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
custurltv = str(base64.decodestring('aHR0cDovL3d3dy50dm9ubGluZS50dy8='))
trans_table = ''.join( [chr(i) for i in range(128)] + [' '] * 128 )
datapath = xbmc.translatePath(Addon.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, "football.lwp")
if os.path.exists(cookie_path) == False:
        os.makedirs(cookie_path)
        net.save_cookies(cookie_jar)
		
import common

metaget = metahandlers.MetaData(preparezip=False)
metaset = 'true'
Freeview_url = 'http://www.filmon.com/' 
session_url = 'http://www.filmon.com/api/init/'
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)

ChildLockStatus = ''	
ChildLockFile = os.path.join(libDir,"childlock.txt")
if not (os.path.isfile(ChildLockFile)):
    ChildLockStatus = 'OFF'
else:
    ChildLockStatus = 'ON'
channels = ''	  
tmpListFile = os.path.join(addonDir, 'tempList.txt')
favoritesFile = os.path.join(addonDir, 'favorites.txt')
if  not (os.path.isfile(favoritesFile)):
	f = open(favoritesFile, 'w') 
	f.write('[]') 
	f.close() 



def Categories():
    #Version = '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]'
    #try: Version = net.http_GET('http://aaastream.com/version.php').content
    #except: AddDir("[COLOR red][B] BAD CONNECTION [/B][/COLOR]", "Update" ,98, icon)
    #if Version != aaastreamdate and Version != '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]':
           #UpdateMe()
           #xbmc.executebuiltin("UpdateLocalAddons")

   
    #AddDir("[COLOR white][B] "+aaastreamversion+" [/B][/COLOR]", "Update" ,98, icon)
    #links = ''
    #try: links = net.http_GET(Raw + 'MNBnYcrT').content
    #except: pass
    #if links.find('AAAMENU') < 1:
        #try: links = net.http_GET(ChinaServer + 'homemenu').content
        #except: links = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*SERVER DOWN*[/B][/COLOR]" C:icon'
    AddFacebookLink()
    links = net.http_GET(ChinaServer + 'homemenu').content
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        url = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')
        nono = '[COLOR white][B] TV BOXES[/B][/COLOR]'
        if nono not in name:
            AddDir('[COLOR lime]'+name+'[/COLOR]',url, mode, icon)
    #AddDir("[COLOR white][B] UPDATE[/B][/COLOR]", "Update" ,50, "http://s5.postimg.org/pgtpss09z/update.png")   
    xbmc.executebuiltin("Container.SetViewMode(500)") 
    

def TV():
    AddFacebookLink()
    AddDir("[COLOR white][B]FAVOURITES[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png") 
    AddDir('[COLOR white]Newest Episodes [/COLOR]',custurltv+'new-episodes/',77,'http://s5.postimg.org/xsuir53zb/new.png')
    AddDir('[COLOR white]Latest Added[/COLOR]',custurltv+'latest-added/',75,'http://s5.postimg.org/5rghdfyp3/latest_added.png')
    AddDir('[COLOR white]Search[/COLOR]',custurltv,78,'http://s5.postimg.org/rhpbaq2qv/search.png')
    AddDir('[COLOR white]A-Z[/COLOR]',custurltv+'tv-listings/0-9',82,icon)
  		
    GenresPage = net.http_GET(custurltv+'genres/action').content
    GenresPage = GenresPage.encode('ascii', 'ignore').decode('ascii')
    GenresPage = regex_from_to(GenresPage, '<div class="tv_letter">', '</ul></div>')
    GenresPage = GenresPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

    match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(GenresPage))
		
    for url,name in match:
        name = CLEAN(name)
        AddDir('[COLOR white]'+name+'[/COLOR]',custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")

    xbmc.executebuiltin("Container.SetViewMode(500)")
		
def MusicVideos(url):
    AddFacebookLink()
    MusicAddDir('New Picks', LibDBLink + 'picks',102,"http://s5.postimg.org/xsuir53zb/new.png",'n')
    MusicAddDir('Latest Videos', LibDBLink + 'new',102,"http://s5.postimg.org/5rghdfyp3/latest_added.png",'n')
    MusicAddDir('Genres', LibDBLink + 'genres',103,"http://s5.postimg.org/9rkgllr3b/music_genre.png",'n')
    MusicAddDir('Charts New', LibDBLink + 'charts/new',104,"http://s5.postimg.org/tap1uypuv/music_charts_new.png",'n')
    MusicAddDir('AtoZ Artist', LibDBLink + 'browse/artists/',105,"http://s5.postimg.org/75nbnmtev/atoz.png",'n')
    MusicAddDir('Search', LibDBLink ,108,"http://s5.postimg.org/rhpbaq2qv/search.png",'n')
    
    MusicAddDir(' ', LibDBLink ,0,"http://s5.postimg.org/axkbq16xz/blank.png",'n')
    MusicAddDir(' ', LibDBLink ,0,"http://s5.postimg.org/axkbq16xz/blank.png",'n')
    
    xbmc.executebuiltin("Container.SetViewMode(500)")

def Navi_Playlist(url):
# for individual navi stream only where the listmaker agrees.
    AddFacebookLink()
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    NextPage = FindFirstPattern( PageSource ,"name=>>>\nURL=(.+?)\n")
    print '******************' + str(NextPage)

    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
    all_links = regex_get_all(PageSource, '# ', 'rating')	

    for a in all_links:
        mode = regex_from_to(a, 'type=', '\n')
        title = regex_from_to(a, 'name=', '\n')
        iconimage = regex_from_to(a, 'thumb=', '\n')
        if len(iconimage) < 10:
           iconimage = 'http://icons.iconarchive.com/icons/hopstarter/button/256/Button-Play-icon.png'
        vurl = regex_from_to(a, 'URL=', '\n')
        print title,vurl
        if mode == 'video':
           AddDir(title,vurl,3,iconimage,isFolder=False)
        elif mode == 'playlist':
           AddDir(title,vurl,800,iconimage,isFolder=True)
		   
    if len(NextPage) > 10:   
       AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',NextPage,800,"http://s5.postimg.org/rmlrly3jb/next.png")			
    
    xbmc.executebuiltin("Container.SetViewMode(500)")		
	
def Hybrid_List(url):
    AddFacebookLink()
    data = net.http_GET(url).content
    data = data.encode('ascii', 'ignore').decode('ascii')
    title = 'NA'
    img = ''
    fanart = ''
    list = []
      
    data = data.replace('&nbsp;',' ')
    data = re.sub('>[ \t\n\r\f\v]+<', '><', data)
    data = re.sub('[\t\n\r\f\v]+', '', data)
    data = re.sub('<(\w+)>', '\n<\g<1>>', data)
    data = re.sub('</(\w+)>', '</\g<1>>\n', data)

    data = re.sub('[\n]{2,}', '\n', data)

    lines = data.splitlines()
    line_data = {}
    sublinks = []
	
    import hashlib
        
    for line in lines:  
         line = line.strip()
         if (not line) or ( (line.startswith('<name>') or line.startswith('<title>') or line.startswith('<message>')  or line.startswith('<item>') or line.startswith('<dir>') or line.startswith('<info>') ) and line_data and line_data.get('name', None)):
             if line_data and line_data.get('name', None): 
                 if line_data.get('type', None) and line_data.get('type', None) == 'playlist' and line_data.get('url', None) and not re.search( '.+?[/\\\\]{1}.+?', line_data.get('url', 'dummy')):
                     line_data['type'] = 320
                 if ( line_data.get('url', None) or line_data.get('type', None) == 'info' ) and line_data.get('type', None)   :
                     line_data['fanart'] = fanart
                     list.append(line_data)
                     if (line_data['type'] == 3):
                         AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=False)
                     else:
                         AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=True)
                     line_data = {}
                 elif sublinks:
                     line_data['type'] = 3
                     line_data['fanart'] = fanart
                     for sublink in sublinks:
                         sub_line_data = line_data
                         line_data.update({'url':sublink})
                         line_data['id'] = hashlib.md5(sublink).hexdigest()
                         list.append(line_data.copy())
                         if (line_data['type'] == 3):
                            AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=False)
                         else:
                            AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=True)
                     sublinks = []
                     line_data = {}
             if not line: continue
         
         if line.startswith('<dir>'):
            line_data['type'] = 301
         elif line.startswith('<item>'):
             line_data['type'] = 3
         elif line.startswith('<message>'):
             l_name = re.search('<message>(.*)</message>', line)
             if not l_name: continue
             l_name = l_name.group(1)
             if not l_name: continue
             line_data['name'] = l_name
             line_data['title'] = line_data['name']
             line_data['type'] = 320                
         elif line.startswith('<name>'):
             l_name = re.search('<name>(.*)</name>', line)
             if not l_name: continue
             l_name = l_name.group(1)
             if not l_name: continue
             line_data['name'] = l_name
             line_data['title'] = line_data['name']
             line_data['type'] = 301
         elif line.startswith('<title>'):
             l_name = re.search('<title>(.*)</title>', line)
             if not l_name: continue
             l_name = l_name.group(1)
             if not l_name: continue
             line_data['name'] = l_name
             line_data['title'] = line_data['name']
             line_data['type'] = 3
         elif line.startswith('<link>') and '</link>' in line:
             l_link = re.search('<link>(.*)</link>', line)
             if not l_link: continue
             l_link = l_link.group(1)
             if not l_link: continue
             l_link = l_link.strip()
             if l_link.startswith('<sublink>'):
                  for sublink in re.finditer('<sublink>(.+?)</sublink>', l_link):
                     if not sublink: continue
                     sublink = sublink.group(1)
                     if not sublink: continue                        
                     sublinks.append(sublink)
             else:                    
                 line_data['url'] = l_link
                 line_data['id'] = hashlib.md5(line_data['url'].lower()).hexdigest()
                 if not line_data.get('type', None):
                     if line_data['url'].endswith('.xml'):
                         line_data['type'] = 301
                     else:
                         line_data['type'] = 3
         elif line.startswith('<link>') and '</link>' not in line:
             continue
         elif line.startswith('<sublink>'):            
             for sublink in re.finditer('<sublink>(.+?)</sublink>', line):
                 if not sublink: continue
                 sublink = sublink.group(1)
                 if not sublink: continue
                 sublinks.append(sublink)    
         elif line.startswith('<thumbnail>'):
             l_thumb = re.search('<thumbnail>(.*)</thumbnail>', line)
             if not l_thumb: continue
             line_data['img'] = l_thumb.group(1)
     
    if line_data and line_data.get('name', None): 
         if line_data.get('type', None) and line_data.get('type', None) == 'playlist' and line_data.get('url', None) and not re.search( '.+?[/\\\\]{1}.+?', line_data.get('url', 'dummy')):
             line_data['type'] = 320
         if ( line_data.get('url', None) or line_data.get('type', None) == 'info') and line_data.get('type', None)   :
             line_data['fanart'] = fanart

             if (line_data['type'] == 3):
                 AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=False)
             else:
                 AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=True)

             line_data = {}
         elif sublinks:
             line_data['type'] = 3
             line_data['fanart'] = fanart
             for sublink in sublinks:
                 sub_line_data = line_data
                 line_data.update({'url':sublink})

                 if (line_data['type'] == 3):
                     AddDir(line_data['name'] ,line_data['url'], 3, line_data['img'], isFolder=False)
                 else:
                     AddDir(line_data['name'] ,line_data['url'], line_data['type'], line_data['img'], isFolder=True)

             sublinks = []
             line_data = {}
     
    xbmc.executebuiltin("Container.SetViewMode(500)")	

def Stream247(url):
    BaseURL = 'http://www.stream4free.eu'
    PageSource = net.http_GET(BaseURL+url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    PageSource = regex_from_to(PageSource, '<div class="main-content">', '<footer id="t3-footer"') 
    all_videos = regex_get_all(PageSource, '<a class="article-link"', 'alt="')
    AddFacebookLink()	
    ListCount = 0	
    for a in all_videos:
        vurl = BaseURL + regex_from_to(a, 'href="', '">')
        iconimage = BaseURL + regex_from_to(a, 'src="', '"')
        name = regex_from_to(a, 'img title="', '"')
        AddDir(name,vurl,38,iconimage)
    
    xbmc.executebuiltin("Container.SetViewMode(500)")

def Stream247_Links(name,url,iconimage):
    BaseURL = 'http://www.stream4free.eu'
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    background = BaseURL + regex_from_to(PageSource,'poster="','"')
    PageSource = regex_from_to(PageSource, '<div class="vjs-container-intrinsic-ratio">', '<script>var mypostertimeout') 
    all_videos = regex_get_all(PageSource, '<video id="live_player"', 'type="video/mp4">')
    AddFacebookLink()	
    for a in all_videos:
        vurl = regex_from_to(a, 'src="', '"') + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36'
        AddDir(name,vurl,3,iconimage,isFolder=False, background=background)
		
    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def IPTVHome():
    BaseURL = 'http://www.freeiptvlinks.com/latestiptvlinks/'
    PageSource = net.http_GET(BaseURL).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    PageSource = regex_from_to(PageSource, '<div class="post-content">', '</div> <!-- /post-content -->') 
    all_videos = regex_get_all(PageSource, '<img width="300" height="197" ', '</h4>')
    AddFacebookLink()
    AddDir('[COLOR yellow]LINKS ARE UNTESTED BUT ARE UPDATED DAILY[/COLOR]','BLANK',999,icon)
    AddDir('[COLOR yellow]ADD WORKING LINKS TO YOUR FAVOURITES [/COLOR]','BLANK',999,icon)
    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
    	
    ListCount = 0	
    for a in all_videos:
        vurl = regex_from_to(a, '"><a href="', '" class="')
        iconimage = regex_from_to(a, 'src="', '" class="')
        title = regex_from_to(a, 'target="_blank" >', '</a>')
        AddDir(title,vurl,540,iconimage)
        ListCount = ListCount + 1
        if ListCount > 36:
            break
    
    xbmc.executebuiltin("Container.SetViewMode(50)")
			
def IPTVList(url):
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    iconimage = regex_from_to(PageSource ,'<img width="304" height="200" src="','" class="attachment-post-image wp-post-image"')
    if len(iconimage) < 10:
       iconimage = icon  
	   
    PageSource = regex_from_to(PageSource, '<div class="post-content">', '<div style="padding-bottom:20px') 
    PageSource = PageSource.replace('HTTP:','http:').replace('RTMP:','rtmp:').replace('RTME:','rtme:').replace('<P>','<p>').replace('<BR','<br')

    PageSource = PageSource.replace('<p>','\n').replace('</p>','\n').replace('<br />','\n').replace('rtmp://$OPT:rtmp-raw=','')
    all_lines = regex_get_all(PageSource, '\n', '\n')
    
    AddFacebookLink()
    AddDir('[COLOR yellow]LINKS UPDATED DAILY[/COLOR]','BLANK',999,icon)
    AddDir('[COLOR yellow]ADD WORKING LINKS TO YOUR FAVOURITES [/COLOR]','BLANK',999,icon)
    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
    BuiltList = ''
    ListCount = 0
    for Thisline in all_lines:
        Line = ''
        if Thisline.find('EXTINF') > 0: 
           Line = '\n'+ Thisline.strip()
        elif Thisline.find('rtme:') > 0 or Thisline.find('rtmp:') > 0 or Thisline.find('http:') > 0 or Thisline.find('mms:') > 0 or Thisline.find('mmsh:') > 0:
             Line = '\n'+ Thisline.strip()
        elif len(Thisline) > 7:
            Line = 	'\n#EXTINF:-1,' + Thisline.strip()
        if len(Line) > 12:
            BuiltList = BuiltList + Line

    BuiltList = BuiltList.replace('#AAASTREAM:','#A:').replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(BuiltList)

    ListCount = 0
    for params, name, url in matches:
        ListCount = ListCount + 1
        AddDir('[COLOR lime]'+name+'[/COLOR]',url, 3, iconimage,isFolder=False)

    if ListCount == 0:
	   AddDir('[COLOR red]SORRY NO WORKING LINKS HERE TRY ANOTHER SECTION[/COLOR]','BLANK',999,'http://s5.postimg.org/sp2sjkbxj/underconstruction.png')

    xbmc.executebuiltin("Container.SetViewMode(50)")	

def TheBigList_category():
    PageSource = net.http_GET('http://www.iptvshqip.net/').content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    AddFacebookLink() 
    AddDir('[COLOR yellow]TUX LINKS ARE UNTESTED BUT ARE UPDATED DAILY[/COLOR]','BLANK',999,icon)
    AddDir('[COLOR yellow]ADD WORKING LINKS TO YOUR FAVOURITES [/COLOR]','BLANK',999,icon)
    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
	   
    all_videos = regex_get_all(PageSource, '<li class="cat-item cat-item', '</li>') 
    ListCount = 0	
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="', '"')
        iconimage = 'http://s5.postimg.org/wtyg90dt3/biglist.png'
        title = regex_from_to(a, '/" >', '</a>')
        title = title.replace('&lt;','<').replace('&gt;','>').replace('&#8221;','"').replace('&#8243;','"').replace('&#038;','&').replace('&#8211;','--').replace('&#215;','x')
        if len(title) > 1:
           AddDir("[COLOR lime][B]" + title + "[/B][/COLOR]"  ,vurl,710,iconimage)
        ListCount = ListCount + 1
        if ListCount > 100:
            break
    
    xbmc.executebuiltin("Container.SetViewMode(50)")

def TheBigList_page(url):
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    AddFacebookLink()   
    AddDir('[COLOR yellow]TUX LINKS ARE UNTESTED BUT ARE UPDATED DAILY[/COLOR]','BLANK',999,icon)
    AddDir('[COLOR yellow]ADD WORKING LINKS TO YOUR FAVOURITES [/COLOR]','BLANK',999,icon)
    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
		   
    all_videos = regex_get_all(PageSource, '<div class="thumbnail">', 'class="attachment-defaultthumb') 
    ListCount = 0	
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="', '"')
        iconimage = regex_from_to(a, 'src="', '"')
        title = regex_from_to(a, ' title="', '"')
        title = title.replace('&lt;','<').replace('&gt;','>').replace('&#8221;','"').replace('&#8243;','"').replace('&#038;','&').replace('&#8211;','--').replace('&#215;','x')
        if len(title) > 1:
           AddDir("[COLOR lime][B]" + title + "[/B][/COLOR]"  ,vurl,720,iconimage)
        ListCount = ListCount + 1
        if ListCount > 100:
            break

    xbmc.executebuiltin("Container.SetViewMode(50)")		

def TheBigList_lines(url,iconimage):
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')

    AddFacebookLink()   
    AddDir('[COLOR yellow]TUX LINKS ARE UNTESTED BUT ARE UPDATED DAILY[/COLOR]','BLANK',999,icon)
    AddDir('[COLOR yellow]ADD WORKING LINKS TO YOUR FAVOURITES [/COLOR]','BLANK',999,icon)
    AddDir("[COLOR white][B]FAVOURITE STREAMS[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png")
	
    BuiltList = ''
    ListCount = 0	
    PageSource = regex_from_to(PageSource, '<div class="entry clearfix">', '<div class="fcbk_button"')
    PageSource = PageSource.replace('#EXTINF','#extinf').replace('<P>','<p>').replace('</P>','</p>').replace('<BR />','<br />')
    PageSource = PageSource.replace('#extinf','\n#extinf').replace('<p>','\n').replace('</p>','\n').replace('<br />','\n').replace('rtmp://$OPT:rtmp-raw=','')
    #print PageSource
    all_lines = regex_get_all(PageSource, '\n', '\n')
    for Thisline in all_lines:
        Line = ''
        if Thisline.find('extinf') > 0: 
           Thisline = Thisline.replace('&lt;','<').replace('&gt;','>').replace('&#8221;','"').replace('&#8243;','"').replace('&#038;','&').replace('&#8211;','--').replace('&#215;','x')
           Line = '\n'+ Thisline.strip()
        elif Thisline.find('rtme:') > 0 or Thisline.find('rtmp:') > 0 or Thisline.find('http:') > 0 or Thisline.find('mms:') > 0 or Thisline.find('mmsh:') > 0:
             Line = '\n'+ Thisline.strip()
        elif len(Thisline) > 7:
            Line = 	'\n#extinf:-1,' + Thisline.strip()
        if len(Line) > 12 and Line.find('<div>') < 1 and Line.find('</div>') < 1 and Line.find('script>') < 1 and Line.find('dynamicgoogletags') < 1 and Line.find('####') < 1 and Line.find('????') < 1 and Line.find('#extgrp') < 1:
            BuiltList = BuiltList + Line
    #print BuiltList
    BuiltList = BuiltList.replace('#AAASTREAM:','#A:').replace('#EXTINF:','#A:').replace('#extinf:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(BuiltList)

    for params, name, url in matches:
        AddDir('[COLOR gold]'+name.upper()+'[/COLOR]',url, 3, iconimage,isFolder=False)
		
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmc.executebuiltin("Container.SetViewMode(50)")
	
		
def x1Channels(url):
    url = "http://mobile.desistreams.tv/DesiStreams"+url
    AddFacebookLink()
    try: 
        links = net.http_GET(url).content
    except:
        AddDir('[COLOR red]SECTION UNDER MAINTENANCE PLEASE TRY AGAIN SHORTLY[/COLOR]','BLANK',999,'http://s5.postimg.org/sp2sjkbxj/underconstruction.png')
        ##AddDir('[COLOR yellow]GO TO FACEBOOK.COM/AAASTREAM   FOR MORE INFORMATION[/COLOR]','BLANK',999,'http://s5.postimg.org/sp2sjkbxj/underconstruction.png')
        xbmc.executebuiltin("Container.SetViewMode(50)")
        return

    AddDir('[COLOR gold]** LINKS NOT WORKING? RELOAD THE LIST **[/COLOR]','Findus',0,icon)
    AddDir('[COLOR gold]** LINKS HERE CANNOT BE USED IN FAVOURITES **[/COLOR]','Findus',0,icon)
	
    links = links.replace('\/','/')
    Mainurl = 'http://mobile.desistreams.tv/'
    
    all_videos = regex_get_all(links, '{"id"', '}')
    for a in all_videos:
        mode = 3
        url = regex_from_to(a, '"stream_url":"', '"')
        name = regex_from_to(a, 'name":"', '"')
        icon = regex_from_to(a, '"img":"', '",')
        AddDir('[COLOR blue] '+name+' [/COLOR] Source 1' ,url, mode, Mainurl+icon, isFolder=False)
        url = regex_from_to(a, '"stream_url2":"', '"')
        name = regex_from_to(a, 'name":"', '"')
        icon = regex_from_to(a, '"img":"', '",')
        AddDir('[COLOR blue] '+name+'[/COLOR] Source 2' ,url, mode, Mainurl+icon, isFolder=False)
        url = regex_from_to(a, '"stream_url3":"', '"')
        name = regex_from_to(a, 'name":"', '"')
        icon = regex_from_to(a, '"img":"', '",')
        AddDir('[COLOR blue] '+name+'[/COLOR] Source 3' ,url, mode, Mainurl+icon, isFolder=False)
    
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmc.executebuiltin("Container.SetViewMode(50)")
	
def UFCSection(url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
	
    nextpage = ''
    if link.find('rel="next') > 0:
       nextpage = regex_from_to(link, '<link rel="next" href="//', '"/>')
	   
    link = regex_from_to(link, '<div class="nag cf">', '<div class="loop-nav pag-nav">') 
    all_videos = regex_get_all(link, '<div id="post', '<span class="overlay"></span>')
    for a in all_videos:
        title = regex_from_to(a, ' title="', '"')
        vurl = regex_from_to(a, ' href="', '"')
        iconimage = "http://" + regex_from_to(a, '<img src="//', '" alt=')
        AddDir(title,vurl,15,iconimage)

    if len(nextpage) > 0:
       nextpage = 'http://' + nextpage
       AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',nextpage,9,"http://s5.postimg.org/rmlrly3jb/next.png")

    xbmc.executebuiltin("Container.SetViewMode(500)")

def VodlockerxScrape(url):
    Base_URL = 'http://www.vodlockerx.com/' + url
  
    link = net.http_GET(Base_URL).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    AddFacebookLink()
    
    NextPage = FindFirstPattern(Base_URL, '/date/(.+?)')
    if len(NextPage) > 0:
	    NextPage = str(int(NextPage) + 1)
    else:
        NextPage = 2
		
    count = 0
    all_videos = regex_get_all(link, '<div class="item" style="text-align:center">', 'alt=" " style="width:130px;height:190px;background-color: #717171;"/>')
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="http://www.vodlockerx.com/', '" class="spec-border-ie" title="">')
        name = vurl.replace('-',' ').upper().replace('MOVIE/',' ').upper()
        iconimage = regex_from_to(a, 'src="', '"')
        vurl = 'http://www.vodlockerx.com/' + vurl
        count = count + 1
        AddDir('[B][COLOR yellow]'+name+'[/COLOR][/B]',vurl,240,iconimage)
    
    if count == 42:
       AddDir('[B][COLOR pink]Next Page[/COLOR][/B]', url + '/date/' + str(NextPage) ,230,'http://s5.postimg.org/rmlrly3jb/next.png')

    xbmc.executebuiltin("Container.SetViewMode(500)")	
	
def VodlockerxSources(name,url,iconimage):

    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')

    AddFacebookLink()
    link = regex_from_to(link, '<div class="breakaway-wrapper" id="video-pages-wrapper">', '<textarea id="problem"></textarea>')

    count = 0
    all_videos = regex_get_all(link, '<ul class="filter"', 'Play Now</a></li>')
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="', '" target="_blank">')
        if vurl.find('idownloadplay') < 1:
           count = count + 1
           AddDir(name + '[COLOR lime] Source:' + str(count)+  '[/COLOR]',vurl,3,iconimage,isFolder=False)
    
    if count == 0:
       AddDir('[B][COLOR red]UPDATING PLEASE CHECK LATER [/COLOR][/B]', ' ',999,'http://s5.postimg.org/rmlrly3jb/next.png')

    xbmc.executebuiltin("Container.SetViewMode(50)")	
	
	
def UFCScrape(url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    iconimage = regex_from_to(link, '<meta name="twitter:image:src" content="', '"/>') 
    link = regex_from_to(link, '<div class="entry-content rich-content">', '<div id="extras">') 
    all_videos = regex_get_all(link, '<a class="small cool-blue vision-button"', '</a>')
 
    c=0
    for a in all_videos:
        vurl = regex_from_to(a, 'button" href="', '" target="')
        c=c+1
        title = "[COLOR gold] Source ["+str(c)+"] [/COLOR]" + regex_from_to(a, 'blank">', '</a>')
 #       xbmcgui.Dialog().ok(str(title), vurl)
        AddDir(title,vurl,16,iconimage)

def StreamUFC(name,url,thumb):
    name2 = name
    url2 = url
              
    print url
    if re.search('http://pwtalk.net', url):
       headers['Referer'] = "http://watchwrestling.ch/"
       url_content = net.http_GET(url, headers=headers).content
       url_content = re.sub("<!--.+?-->", " ", url_content)
       link2 = regex_from_to(url_content, '<iframe ', '<') 
       url = regex_from_to(link2, 'src="', '">')
       print url   
			
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        addLinkMovies(name2,streamlink,thumb)
    except:
        Notify('small','MaaaDstream Sorry Link Removed:', 'Please try another one.',9000)
		   
def AddFacebookLink():
    AddDir(DirectoryMSG,FacebookLink, 60, "http://s5.postimg.org/7hz1vjzaf/facebook.png", isFolder=False)
	

def PlayVimeo(url):
#Thanks to lambda for this
    url = 'http://player.vimeo.com/video/'+url+'/config'
    try: 
        link = net.http_GET(url).content
        link = link.encode('ascii', 'ignore').decode('ascii')
        link = json.loads(link)
        u = link['request']['files']['h264']
        url = None
        try: url = u['hd']['url']
        except: pass
        try: url = u['sd']['url']
        except: pass
        Playurl = "PlayMedia("+url+")"
        xbmc.executebuiltin(Playurl)
    except: pass
	
		
def PlayYoutubeView(url):
    try:
        url = "PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid="+url+")"
        xbmc.executebuiltin(url)
    except:
        xbmc.executebuiltin("XBMC.Notification(MaaaDstream STREAM,This host is not supported or resolver is broken::,10000)")

def EVO_Private():
    EVOFile = os.path.join(libDir,"EVOLocation.txt")
    if not (os.path.isfile(EVOFile)):
        xbmcgui.Dialog().ok('EVO LINK', 'No Link Entered - Please enter EVO LINK First')	
        return
		
    try:
        f = open(EVOFile,'r')
        EVOLink = f.read()
        EVOLink = regex_from_to(EVOLink, '{', '}')
        f.close()
    except:
        xbmcgui.Dialog().ok('EVO LINK', 'No Link Entered - Please enter EVO LINK First')
        return

    StreamlistURL = ''
    if EVOLink[:4].lower() == "evo-":
        StreamlistURL = EvoUrl
    elif EVOLink[:5].lower() == "chin-":
        StreamlistURL = ChinaServer
    else:
        StreamlistURL = Raw
	   
    links = ''
    try:
        links = net.http_GET(StreamlistURL + EVOLink).content
    except:
        xbmcgui.Dialog().ok('EVO LINK', 'ERROR WITH THE EVO LINK PLEASE CHECK')
        return
		
    links = links.encode('ascii', 'ignore').decode('ascii')
    links = links.replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
    links = links.replace('<a href="','').replace('</a>&#8220;#','"')
    if links.find('<link>') > 0:
        XMLRead500(EVOLink)
    else:
        if links.find('I:"') > 0:
            StreamsList(EVOLink)
        else:
            StreamM3U(EVOLink)
	

	   
def StreamsList(url):
    links = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*OFFSHORE DOWN*[/B][/COLOR]" C:icon'
    StreamlistURL = ''
    if url[:4].lower() == "evo-":
        StreamlistURL = EvoUrl
    elif url[:5].lower() == "chin-":
        StreamlistURL = ChinaServer
    else:
        StreamlistURL = Raw
		
    try: links = net.http_GET(StreamlistURL + url).content
    except: pass
    links = links.encode('ascii', 'ignore').decode('ascii')
	
    if url[:4].lower() == "evo-":
       links = links.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\r\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
       links = links.replace('<a href="','').replace('</a>&#8220;#','"')	   
    SetViewLayout = "50"

    LayoutType = re.compile('FORMAT"(.+?)"').findall(links)
    if LayoutType:
       SetViewLayout = str(LayoutType)
       SetViewLayout = SetViewLayout.replace('[u\'','').replace(']','').replace('\'','')
 	
    AddFacebookLink()
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        url = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')
        if mode == '60' or mode == '3' or mode == '61': 
            AddDir('[COLOR lime]'+name+'[/COLOR]',url, mode, icon,isFolder=False)
        else:
            nono = 'DWc162SS'
            if nono not in url:
                name = name.replace('AAASTREAMS SPORTS','[B]MaaaDstream COPIED PLAYLISTS[/B]')   
                AddDir('[COLOR lime]'+name+'[/COLOR]',url, mode, icon)
    xbmc.executebuiltin("Container.SetViewMode("+str(SetViewLayout)+")")
	
def StreamM3U(url):
    links = '#A:-1,INVALID LIST \r\n http://youtube.com'
    StreamlistURL = ''
    if url[:4].lower() == "evo-":
        StreamlistURL = EvoUrl
    elif url[:5].lower() == "chin-":
        StreamlistURL = ChinaServer
    else:
        StreamlistURL = Raw
 
    try: links = net.http_GET(StreamlistURL + url).content
    except: pass
    
    links = links.encode('ascii', 'ignore').decode('ascii')
	
    if url[:4].lower() == "evo-":
        links = links.replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
        links = links.replace('<a href="','').replace('</a>&#8220;#','"')
      
    SetViewLayout = "50"
     
    LayoutType = re.compile('FORMAT"(.+?)"').findall(links)
    if LayoutType:
       SetViewLayout = str(LayoutType)
       SetViewLayout = SetViewLayout.replace('[u\'','').replace(']','').replace('\'','')
	   
    links = links.replace('#AAASTREAM:','#A:').replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(links)

    for params, name, url in matches:
        item_param = params
#        if ChildLockStatus <> 'ON':
        print '***********   ' + str(url) + '   ************'
        AddDir('[COLOR lime]'+name+'[/COLOR]',url, 3, icon,isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode("+str(SetViewLayout)+")")
	
def LockedIndex(url):
    links = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*OFFSHORE DOWN*[/B][/COLOR]" C:icon'
    StreamlistURL = ''
    if url[:4].lower() == "evo-":
       StreamlistURL = EvoUrl
    else:
	   StreamlistURL = ChinaServer
	
    try: links = net.http_GET(StreamlistURL + url).content
    except: pass
    links = links.encode('ascii', 'ignore').decode('ascii')
	
    if url[:4].lower() == "evo-":
       links = links.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\r\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
       links = links.replace('<a href="','').replace('</a>&#8220;#','"')
	   
    SetViewLayout = "50"
     
    LayoutType = re.compile('FORMAT"(.+?)"').findall(links)
    if LayoutType:
       SetViewLayout = str(LayoutType)
       SetViewLayout = SetViewLayout.replace('[u\'','').replace(']','').replace('\'','')
	   
    AddFacebookLink()
    if ChildLockStatus == 'OFF':
       AddDir('[COLOR green][B]ChildLock is OFF[/B][/COLOR] Click here to Activate' ,"Childlock",400,"http://s5.postimg.org/o7qg63yw7/childlock.png",isFolder=False)  
    else:
       AddDir('[COLOR red][B]ChildLock is ON[/B][/COLOR] Click here to Deactivate' ,"Childlock",400,"http://s5.postimg.org/o7qg63yw7/childlock.png",isFolder=False)  
	
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        url = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')
        if ChildLockStatus == 'OFF':
           AddDir('[COLOR lime]'+name+'[/COLOR]',url, mode, icon)
				
    xbmc.executebuiltin("Container.SetViewMode("+str(SetViewLayout)+")")

def ChildLock():
#h@k@m@c
    pwd = ''	
    KeyboardMessage = 'Type Password to deactivate Childlock (case sensitive)'
    ChildLockFile = os.path.join(libDir,"childlock.txt")
    try:
        f = open(ChildLockFile,'r')
        pwd = f.read()
        pwd = regex_from_to(pwd, '{', '}')
        f.close()
    except:
        pwd = ""
        KeyboardMessage = 'Type Password to Activate Childlock (case sensitive)'
	
    passwordEntered = ''
    keyboard = xbmc.Keyboard(passwordEntered, KeyboardMessage)
    keyboard.doModal()
    if keyboard.isConfirmed():
       passwordEntered = keyboard.getText() .replace(' ','+')
       if passwordEntered == None:
          return False
	
    if len(passwordEntered) == 0: 
        xbmcgui.Dialog().ok('MaaaDstream Childlock', 'No Password entered. No action taken')
        return	   
    else:
        xbmcgui.Dialog().ok('MaaaDstream Childlock', 'Password Entered: '+passwordEntered)
	   
    if len(passwordEntered) > 0 and pwd =='':
        try:
            f = open(ChildLockFile, 'w') 
            f.write('{'+passwordEntered+'}') 
            f.close()
            ChildLockStatus == 'ON'
            xbmcgui.Dialog().ok('MaaaDstream Childlock', 'Childlock Activation Successful', 'Return to MaaaDstream Home Page')			
        except:
            ChildLockStatus == 'OFF'
            xbmcgui.Dialog().ok('MaaaDstream Childlock', 'Childlock Activation Failed', 'Exit Afterdark & Return')

    if len(passwordEntered) > 0 and pwd == passwordEntered:	
        try:
            os.remove(ChildLockFile)
            xbmcgui.Dialog().ok('MaaaDstream Childlock', 'ChildLock removed', 'Return to MaaaDstream Home Page')
        except:
            xbmcgui.Dialog().ok('MaaaDstream Childlock', 'Cannot remove childlock', 'Reboot and try again')  
	   
    if len(passwordEntered) > 0 and pwd <> passwordEntered and len(pwd) > 0:
       xbmcgui.Dialog().ok('MaaaDstream Childlock', 'Password incorrect Childlock still active')

def EVO_Link():
#h@k@m@c
    EVOLink = ''	
    KeyboardMessage = 'Enter Your EVO Link (evo-xxxx)'
    EVOFile = os.path.join(libDir,"EVOLocation.txt")
	
    keyboard = xbmc.Keyboard(EVOLink, KeyboardMessage)
    keyboard.doModal()
    if keyboard.isConfirmed():
       EVOLink = keyboard.getText() .replace(' ','+')
       if EVOLink == None:
          return False
	
    if len(EVOLink) == 0: 
        xbmcgui.Dialog().ok('MaaaDstreamStream EVO', 'No Link Entered. No action taken')
        return	   

    if len(EVOLink) > 0:
        if os.path.isfile(EVOFile):
            os.remove(EVOFile)
        try:
            f = open(EVOFile, 'w') 
            f.write('{'+EVOLink+'}') 
            f.close()
        except:
            pass

    AddDir('EVO LINK SET: '+EVOLink ,'evoindex', 7, "http://s5.postimg.org/pppqafk9z/unlockaccount.png", isFolder=True)

def Xham_Cats(url):
    Xham_Category = url
    PageSource = net.http_GET('http://xhamster.com/channels.php').content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    PageSource = PageSource.replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

    iconimage = ''
	
    if Xham_Category == 'Straight':
       PageSource = regex_from_to(PageSource,'<div class="title">Straight</div>', '<div class="catName">') 
       iconimage = 'http://s13.postimg.org/h0ioz9kk7/straight.png'
    elif Xham_Category == 'Gays':
       PageSource = regex_from_to(PageSource,'<div class="title">Gays</div>', '<div id="footer">')
       iconimage = 'http://s3.postimg.org/x6qcgvisz/gay.png'
    else:
       PageSource = regex_from_to(PageSource,'<div class="title">Transsexuals</div>', '<div class="catName">')
       iconimage = 'http://s23.postimg.org/y3sy9ak0r/transsexual.png'

    all_links = regex_get_all(PageSource, '<a class="btnBig" href="', '</a>')
    AddFacebookLink()
    for a in all_links:
        vurl = regex_from_to(a, '<a class="btnBig" href="', '">')
        name = regex_from_to(a, '     ', '</a>')
        
        if name.find('div>') > 0:
           name = name[name.find('div>')+4:]
        name = name.strip().upper()
        title = '[COLOR gold]'+ name +'[/COLOR]'
        
        AddDir(title,vurl,610,iconimage)
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )		
    xbmc.executebuiltin("Container.SetViewMode(50)")

def Xham_FindLinks(url):
    try:
	    PageSource = net.http_GET(url).content
    except:
        return
		
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')

    NextPage = FindFirstPattern( PageSource ,"</a><a href='/channels/([^\&]+)' class='last") + "#'>"
    all_NextPages = regex_get_all(NextPage, "</a><a href='", "'>")

    PageSource = regex_from_to(PageSource,"id='vListTop'>", "<div id='adBottom'>")
    PageSource = PageSource.replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

    all_links = regex_get_all(PageSource, '<div class=video>', '</div>')
    AddFacebookLink()
    for a in all_links:
        vurl = regex_from_to(a, '<a href=', '  ')
        name = regex_from_to(a, 'alt="', '"')
        iconimage = regex_from_to(a, 'class=hRotator ><img src=', ' ')
        if len(iconimage) < 5:
           iconimage = 'http://s23.postimg.org/5pvk434rv/adultmovies.png'
        name = name.strip()
        title = '[COLOR gold]'+ name +'[/COLOR]'
        url = Xham_Stream(vurl)
        AddDir(title,url,3,iconimage,isFolder=False)
		
    if len(NextPage) > 0:
        for a in all_NextPages:
            if a.find('#') > 0:
               url = regex_from_to(a, "<a href='", "#'>")
               url = 'http://xhamster.com' + url
               AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url,610,"http://s5.postimg.org/rmlrly3jb/next.png")

    xbmc.executebuiltin("Container.SetViewMode(500)")
			   
def Xham_Stream(url):
    PageSource = net.http_GET(url).content
    PageSource = PageSource.encode('ascii', 'ignore').decode('ascii')
    Link = regex_from_to(PageSource,"type='video/mp4' file=", '"')
    Link = Link[1:]
    url = Link
    return url
 #   xbmcgui.Dialog().ok(str('top'), Link)       

	
def XMLRead500(url):
    icon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.MaaaDstream/icon.png'))
    StreamlistURL = ''
    if url[:4].lower() == "evo-":
        StreamlistURL = EvoUrl
    elif url[:5].lower() == "chin-":
        StreamlistURL = ChinaServer
    else:
        StreamlistURL = Raw
		
    try: links = net.http_GET(StreamlistURL + url).content
    except: return
	
    links = links.encode('ascii', 'ignore').decode('ascii')
	
    if url[:4].lower() == "evo-":
       links = links.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('<name>','<title>').replace('</name>','</title>').replace('</p>','\r\n').replace('&nbsp;','').replace('&#8221;','"').replace('&#8243;','"').replace('<!-- EVO LINK','\n').replace('END EVO -->','').replace('<p>','').replace('&#038;','&').replace('&#8211;','--').replace('<br />','').replace('&#215;','x')
       links = links.replace('<a href="','').replace('</a>&#8220;#','"')	   
	   
    SetViewLayout = "50"
     
    LayoutType = re.compile('FORMAT"(.+?)"').findall(links)
    if LayoutType:
       SetViewLayout = str(LayoutType)
       SetViewLayout = SetViewLayout.replace('[u\'','').replace(']','').replace('\'','')
    
    AddFacebookLink()
    links = links.encode('ascii', 'ignore').decode('ascii')	
	
    all_videos = regex_get_all(links, 'I:', '"#')
    for a in all_videos:
        mode = regex_from_to(a, 'I:"', '"')
        vurl = regex_from_to(a, 'A:"', '"')
        name = regex_from_to(a, 'B:"', '"')
        icon = regex_from_to(a, 'C:"', '"')

        AddDir('[COLOR lime]'+name+'[/COLOR]',vurl, mode, icon)
		   
    
    all_videos = regex_get_all(links, '<item>', '</item>')
    for a in all_videos:
        background = ''
        vurl = regex_from_to(a, '<link>', '</link>').replace('  ', ' ')
        name = regex_from_to(a, '<title>', '</title>')
        icon = regex_from_to(a, '<thumbnail>', '</thumbnail>')
        background = regex_from_to(a, '<fanart>', '</fanart>')
        if len(background) < 5:
            background = icon

        AddDir('[COLOR lime]'+name+'[/COLOR]',vurl, 3, icon,isFolder=False, background=background)
    list = common.m3u2list(StreamlistURL + url)
    for channel in list:
        name = common.GetEncodeString(channel["display_name"])
        mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3

        AddDir(name ,channel["url"], mode, icon, isFolder=False)
		
    xbmc.executebuiltin("Container.SetViewMode("+str(SetViewLayout)+")")	
		
def YouTube_List(url): 
# H@k@M@c
    url = 'https://www.youtube.com/user/' + url + '/videos'
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
 
    AddFacebookLink()
    all_videos = regex_get_all(link, '<h3 class="yt-lockup-title">', '</span></h3>')
    for a in all_videos:
        name = regex_from_to(a, 'title="', '"').replace("&amp;","&")
        video_id = regex_from_to(a, 'href="', '"').replace("&amp;","&")
        video_id = video_id[9:]
        icon = 'http://i.ytimg.com/vi/' + str(video_id) + '/mqdefault.jpg'
        AddDir(name , video_id, 60, icon, isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(500)")

def FindFirstPattern(text,pattern):
    result = ""
    try:    
        matches = re.findall(pattern,text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result
	
def Highlights():
        link = net.http_GET('http://doctortips.net/wss/footballhighlights.html').content
        link = link.encode('ascii', 'ignore').decode('ascii')
        match=re.compile('<a href="(.+?)">(.+?)</a></div>').findall(link)
        for url, name in match:
                AddDir(name,url,156,"http://s5.postimg.org/vr0ijo3mv/fullmatches.png")


def PlayHighlights(name,url):
    ok=True
    try:
      liz=xbmcgui.ListItem(name, "http://s5.postimg.org/vr0ijo3mv/fullmatches.png","http://s5.postimg.org/vr0ijo3mv/fullmatches.png"); liz.setInfo( type="Video", infoLabels={ "Title": name } )
      ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
      xbmc.Player ().play(url, liz, False)
    except:pass

    return ok
				
def FullMatches(url):
    custurlreplay = str(base64.decodestring(LocalisedReplay))
    link = net.http_GET(custurlreplay+url).content
    link = link.encode('ascii', 'ignore').decode('ascii')

    r='<div class="cover"><a href="(.+?)" rel="bookmark" title="(.+?)">.+?<img src="(.+?)".+?<p class="postmetadata longdate" rel=".+?">(.+?)/(.+?)/(.+?)</p>'
    match=re.compile(r,re.DOTALL).findall(link)
    AddFacebookLink()
    for vurl,name,iconimage,month,day,year in match:
        _date='%s/%s/%s'%(day,month,year)  
        name='%s-[COLOR gold][%s][/COLOR]'%(name,_date)    
        AddDir(name,vurl,152,iconimage)
    
    nextpage=re.compile('</span><a class="page larger" href="(.+?)">').findall(link)
    if nextpage:
       vurl = str(nextpage)
       vurl = vurl.replace('[u\'','')
       vurl = vurl.replace(']','')
       vurl = vurl.replace('\'','')
       AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',vurl,151,"http://s5.postimg.org/rmlrly3jb/next.png")

    xbmc.executebuiltin("Container.SetViewMode(500)")	

def SearchReplays():
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Search MaaaDstream Replays')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() .replace(' ','+')
            if search_entered == None:
                return False
        link=OPEN_MAGIC('http://www.google.com/cse?cx=partner-pub-9069051203647610:8413886168&ie=UTF-8&q=%s&sa=Search&ref=livefootballvideo.com/highlights'%search_entered)
        match=re.compile('" href="(.+?)" onmousedown=".+?">(.+?)</a>').findall(link)
        for url,dirtyname in match: 
            import HTMLParser
            cleanname= HTMLParser.HTMLParser().unescape(dirtyname)
            name= cleanname.replace('<b>','').replace('</b>','')
            AddDir(name,url,152,'')
        xbmc.executebuiltin("Container.SetViewMode(50)")	 
		
def REPLAYSGETLINKS(name,url):#  cause mode is empty in this one it will go back to first directory
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    AddFacebookLink()
    if "proxy.link=lfv*" in link :
        import decrypter
        match = re.compile('proxy\.link=lfv\*(.+?)&').findall(link)
        match = uniqueList(match)
        match = [decrypter.decrypter(198,128).decrypt(i,base64.urlsafe_b64decode('Y0ZNSENPOUhQeHdXbkR4cWJQVlU='),'ECB').split('\0')[0] for i in match]
        print match
        for url in match:

            url = replaceHTMLCodes(url)
            if url.startswith('//') : url = 'http:' + url
            url = url.encode('utf-8')  
            _name=url.split('://')[1] 
            _name=_name.split('/')[0].upper()
            ReplaysAddDir( name+' - [COLOR red]%s[/COLOR]'%_name , url , 120 , icon , '' )
    if "www.youtube.com/embed/" in link :
        r = 'youtube.com/embed/(.+?)"'
        match = re.compile(r,re.DOTALL).findall(link)
        yt= match[0]
        iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % yt.replace('?rel=0','')
        url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % yt.replace('?rel=0','')
        ReplaysAddDir( name+' - [COLOR red]YOUTUBE[/COLOR]' , url , 120 , iconimage , '' )
    if "dailymotion.com" in link :
        r = 'src="http://www.dailymotion.com/embed/video/(.+?)\?.+?"></iframe>'
        match = re.compile(r,re.DOTALL).findall(link)
        for url in match :
            ReplaysAddDir ( name+' - [COLOR red]DAILYMOTION[/COLOR]' , url , 120 , icon, '' )
    if "http://videa" in link :
        r = 'http://videa.+?v=(.+?)"'
        match = re.compile(r,re.DOTALL).findall(link)
        for url in match :
            ReplaysAddDir (name+' - [COLOR red]VIDEA[/COLOR]',url,120,icon, '' )
            
    if "rutube.ru" in link :
        r = 'ttp://rutube.ru/video/embed/(.+?)\?'
        match = re.compile(r,re.DOTALL).findall(link)
        print match
        for url in match :
            ReplaysAddDir (name+' - [COLOR red]RUTUBE[/COLOR]',url,120,icon, '' )
    if 'cdn.playwire.com' in link :
        r = 'cdn.playwire.com/bolt/js/embed.min.js.+?data-publisher-id="(.+?)".+?data-config="(.+?)">'
        match = re.compile(r,re.DOTALL).findall(link)
        for id ,vid in match :
            
            url=vid.replace('player.json','manifest.f4m')
            ReplaysAddDir (name+' - [COLOR red]PLAYWIRE[/COLOR]',url,120,icon, '' )
    if "vk.com" in link :
        r = '<iframe src="http://vk.com/(.+?)"'
        match = re.compile(r,re.DOTALL).findall(link)
        for url in match :
            ReplaysAddDir (name+' - [COLOR red]VK.COM[/COLOR]','http://vk.com/'+url,120,icon, '' )
    if "mail.ru" in link :
        r = 'http://videoapi.my.mail.ru/videos/embed/(.+?)\.html'
        match = re.compile(r,re.DOTALL).findall(link)
        for url in match :
            ReplaysAddDir (name+' - [COLOR red]MAIL.RU[/COLOR]','http://videoapi.my.mail.ru/videos/%s.json'%url,120,icon, '' )            
          

def PLAYSTREAM(name,url,iconimage):
        if 'YOUTUBE' in name:
            link = str(url)
        elif 'VIDEA' in name:
            try:
                url=url.split('-')[1]
            except:
                url=url
            link = GrabVidea(url)
        elif 'VK.COM' in name:
            link = GrabVK(url)

        elif 'MAIL.RU' in name:
            link = GrabMailRu(url)

            
        elif 'RUTUBE' in name:
            try:
                html = 'http://rutube.ru/api/play/trackinfo/%s/?format=xml'% url.replace('_ru','')
                print html
#                link = OPEN_URL(html)
                link = net.http_GET(html).content
                r = '<m3u8>(.+?)</m3u8>'
                match = re.compile(r,re.DOTALL).findall(link)
                if match:
                    link=match[0]
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Football Replays", '','Sorry Video Is Private', '')
                    return
            except:
                dialog = xbmcgui.Dialog()
                dialog.ok("Football Replays", '','Sorry Video Is Private', '')
                return
        elif 'PLAYWIRE' in name:
            link = net.http_GET(url).content
 #           link = OPEN_URL(url)
            r = '<baseURL>(.+?)</baseURL>.+?media url="(.+?)"'
            match = re.compile(r,re.DOTALL).findall(link)
            if match:
                link=match[0][0]+'/'+match[0][1]
                
                
        elif 'DAILYMOTION' in name:
            try:
                url = url.split('video/')[1]
            except:
                url = url
            link = getStreamUrl(url)
        try:
            liz=xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name} )
            liz.setProperty("IsPlayable","true")
            liz.setPath(link)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except:pass
        
 
def GrabMailRu(url):
    print 'RESOLVING VIDEO.MAIL.RU VIDEO API LINK'
      
    items = []
    quality = "???"
    data = getData(url)
    cookie = net.get_cookies()
    for x in cookie:

         for y in cookie[x]:

              for z in cookie[x][y]:
                   
                   l= (cookie[x][y][z])
    name=[]
    url=[]
    r = '"key":"(.+?)","url":"(.+?)"'
    match = re.compile(r,re.DOTALL).findall(data)
    for quality,stream in match:
        name.append(quality.title())
        

  
        test = str(l)
        test = test.replace('<Cookie ','')
        test = test.replace(' for .my.mail.ru/>','')
        url.append(stream +'|Cookie='+test)

    return url[xbmcgui.Dialog().select('Please Select Resolution', name)]

def getData(url,headers={}):
    net.save_cookies(cookie_jar)
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    data=response.read()
    response.close()
    return data
	
def ReplaysAddDir(name,url,mode,iconimage,page):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        if mode == 120:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def uniqueList(name):
    uniques = []
    for n in name:
        if n not in uniques:
            uniques.append(n)
    return uniques  

def replaceHTMLCodes(txt):
    import HTMLParser

    # Fix missing ; in &#<number>;
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", makeUTF8(txt))

    txt = HTMLParser.HTMLParser().unescape(txt)
    txt = txt.replace("&amp;", "&")
    return txt  

def makeUTF8(data):
    return data
    try:
        return data.decode('utf8', 'xmlcharrefreplace') # was 'ignore'
    except:
        s = u""
        for i in data:
            try:
                i.decode("utf8", "xmlcharrefreplace") 
            except:
                log("Can't convert character", 4)
                continue
            else:
                s += i
        return s  

def getStreamUrl(id):
    maxVideoQuality = "1080p"
    content = net.http_GET("http://www.dailymotion.com/embed/video/"+id).content

    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,Not Found (DailyMotion)!,5000)')
        return ""
    else:
        matchFullHD = re.compile('"stream_h264_hd1080_url":"(.+?)"', re.DOTALL).findall(content)
        matchHD = re.compile('"stream_h264_hd_url":"(.+?)"', re.DOTALL).findall(content)
        matchHQ = re.compile('"stream_h264_hq_url":"(.+?)"', re.DOTALL).findall(content)
        matchSD = re.compile('"stream_h264_url":"(.+?)"', re.DOTALL).findall(content)
        matchLD = re.compile('"stream_h264_ld_url":"(.+?)"', re.DOTALL).findall(content)
        url = ""
        if matchFullHD and maxVideoQuality == "1080p":
            url = urllib.unquote_plus(matchFullHD[0]).replace("\\", "")
        elif matchHD and (maxVideoQuality == "720p" or maxVideoQuality == "1080p"):
            url = urllib.unquote_plus(matchHD[0]).replace("\\", "")
        elif matchHQ:
            url = urllib.unquote_plus(matchHQ[0]).replace("\\", "")
        elif matchSD:
            url = urllib.unquote_plus(matchSD[0]).replace("\\", "")
        elif matchLD:
            url = urllib.unquote_plus(matchLD[0]).replace("\\", "")
        return url

def search_music_videos():
    keyb = xbmc.Keyboard('', 'MaaaDstream Search Songs or Artist')
    keyb.doModal()
    if (keyb.isConfirmed()):
        AddFacebookLink()
        search = keyb.getText()
        encode=urllib.quote(search)
        url = 'http://imvdb.com/search?search_term=%s' % encode
        link = net.http_GET(url).content
        link = link.encode('ascii', 'ignore').decode('ascii')
        result = regex_from_to(link, '<h4>Videos</h4>', '</table>')
        match = re.compile('<tr><td width="50"><a href="(.+?)"><img class="searchImg" src="(.+?)" /></td><td><a href="(.+?)"><h5>(.+?)</h5><p style="margin-bottom(.+?)">(.+?)</p></a></td></tr>').findall(result)
        for vurl,iconimage,vurl1,song,d1,artist in match:
            title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
            MusicAddDirVideo(title,vurl,110,iconimage,song,artist,'','','')

	xbmc.executebuiltin("Container.SetViewMode(500)")

def Music_video_list(name,url):
    
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    if 'http://imvdb.com/genre' in url:
        all_videos = regex_get_all(link, '<div class="slideNode', 'p class="node_info')
        for a in all_videos:
            if not 'Not Available Online' in a:
                vurl = regex_from_to(a, '<a href="', '"')
                iconimage = regex_from_to(a, '<img class="rack_img" src="', '"').replace('tv.jpg', 'bv.jpg')
                songinfo = regex_from_to(a, '<h3>', '</h3>')
                song = regex_from_to(songinfo, '">', '<').rstrip()
                artistinfo = regex_from_to(a, '<h4>', '</h4>')
                artist = regex_from_to(artistinfo, '">', '<')
                artisturl = regex_from_to(artistinfo, 'href="', '"')
                title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
                MusicAddDirVideo(title,vurl,110,iconimage,song,artist,artisturl,'','')
    else:
        all_videos = regex_get_all(link, '<div class="rack_node', '</div>')
        for a in all_videos:
            if not 'Not Available Online' in a:
                vurl = regex_from_to(a, '<a href="', '"')
                iconimage = regex_from_to(a, '<img class="rack_img" src="', '"').replace('tv.jpg', 'bv.jpg')
                song = regex_from_to(a, 'title="', '">').rstrip()
                artistinfo = regex_from_to(a, '<h4>', '</h4>')
                artist = regex_from_to(artistinfo, '">', '<')
                artisturl = regex_from_to(artistinfo, 'href="', '"')
                title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
                MusicAddDirVideo(title,vurl,110,iconimage,song,artist,artisturl,'','')
       
    xbmc.executebuiltin("Container.SetViewMode(500)")

def video_artists(name,url):
    alphabet =  ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U','V', 'W', 'X', 'Y', 'Z']
    for a in alphabet:
        MusicAddDir(a,url+a.lower(),106,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+a.upper()+"-black.ico",'1')
    
    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def Get_video_artists_AZ(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
	
    AddFacebookLink()
	
    all_artists = regex_from_to(link, 'ul class="nameList">', '<div id="footer">')
    match = re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(all_artists)
    for url, title in match:
        MusicAddDir(title,url,107,'','n')
		
    xbmc.executebuiltin("Container.SetViewMode(50)")	

def Music_artist_videos(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    try:
        artistlst = regex_from_to(link, '<div id="artist-credits"', '</tbody>')
    except:
        try:
            artistlst = regex_from_to(link, '<div id="director-credits"', '</tbody>')
        except:
            artistlst = regex_from_to(link, '<div id="animator-credits"', '</tbody>')
    all_videos = regex_get_all(artistlst, '<tr', '<span><em>Director')
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="', '"')
        iconimage = regex_from_to(a, 'data-src="', '"').replace('tv.jpg', 'bv.jpg')
        songinfo = regex_from_to(a, '<td width="40%"><strong>', 'a>')
        song = regex_from_to(songinfo, '">', '<').rstrip()
        artist = name
        artisturl = url
        title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
        MusicAddDirVideo(title,vurl,110,iconimage,song,artist,artisturl,'','videoartist')	

    xbmc.executebuiltin("Container.SetViewMode(500)")
		
def Music_video_genres(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    all_genres = regex_get_all(link, '<div class="glassBox">', '</div>')
    loadedLinks = 0
    dialogWait = xbmcgui.DialogProgress()
	
    ret = dialogWait.create('Please wait until list is cached.')
    remaining_display = 'loaded :: [B]'+str(loadedLinks)+'[/B]'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
	
    AddFacebookLink()
    for a in all_genres:
        url = regex_from_to(a, 'href="', '"')
        title = regex_from_to(a, '</i>', '<').lstrip()
        iconimage = regex_from_to(a, 'image: url', '"').replace('(','').replace(')','')
        
        loadedLinks = loadedLinks + 1
        remaining_display = 'loaded :: [B]'+str(loadedLinks)+' : '+str(title)+'[/B].'
        dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
        MusicAddDir(title,url,102,iconimage,'1')
        if dialogWait.iscanceled(): return False 
		
    dialogWait.close()
    del dialogWait
 
    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def Music_Charts_New(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    AddFacebookLink()
    all_genres = regex_get_all(link, '<td style="width: 50px">', '</td>')
    Position = 0
    for a in all_genres:
        url = regex_from_to(a, 'href="', '"')
        iconimage = regex_from_to(a, 'img src="', '"')
        title = regex_from_to(a, 'alt="', '"').lstrip()
        Position = Position + 1
        title = str(Position) + ' ' + title
#        xbmcgui.Dialog().ok(str(title), url)
        MusicAddDirVideo(title,url,110,iconimage,'','','','','')
		
	xbmc.executebuiltin("Container.SetViewMode(500)")
		
def MusicAddDir(name,url,mode,iconimage,artist):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&artist="+urllib.quote_plus(artist)
        ok=True
        type1=artist
        artist = artist.replace('qq','')
        suffix = ""
        if artist == "artists":
            list = "%s<>%s" % (str(name),url)
        else:
            if 'qq' in type1:
                spltype1 = type1.split('qq')
                list = "%s<>%s<>%s<>%s" % (str(name).lower(),url,str(iconimage),spltype1[0])
            else:
                list = "%s<>%s<>%s" % (str(name).lower(),url,str(iconimage))
        list = list.replace(',', '')
        
        contextMenuItems = []
        if artist == "videoartist":
            if find_list(list, FAV_VIDEOARTIST) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1327&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1328&iconimage=%s)'%(sys.argv[0], name, urllib.quote(url), urllib.quote(iconimage))))
        if artist == "artists":
            if find_list(list, FAV_ARTIST) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=61&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=62&iconimage=%s)'%(sys.argv[0], name, urllib.quote(url), urllib.quote(iconimage))))
        if len(artist)>2 and artist != "videoartist" and 'itemvn' not in url:
            download_album = '%s?name=%s&url=%s&iconimage=%s&artist=%s&mode=202' % (sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(artist))  
            contextMenuItems.append(('[COLOR cyan]Download Album[/COLOR]', 'XBMC.RunPlugin(%s)' % download_album))
            if QUEUE_ALBUMS:
                play_music = '%s?name=%s&url=%s&iconimage=%s&mode=7' % (sys.argv[0], urllib.quote(name), url, iconimage)  
                contextMenuItems.append(('[COLOR cyan]Play/Browse Album[/COLOR]', 'XBMC.RunPlugin(%s)' % play_music))
            else:
                queue_music = '%s?name=%s&url=%s&iconimage=%s&mode=6&artist=%s' % (sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage), urllib.quote(artist))  
                contextMenuItems.append(('[COLOR cyan]Queue[/COLOR]', 'XBMC.RunPlugin(%s)' % queue_music))
            if not 'qq' in type1:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Albums[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=64&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Albums[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=65&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(artist), urllib.quote(iconimage))))
        liz=xbmcgui.ListItem(name + suffix, iconImage="DefaultAudio.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def MusicAddDirVideo(name,url,mode,iconimage,songname,artist,album,dur,type):
        suffix = ""
        if 'qq' in dur:
            list = "%s<>%s<>%s<>%s<>%s<>%s" % (str(artist),str(album),str(songname).lower(),url,str(iconimage),str(dur).replace('qq',''))
        else:
            list = "%s<>%s<>%s<>%s<>%s" % (str(artist),str(album),str(songname).lower(),url,str(iconimage))
        list = list.replace(',', '')
        artistsong = "%s - %s" % (artist,songname)
        contextMenuItems = []
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&songname="+urllib.quote_plus(songname)+"&artist="+urllib.quote_plus(artist)+"&album="+urllib.quote_plus(album)+"&dur="+str(dur)+"&type="+str(type)
        ok=True
        if type != 'favvid':
            suffix = ""
            contextMenuItems.append(("[COLOR lime]Add to Favourite Videos[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1323&iconimage=%s)'%(sys.argv[0], urllib.quote(artistsong), urllib.quote(url), urllib.quote(iconimage))))
        else:
            suffix = ' [COLOR lime]+[/COLOR]'
            contextMenuItems.append(("[COLOR orange]Remove from Favourite Videos[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1324&iconimage=%s)'%(sys.argv[0], urllib.quote(artistsong), urllib.quote(url), urllib.quote(iconimage))))
        liz=xbmcgui.ListItem(name + suffix, iconImage="DefaultAudio.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
 
def Music_play_video(name,url,iconimage):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    videoid = regex_from_to(link, 'FI.video_source_id = "', '"')
    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + videoid
    listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage, path=url)
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    handle = str(sys.argv[1])    
    if handle != "-1":
        listitem.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    else:
        xbmcPlayer.play(url, listitem)

def SEARCHTV(url):
        EnableMeta = metaset
        keyb = xbmc.Keyboard('', 'MaaaDstream Search TV Shows')
        keyb.doModal()
        if (keyb.isConfirmed()):
                AddFacebookLink()
                search = keyb.getText()
                encode=urllib.quote(search)
                print encode
                url = custurltv+'search.php?key='+encode
                print url
                links = net.http_GET(url).content
                links = regex_from_to(links, '<div class="found">', '</div>')
                links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
                
#				match=re.compile('<a href="(.+?)" target="_blank">(.+?)</a>   </li>',re.DOTALL).findall(links) 

                all_genres = regex_get_all(links, '<ul><li>', '</li></ul>')
                for a in all_genres:
                        url = regex_from_to(a, '<a href="', '"')
                        name = regex_from_to(a, '">', '<').lstrip()
                        name = CLEAN(name)
                        AddDir(name,custurltv+url,80,'')

	
def LATESTADDED(url):
        links = net.http_GET(url).content
        links = links.encode('ascii', 'ignore').decode('ascii')
        links = regex_from_to(links, '<div class="home">', '</div>')
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        AddFacebookLink()
		
        match=re.compile('<li><a href="/(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(links))
        for url,name in match:
                name = CLEAN(name)
                searcher = url.replace('/','')
                AddDir(name,custurltv+url,80,'')
				
        xbmc.executebuiltin("Container.SetViewMode(50)") 
				
def NEWLINKS(url):
        EnableMeta = metaset
        links = net.http_GET(url).content
		
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        NotNeeded, SelectOut = links.split('<div class="leftpage_frame">')
        SelectOut , NotNeeded = SelectOut.split('<div class="foot"')
        AddFacebookLink()
		
        match=re.compile('<li><a href="/(.+?)" >(.+?)</a></li><li>',re.DOTALL).findall(str(SelectOut))
        for url,name in match:
                name = CLEAN(name)
                searcher = url.replace('/','')
                AddDir(name,custurltv+url,80,'')
				
        xbmc.executebuiltin("Container.SetViewMode(50)") 
		
def NEWEPISODESTV(url):
        links = net.http_GET(url).content 
        links = links.encode('ascii', 'ignore').decode('ascii')
        links = regex_from_to(links, '<div class="home">', '</div>')
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        AddFacebookLink()
      
        match=re.compile('<li><a href="/(.+?)">(.+?)</a></li>',re.DOTALL).findall(links)
        for url,name in match:
                name = CLEAN(name)
                url = url+'/'
                AddDir(name,custurltv+url,81,'')
	
        xbmc.executebuiltin("Container.SetViewMode(50)")
			 
def GETSEASONSTV(name,url):

        SeasonPage = net.http_GET(url).content
        SeasonPage = SeasonPage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, SelectOut = SeasonPage.split("IMDB</a><br/>")
        SelectOut , NotNeeded = SelectOut.split('class="foot"')
        match=re.compile("<a href='/(.+?)'><strong>Episode</strong> (.+?)</a>").findall(str(SelectOut))
        AddFacebookLink()
        for url,name in match:
             AddDir(name,custurltv+url,81,'')
	
        xbmc.executebuiltin("Container.SetViewMode(50)")

def GETTVSOURCES(name,url):
        SelectOut = net.http_GET(url).content
        SelectOut = SelectOut.encode('ascii', 'ignore').decode('ascii')
        SelectOut = regex_from_to(SelectOut, '<div id="linkname">', '</table>')
        SelectOut = SelectOut.replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        all_genres = regex_get_all(SelectOut, '<ul id="linkname_nav">', '</a></li>')

        AddFacebookLink()
        List=[]; ListU=[]; c=0
    	for a in all_genres:
                url = regex_from_to(a, 'http://', ';')
                Source = regex_from_to(a, ';">', '</a></li>').lstrip()
                c=c+1; List.append('Link MaaaDstream ['+str(c)+'] '+ Source); ListU.append(url)
        
        dialog=xbmcgui.Dialog()
        rNo=dialog.select('MaaaDstream Select A Source', List)
        if rNo>=0:
                rName=List[rNo]
                rURL=str("http://"+ListU[rNo])
                STREAMTV(name,rURL,'')
        else:
                pass
				
def STREAMTV(name,url3,thumb):
 #       xbmcgui.Dialog().ok(str(name), url3)
        url = url3
        try:
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
                addLinkMovies(name,streamlink,thumb)
        except:
                Notify('small','Sorry Link Removed:', 'Please try another one.',9000)

				
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("MaaaDstream","Downloading")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()

def GetBestMovieURL():
    
    try:
       custurl1 = str('https://movie25.unblocked.pw/')
       Test = net.http_GET(custurl1).content
    except:
       custurl1 = str('http://www.movie25.ag/')
       Test = net.http_GET(custurl1).content
 
    return custurl1


def TOP9(url):
         custurl1 = GetBestMovieURL()
         if len(custurl1) < 10:
            return
         AddFacebookLink()
         EnableMeta = metaset
         links = net.http_GET(custurl1+url).content
         NotNeeded, links = links.split('<div class="banner_body">')
         links , NotNeeded = links.split('<div class="main">')
         links=links.replace('\r','').replace('\"','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
         match=re.compile('<div class=pic_top_movie><a href=(.+?) title=(.+?)><img src=(.+?) alt=(.+?) width=90 height=130 /></a></div>',re.DOTALL).findall(links)
         for url,blank1,icon,name, in match:
                name = CLEAN(name)
                AddDir(name,custurl1+url,66,icon)

def INDEX(url):
        custurl1 = GetBestMovieURL()
        if len(custurl1) < 10:
            return
        links = net.http_GET(custurl1+url).content
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','').replace('"  target="_self" title="','" target="_self" title="')
		
        pages=re.compile('found(.+?)/(.+?)Page').findall(links)
        nextpage=re.compile('<font color=#FF3300>.+?</font><a href=(.+?)>.+?</a>').findall(links)
        links , NotNeeded = links.split('<div class="count_text">')
        match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_self" title="(.+?)"><img src="(.+?)" width="130" height="190" alt="',re.DOTALL).findall(links)

        
        AddFacebookLink()
        for current,last in pages:
                AddDir('[B][COLOR yellow]MaaaDstream MOVIES Page  %s  of  %s[/COLOR][/B]'%(current,last),custurl1+url,52,icon)


        for url,name,iconimage2 in match:
                name = CLEAN(name)
                AddDir(name,custurl1+url,66,iconimage2)

 
        if nextpage:
                print nextpage
                url = str(nextpage)
                print url
                url = url.replace('[u\'','')
                url = url.replace(']','')
                url = url.replace('\'','')
                print url
                AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url,52,"http://s5.postimg.org/rmlrly3jb/next.png")



def VIDEOLINKS(name,url,iconimage):
        custurl1 = GetBestMovieURL()
        if len(custurl1) < 10:
            return
        EnableMeta = metaset
        name2 = name
        links2 = net.http_GET(url).content
        links2 = links2.encode('ascii', 'ignore').decode('ascii')
        links2 = links2.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','')
				  
        match2=re.compile('<h1>Links - Quality(.+?)</h1>').findall(links2)
        match=re.compile('<li id="playing_button"><a href="(.+?)" target="_blank"><span').findall(links2)
        if match2:
                quality = str(match2).replace('[','').replace(']','').replace("'",'').replace(' ','').replace('u','')
        else:
                quality = 'Not Specified'
        List=[]; ListU=[]; c=0

        for url in match:
                url = url.replace(')','')
                c=c+1; List.append('Link MaaaDstream ['+str(c)+'] '); ListU.append(url)
        dialog=xbmcgui.Dialog()
        rNo=dialog.select('Go to facebook.com/xbmc4every1', List)
        if rNo>=0:
                rName=List[rNo]
                rURL=ListU[rNo]
                STREAM(name2,custurl1+rURL,iconimage)
        else:
                pass

def STREAM(name,url,thumb):
        url3 = ''
        name2 = name
        url2 = url
        link = net.http_GET(url).content
        link = link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('" value="Click Here to Download"','"  value="Click Here to Download"')
        match=re.compile('onclick="location.href=(.+?)"  value="Click Here to Download"').findall(link)

        if match:
            print match
            url3 = str(match)
            url3 = url3.replace('[u\'','')
            url3 = url3.replace(']','')
            url3 = url3.replace(' ','')
            url3 = url3.replace('\'','')
        else:
		    Notify('small','Problem with link:', 'Contact Facebook.com/xbmc4every1',9000)
                

        try:
                req = urllib2.Request(url3)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                url = url3				
                streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
                addLinkMovies(name2,streamlink,thumb)
        except:
                if len(url3) > 0:
				   Notify('small','Sorry Link Removed:', 'Please try another one.',9000)


def GETGENRES(url):
        GenresPage = net.http_GET(url).content
        GenresPage = GenresPage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, GenresPage = GenresPage.split('<div class="tv_letter_nav"><ul>')
        GenresPage , NotNeeded = GenresPage.split('<div class="tv_all">')
        GenresPage = GenresPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(GenresPage))
		
        AddFacebookLink()
        for url,name in match:
                name = CLEAN(name)
                AddDir(name,custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")

		
def ATOZ(url):
        AtoZPage = net.http_GET(url).content
        AtoZPage = AtoZPage.encode('ascii', 'ignore').decode('ascii') 
        print url
        AtoZPage = regex_from_to(AtoZPage, '<a href="/tv-listings/0-9">0-9</a>', '<div class="home">')
        AtoZPage = AtoZPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(AtoZPage))
		
        AddFacebookLink()
        AddDir("Number 0-9",custurltv+"tv-listings/0-9",83,icon)
        for url,name in match:
                name = CLEAN(name)
                AddDir(name,custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")
        xbmc.executebuiltin("Container.SetViewMode(500)")
		
def GETATOZLIST(name,url):
    ATOZLIST = net.http_GET(url).content
    ATOZLIST = ATOZLIST.encode('ascii', 'ignore').decode('ascii')
    ATOZLIST = regex_from_to(ATOZLIST, '<div class="home">', '</div>')
    ATOZLIST = ATOZLIST.replace('\"','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
    match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(ATOZLIST)
    dp = xbmcgui.DialogProgress()

    totalLinks = len(match)
    loadedLinks = 0
    dp.create('UPDATING MaaaDstream')
   
    AddFacebookLink()
    for url,name in match:
        AddDir(name,custurltv+url,84,icon)
        loadedLinks = loadedLinks + 1
        percent = (loadedLinks * 100)/totalLinks
        dp.update(percent)
    dp.update(100)
    dp.close()
    
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
	
    xbmc.executebuiltin("Container.SetViewMode(50)")
			 
def GETATOZSEASON(name,url):
    SeasonPage = net.http_GET(url).content
    SeasonPage = regex_from_to(SeasonPage, 'target="_blank">IMDB</a><br/>', '<div class="addthis">') 
    SeasonPage = SeasonPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
    match=re.compile("<h3><a href=/(.+?)>(.+?)</a></h3>",re.DOTALL).findall(str(SeasonPage))
    AddFacebookLink()
    for url,name in match:
        AddDir(name,custurltv+url,85,icon)
			 
def GETATOZEPISODE(name,url):
        EpisodePage = net.http_GET(url).content
        EpisodePage = EpisodePage.encode('ascii', 'ignore').decode('ascii')
        EpisodePage = regex_from_to(EpisodePage, 'target="_blank">IMDB</a><br/>', '<div class="addthis">') 
        EpisodePage = EpisodePage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        match=re.compile("<a href=/(.+?)><strong>(.+?)</strong>(.+?)</a></li><li>",re.DOTALL).findall(str(EpisodePage))
        AddFacebookLink()
        for url,Blank1,name in match:
             AddDir(name,custurltv+url,81,icon)
      
def addLinkMovies(name,url,iconimage):
        download_enabled = 'False'
        ok=True
        try: addon.resolve_url(streamlink)
        except: pass
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo('Video', infoLabels={ "Title": name } )
        contextMenuItems = []
        if download_enabled == 'true':
                contextMenuItems = []
                contextMenuItems.append(('Download', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)' % (sys.argv[0], name, urllib.quote_plus(url))))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)

        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok
		
def SEARCHMOVIES():
        custurl1 = GetBestMovieURL()
        if len(custurl1) < 10:
            return
        EnableMeta = metaset
        keyb = xbmc.Keyboard('', 'Search MaaaDstream Movies')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', '+')
                print encode
                url = custurl1+'search.php?key='+encode+'&submit='
                print url
                SelectOut = net.http_GET(url).content
                SelectOut = regex_from_to(SelectOut, '<h1>Search', '<div class="count">') 
				
                SelectOut=SelectOut.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
#				match=re.compile('<div class="movie_pic"><a href="(.+?)"  target="_self" title="(.+?)">    <img src="(.+?)" width="130" height="190" alt="(.+?)" >    </a>',re.DOTALL).findall(SelectOut)
                match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_self" title="(.+?)"><img src="(.+?)" width="130" height="190" alt="(.+?)"></a>',re.DOTALL).findall(SelectOut)
                AddFacebookLink()
                for url,name,iconimage2,iconimage3 in match:
                    name = CLEAN(name)
                    AddDir(name,custurl1+url,66,iconimage2)


							   
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
            smallicon= "http://s5.postimg.org/ycy0pxt9j/appmovies.jpg"
            xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","+smallicon+")")
     elif typeq == 'big':
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ')

def OPEN_MAGIC(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent' , "Magic Browser")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def CLEAN(name):
        name = name.replace('&amp;','&')
        name = name.replace('&#x27;',"'")
        urllib.quote(u'\xe9'.encode('UTF-8'))
        name = name.replace(u'\xe9','e')
        urllib.quote(u'\xfa'.encode('UTF-8'))
        name = name.replace(u'\xfa','u')
        urllib.quote(u'\xed'.encode('UTF-8'))
        name = name.replace(u'\xed','i')
        urllib.quote(u'\xe4'.encode('UTF-8'))
        name = name.replace(u'\xe4','a')
        urllib.quote(u'\xf4'.encode('UTF-8'))
        name = name.replace(u'\xf4','o')
        urllib.quote(u'\u2013'.encode('UTF-8'))
        name = name.replace(u'\u2013','-')
        urllib.quote(u'\xe0'.encode('UTF-8'))
        name = name.replace(u'\xe0','a')
        try: name=messupText(name,True,True)
        except: pass
        try:name = name.decode('UTF-8').encode('UTF-8','ignore')
        except: pass
        return name

def PLAYLINK(name,url,iconimage):
        link = common.OpenURL(url)
        match=re.compile('hashkey=(.+?)">').findall(link)
        if len(match) == 0:
                match=re.compile("hashkey=(.+?)'>").findall(link)
        if (len(match) > 0):
                hashurl="http://videomega.tv/validatehash.php?hashkey="+ match[0]
                req = urllib2.Request(hashurl,None)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0')
                req.add_header('Referer', url)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('var ref="(.+?)"').findall(link)[0]
                videomega_url = 'http://videomega.tv/?ref='+match 
        else:
                match=re.compile("javascript'\>ref='(.+?)'").findall(link)[0]
                videomega_url = "http://videomega.tv/?ref=" + match
                
##RESOLVE##     
        url = urlparse.urlparse(videomega_url).query
        url = urlparse.parse_qs(url)['ref'][0]
        url = 'http://videomega.tv/cdn.php?ref=%s' % url
        referer = videomega_url
        req = urllib2.Request(url,None)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()        
        stream_url = re.compile('<source src="(.+?)" type="video/mp4"/>').findall(link)[0]      
##RESOLVE##
        
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(stream_url,listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)


def PlxCategory(url):
	tmpList = []
	list = common.plx2list(url)
	background = list[0]["background"]
	for channel in list[1:]:
		iconimage = "" if not channel.has_key("thumb") else common.GetEncodeString(channel["thumb"])
		name = common.GetEncodeString(channel["name"])
		if channel["type"] == 'playlist':
			AddDir("[COLOR blue][{0}][/COLOR]".format(name) ,channel["url"], 1, iconimage, background=background)
		else:
			AddDir(name, channel["url"], 3, iconimage, isFolder=False, background=background)
			tmpList.append({"url": channel["url"], "image": iconimage, "name": name.decode("utf-8")})
			
	common.SaveList(tmpListFile, tmpList)
			
		
def AddDir(name, url, mode, iconimage, description='', isFolder=True, background=None):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)

    if background == None:
       background=iconimage
	
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
    liz.setProperty('fanart_image', background)
    if mode == 1 or mode == 2:
       liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
    elif mode == 3:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
    elif mode == 32:
        liz.setProperty('IsPlayable', 'true')
        liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
		
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text =  "" if not keyboard.isConfirmed() else keyboard.getText()
	return text

def GetSourceLocation(title, list):
	dialog = xbmcgui.Dialog()
	answer = dialog.select(title, list)
	return answer
	
def AddFavorites(url, iconimage, name):
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
			return
    
	list = common.ReadList(tmpListFile)	
	for channel in list:
		if channel["name"].lower() == name.lower():
			url = channel["url"]
			iconimage = channel["image"]
			break
			
	if not iconimage:
		iconimage = ""
		
	data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
	favList.append(data)
	common.SaveList(favoritesFile, favList)
	xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))

def Freeview_Groups():
#A Big thanks to Kinkin for his code to help me do this
    dp = xbmcgui.DialogProgress()
    dp.create('MaaaDstream Logging in to Server')
    Freeview_Get_Session()
    session_id = xbmcgui.Window(10000).getProperty("session_id")
    url = "%s%s%s" % (Freeview_url,'/tv/api/groups?session_key=', (session_id))
    link = Freeview_OPEN_URL(url)
    all_groups = regex_get_all(link, '{', '_count')
    for groups in all_groups:
        description=regex_from_to(groups,'channels":',',"channels').replace('[','').replace(']','').replace('"','')
        name = regex_from_to(groups, 'title":"', '",')
        iconimage = regex_from_to(groups, 'logo_148x148_uri":"', '",').replace('\\', '')
        url = regex_from_to(groups, 'group_id":"', '",')
        AddDir('[COLOR gold]'+name+'[/COLOR]',url, 310, iconimage, description, isFolder=True)
    
    dp.close()
    xbmc.executebuiltin("Container.SetViewMode(500)")			
	
	
def Freeview_List(name,url,description):
    channels = description
    title = ''
    name_lst = []
    session_id = xbmcgui.Window(10000).getProperty("session_id")
    url = "%s%s%s%s%s" % (Freeview_url, 'api/group/', url, '?session_key=', session_id)
    link = Freeview_GET_URL(url).translate(trans_table)
    link=cleanlink(link)

    data=json.loads(link)
    channels=data['channels']
    for c in channels:
        channel_id=c['id']
        title=c['title']
        description=c['description']
        name_lst.append(title)
#        title="%s (%s)" % (title,channel_id)
        icon = 'http://static.filmon.com/couch/channels/%s/extra_big_logo.png' % channel_id
        AddDir('[COLOR gold]'+title+'[/COLOR]',str(channel_id), 320, icon,isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def Freeview_Play(name,url,iconimage):
    ChannelName = name
    dp = xbmcgui.DialogProgress()
    dp.create('Opening ' + name.upper())
    session_id = xbmcgui.Window(10000).getProperty("session_id")
    url = "%s%s%s%s%s" % (Freeview_url, 'api/channel/', url, '?session_key=', session_id)
    utc_now = datetime.datetime.now()
    channel_name=name.upper()
    try:
        link = Freeview_OPEN_URL(url)
    except:
        return
    p_name = name
    n_p_name = ""


    Method = 1
    streams = re.compile('"id":(.+?),"quality":"high","url":"(.+?)","name":"(.+?)","is_adaptive":"(.+?)","watch-timeout":(.+?)}').findall(link)
    if len(streams) < 1:
       streams = re.compile('"id":(.+?),"quality":"low","url":"(.+?)","name":"(.+?)","is_adaptive":"(.+?)","watch-timeout":(.+?)}').findall(link)
    
    if len(streams) < 1:
       Method = 2
       streams = re.compile('"id":(.+?),"quality":"high","url":"(.+?)""name":"(.+?)","is_adaptive":(.+?),"watch-timeout":"(.+?)"}').findall(link)
    if len(streams) < 1:
       Method = 2
       streams = re.compile('"id":(.+?),"quality":"low","url":"(.+?)","name":"(.+?)","is_adaptive":(.+?),"watch-timeout":(.+?)}').findall(link)
	   
    if len(streams) < 1:
	   return
    app = ''

    if Method == 1:
        for id,url,name,adaptive,wt in streams:
            url = url.replace("\/", "/")
            name = name
            id=id
            if name.endswith('m4v'):
                app = 'vodlast'
            else:
                app='live/?id=' + url.split('=')[1]
        swapout_url = regex_from_to(url,'rtmp://','/')
        STurl = str(url) + ' playpath=' + name + ' app=' + app + ' swfUrl=http://www.filmon.com/tv/modules/FilmOnTV/files/flashapp/filmon/FilmonPlayer.swf' + ' tcUrl=' + url + ' pageUrl=http://www.filmon.com/' + ' live=1 timeout=45 swfVfy=1'
    else:
        for id,url,name,adaptive,wt in streams:
            url = url.replace("\/", "/")
        swapout_url = regex_from_to(url,'rtmp://','/')
        STurl = str(url) + '/' + str(name)
    dp.update(75)	
    playlist = xbmc.PlayList(1)
    playlist.clear()
    listitem = xbmcgui.ListItem(ChannelName, iconImage=iconimage, thumbnailImage=iconimage)
    listitem.setInfo("Video", {"Title":ChannelName})
    listitem.setProperty('mimetype', 'video/x-msvideo')
    listitem.setProperty('IsPlayable', 'true')
    playlist.add(STurl,listitem)
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    xbmcPlayer.play(playlist)
		
    dp.close()
	
	
def Freeview_OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def Freeview_GET_URL(url):
    header_dict = {}
    header_dict['Accept'] = 'application/json, text/javascript, */*; q=0.01'
    header_dict['User-Agent'] = 'User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    req = net.http_GET(url, headers=header_dict).content
    return req
	
def Freeview_Get_Session():
    try:
        session_id = xbmcgui.Window(10000).getProperty("session_id")
        url = "%s%s%s" % (Freeview_url,'/tv/api/groups?session_key=',(session_id))
        link = Freeview_OPEN_URL(url)
    except:
        xbmcgui.Window(10000).setProperty("session_id", '')
    if not xbmcgui.Window(10000).getProperty("session_id"):
        link = Freeview_OPEN_URL(session_url)
        match= re.compile('"session_key":"(.+?)"').findall(link)
        session_id=match[0]
        print "FilmOn.TV......Not logged in"
        xbmcgui.Window(10000).setProperty("session_id", session_id)
        Freeview_keep_session()
            
#    FILMON_SESSION = xbmcgui.Window(10000).getProperty("session_id")

def Freeview_keep_session():
    currentWindow = xbmcgui.getCurrentWindowId()
    session_id = xbmcgui.Window(10000).getProperty("session_id")
    url = "http://www.filmon.com/api/keep-alive?session_key=%s" % (session_id)
    Freeview_GET_URL(url)
    tloop = Timer(60.0, Freeview_keep_session)
    tloop.start()

def cleanlink(link):
    data=link.replace('\u00a0',' ').replace('\u00ae','').replace('\u00e9','').replace('\u00e0','').replace('\u2013','').replace('\u00e7','').replace('\u00f1','')
    return data
	
#def UpdateMe():
    #dp = xbmcgui.DialogProgress()
    #dp.create('UPDATING MaaaDstreamSTREAM')
    #dp.update(10)
    #url = "http://kodi.xyz/updateaaa.php"
    #localfile = os.path.join(addonDir,"default.py")
    #urllib.urlretrieve(url,localfile)
    #url = "http://kodi.xyz/updateaddon.php"
    #localfile = os.path.join(addonDir,"addon.xml")
    #urllib.urlretrieve(url,localfile)
    #dp.update(30)	
	
    #url = "http://kodi.xyz/updatecommon.php"
    #localfile = os.path.join(libDir,"common.py")
    #urllib.urlretrieve(url,localfile)
    #url = "http://kodi.xyz/updatedecrypter.php"
    #localfile = os.path.join(libDir,"decrypter.py")
    #urllib.urlretrieve(url,localfile)
    #localfile = os.path.join(libDir,"commonresolvers.py")
	
    #dp.update(50)	
    #url = "http://kodi.xyz/updateresolvers.php"
    #urllib.urlretrieve(url,localfile)
    #localfile = os.path.join(libDir,"repobuild.py")
    #url = "http://pastebin.com/raw.php?i=hsncpqPD"
    #urllib.urlretrieve(url,localfile)
    
    #dp.update(75)	
    #import repobuild
    #repobuild.UpdateRepo()
	
    #dp.update(90)	
    #xbmc.executebuiltin("UpdateLocalAddons")
    #xbmc.executebuiltin("UpdateAddonRepos")
	
    #dp.update(100)
    #dp.close()
	
    #xbmcgui.Dialog().ok('MaaaDstream', 'Updated. A reboot of Kodi/XBMC may be required', '   ', 'Donation website: ')

def RemoveFavorties(url):
	list = common.ReadList(favoritesFile) 
	for channel in list:
		if channel["url"].lower() == url.lower():
			list.remove(channel)
			break
			
	common.SaveList(favoritesFile, list)
	xbmc.executebuiltin("XBMC.Container.Refresh()")

def YouTubeCode(url):
    try:
        url = "PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid="+url+")"
        xbmc.executebuiltin(url)
    except:
        xbmc.executebuiltin("XBMC.Notification(MaaaDstream ,This host is not supported or resolver is broken::,10000)")

def m3uCategory(url):
    url = Raw + url
    list = common.m3u2list(url)
    AddFacebookLink()
    for channel in list:
		name = common.GetEncodeString(channel["display_name"])
		mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3
		AddDir(name ,channel["url"], mode, icon, isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(50)")

def Newsletter(url):
    list = common.m3u2list(ChinaServer+url)
    AddFacebookLink()
    for channel in list:
		name = common.GetEncodeString(channel["display_name"])
		mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3
		AddDir(name ,channel["url"], mode, "http://s5.postimg.org/mmv5t2nhj/newsletter.png", isFolder=False)

    xbmc.executebuiltin("Container.SetViewMode(50)")
	
def ListFavorites():
    AddDir('[B][COLOR yellow]YOUR FAVOURITES LIST[/COLOR][/B]','BLANK',999,"http://s5.postimg.org/60906955z/favorite.png")	
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
    list = common.ReadList(favoritesFile)
    for channel in list:
		name = channel["name"].encode("utf-8")
		iconimage = channel["image"].encode("utf-8")
		AddDir(name, channel["url"], 32, iconimage, isFolder=False) 

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)

    xbmc.executebuiltin("Container.SetViewMode(true)")		
						
def AddNewFavortie():
	chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
	if len(chName) < 1:
		return
	chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
	if len(chUrl) < 1:
		return
		
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
			return
			
	data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
	
	favList.append(data)
	if common.SaveList(favoritesFile, favList):
		xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))

def PlayUrl(name, url, iconimage=None):
	print '--- Playing "{0}". {1}'.format(name, url)
	listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
	listitem.setInfo(type="Video", infoLabels={ "Title": name })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
def PlayURLResolver(name,url,iconimage):
    import commonresolvers
    resolved = commonresolvers.get(url).result
    if resolved:
        if isinstance(resolved,list):
            for k in resolved:
                quality = 'HD'
                if k['quality'] == 'HD'  :
                    resolver = k['url']
                    break
                elif k['quality'] == 'SD' :
                    resolver = k['url']        
                elif k['quality'] == '1080p' and addon.getSetting('1080pquality') == 'true' :
                    resolver = k['url']
                    break
        else:
            resolver = resolved        
        playsetresolved(resolver,name,iconimage)
    else: 
        xbmc.executebuiltin("XBMC.Notification(MaaaDstream,This host is not supported or resolver is broken::,10000)")  

def playsetresolved(url,name,iconimage):
    liz = xbmcgui.ListItem(name, iconImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':name})
    liz.setProperty("IsPlayable","true")
    	
    liz.setPath(url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	
def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
	   try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
	   except: r = ''
    else:
       try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
       except: r = ''
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
	
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0].lower()] = splitparams[1]
	return param

	
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
channels=None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
try:        
	mode = int(params["mode"])
except:
	pass
try:        
	description = urllib.unquote_plus(params["description"])
except:
	pass

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: channels=urllib.unquote_plus(params["channels"])
except: pass

	
if mode == None or url == None or len(url) < 1:
	Categories()
elif mode == 1:
	PlxCategory(url)
elif mode == 2:
    XMLRead500(url)
#	m3uCategory(url)
elif mode == 3 or mode == 32:
     PlayURLResolver(name,url,iconimage)
elif mode == 4:
    Newsletter(url)
elif mode == 6:	
	StreamsList(url)
elif mode == 7:	
	LockedIndex(url)
elif mode == 9:
	UFCSection(url)
elif mode == 11:
	YouTube_List(url)
elif mode == 12:
    PlayURLResolver(name,url,iconimage)
elif mode == 14:
    PlayUrl(name, url, iconimage)
elif mode == 15:
	UFCScrape(url)
elif mode == 16:
	StreamUFC(name,url,iconimage)
elif mode == 20:
	XMLRead500(url)
elif mode == 30:
	ListFavorites()
elif mode == 31: 
	AddFavorites(url, iconimage, name) 
elif mode == 33:
	RemoveFavorties(url)
elif mode == 34:
	AddNewFavortie()
elif mode == 35:
    x1Channels(url)
elif mode == 37:	
    Stream247(url)
elif mode == 38:	
    Stream247_Links(name,url,iconimage)
elif mode == 41:
	common.DelFile(favoritesFile)
elif mode == 45:	
	TV()
#elif mode == 50:
    #UpdateMe()
    #sys.exit()

elif mode == 51:	
	TOP9(url)
elif mode == 52:	
	INDEX(url)
elif mode == 60 or mode == 46:	
    PlayYoutubeView(url)
elif mode == 61:
    PlayVimeo(url)
elif mode == 66 and LibCommon == 20:	
	VIDEOLINKS(name,url,iconimage)
elif mode == 75 and LibCommon == 20:	
	LATESTADDED(url)
elif mode == 76 and LibCommon == 20:	
	NEWLINKS(url)
elif mode == 77 and LibCommon == 20:	
	NEWEPISODESTV(url)
elif mode == 78 and LibCommon == 20:	
	SEARCHTV(url)
elif mode == 79 and LibCommon == 20:	
	SEARCHMOVIES()
elif mode == 80 and LibCommon == 20:	
	GETSEASONSTV(name,url)
elif mode == 81 and LibCommon == 20:	
	GETTVSOURCES(name,url)
elif mode == 82 and LibCommon == 20:	
	ATOZ(url)
elif mode == 83 and LibCommon == 20:
	GETATOZLIST(name,url)
elif mode == 84 and LibCommon == 20:	
	GETATOZSEASON(name,url)
elif mode == 85 and LibCommon == 20:
	GETATOZEPISODE(name,url)
elif mode == 86 and LibCommon == 20:
	GETGENRES(url)
elif mode == 90 and LibCommon == 20:
	(name,url)
elif mode == 98 and LibCommon == 20:
    sys.exit()
elif mode == 99 and LibCommon == 20:
	Categories()
elif mode == 100 and LibCommon == 20:	
	PLAYLINK(name,url,iconimage)
elif mode == 101 and LibCommon == 20:
    MusicVideos(url)
elif mode == 102 and LibCommon == 20:
	Music_video_list(name,url)
elif mode == 103 and LibCommon == 20:	
	Music_video_genres(name,url)
elif mode == 104 and LibCommon == 20:
	Music_Charts_New(name,url)
elif mode == 105 and LibCommon == 20:
	video_artists(name,url)
elif mode == 106 and LibCommon == 20:
	Get_video_artists_AZ(name,url)
elif mode == 107 and LibCommon == 20:
	Music_artist_videos(name,url)
elif mode == 108 and LibCommon == 20:
	search_music_videos()
elif mode == 110 and LibCommon == 20:
	Music_play_video(name,url,iconimage)

elif mode == 151 and LibCommon == 20:
	FullMatches(url)
elif mode == 152 and LibCommon == 20:
	REPLAYSGETLINKS(name,url)
elif mode == 153 and LibCommon == 20:
	NEXTPAGE(page)
elif mode == 154 and LibCommon == 20: 
	SearchReplays()
elif mode == 155 and LibCommon == 20: 
	Highlights()
elif mode == 156 and LibCommon == 20: 
	PlayHighlights(name,url)
elif mode == 120:
    PLAYSTREAM(name,url,iconimage)
elif mode == 200 and LibCommon == 20: 	
	YouTube_List(url)
elif mode == 210 and LibCommon == 20: 	
	YouTubeCode(url)
elif mode == 220 and LibCommon == 20:	
    Hybrid_List(url)
elif mode == 230 and LibCommon == 20:	
    VodlockerxScrape(url)
elif mode == 240 and LibCommon == 20:	
	VodlockerxSources(name,url,iconimage)
elif mode == 300:
    Freeview_Groups()
elif mode == 310:
    Freeview_List(name,url,description)
elif mode == 320:	
    Freeview_Play(name,url,iconimage)
elif mode == 400:	
	ChildLock()
elif mode == 500:
    EVO_Link()
elif mode == 510:
    EVO_Private()
elif mode == 520:
    StreamM3U(url)
elif mode == 530:
    IPTVHome()
elif mode == 540:
    IPTVList(url)
elif mode == 600:
    Xham_Cats(url)
elif mode == 610:	
	Xham_FindLinks(url)
elif mode == 700:
	TheBigList_category()
elif mode == 710:
	TheBigList_page(url)
elif mode == 720:
	TheBigList_lines(url,iconimage)
elif mode == 800:	
	Navi_Playlist(url)
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#       xbmcgui.Dialog().ok(str(name), url)
# h@k@M@c Code
