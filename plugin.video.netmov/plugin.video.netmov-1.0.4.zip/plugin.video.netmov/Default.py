import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
import urlresolver
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net


#NETMOV - By Mucky Duck (03/2015)

addon_id='plugin.video.netmov'
addon = Addon(addon_id, sys.argv)
baseurl1 = 'http://netmov.tv'
net = Net()

def NETMOV():
        addDir('Movies',baseurl1,21,'')
        addDir('TV Shows',baseurl1+'/TV.php',30,'')
        
#######################################################NETMOVMOVIES#########################################################
def NETMOVM(url):
        addDir('Random',baseurl1+'/Random.php',22,'')
        addDir('Top Rated',baseurl1+'/TopRated.php',22,'')
        addDir('Most Popular',baseurl1+'/MostPopular.php',22,'')
        addDir('Latest Updates',baseurl1,22,'')
        addDir('Latest Added',baseurl1+'/NewlyAdded.php',22,'')
        addDir('Featured',baseurl1+'/Featured.php',22,'')
        addDir('Genre',baseurl1+'/Channels.php',28,'')
        addDir('Movie SubGenres',baseurl1+'/Channels.php',39,'')
        addDir('Movie Categories',baseurl1+'/Channels.php',27,'')
        addDir('Movie Sequels and Remakes',baseurl1+'/Channels.php',29,'')
        addDir('Movies By Year',baseurl1+'/Channels.php',26,'')
        addDir('A/Z',baseurl1,25,'')
        
        
def NMMINDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<img src="(.+?)" title="(.+)" alt=".+?="smposter" align="left" /></a>\n<a href="(.+?)">.+?</a><br>\n<span class="highlight">(.+?)</span> <span class="rating">(.+?)</span><br>\n<span class="highlight">.+?</span>(.+?)<br>').findall(link)
        for thumbnail,name,url,rating,score,release in match:
                addDir('%s (%s %s -%s)' %(name,rating,score,release),baseurl1+url,23,thumbnail)
        else:
                match=re.compile('<a href="(.+?)"><small>(.+?)</small></a>').findall(link)
                for url, name in match:
                        addDir('[B][COLOR maroon]%s %s %s[/COLOR][/B]' %('Page',name,'>>>'),baseurl1+url,22,'')


def NMMINDEX2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<img src="(.+?)" title="(.+)" alt=".+?="smposter" align="left" /></a>\n<a href="(.+?)">.+?</a><br>\n<span class="highlight">(.+?)</span> <span class="rating">(.+?)</span><br>\n<span class="highlight">.+?</span>(.+?)<br>').findall(link)
        for thumbnail,name,url,rating,score,release in match:
                addDir('%s (%s %s -%s)' %(name,rating,score,release),baseurl1+url,23,thumbnail)
        else:
                match=re.compile('- <a href="(.+?)>(.+?)</a>').findall(link)
                for url, name in match:
                        addDir('[B][COLOR maroon]%s %s %s[/COLOR][/B]' %('Page',name,'>>>'),baseurl1+url,38,'')
                
                            

def NETMOVMHOSTS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<td width="80px" align="center">(.+?)</td>\n<td width="40px" align="center">.+?</td>\n<td width="30px" align="center">(.+?)</td>\n<td width="60px" align="center">(.+?)</td>\n<td width="100px" align="center"><a href="(.+?)"').findall(net.http_GET(url).content)
        for name,qual,lang,url in match:
                nono = ['YouTube']
                ok = '/source/'
                if name not in nono:
                        if ok in url:
                                addDir('%s (%s-%s)' %(name,qual,lang),baseurl1+url,24,'')
                        if ok not in url:
                                addDir('%s (%s-%s)' %(name,qual,lang),url,100,'')
                        
                                

def NETMOVMLINKS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('SRC="(.+?)" FRAMEBORDER=0').findall(net.http_GET(url).content)
        match1=re.compile('src="(.+?)" frameborder="0"').findall(net.http_GET(url).content)
        match2=re.compile('src="(.+?)" scrolling="no">').findall(net.http_GET(url).content)
        for url in match:
                RESOLVE(name,url)
        for url in match1:
                RESOLVE(name,url)
        for url in match2:
                RESOLVE(name,url)


def NETMOVMATOZ(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(link)
        for url,name in match:
                ok = ['#','A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
                if name in ok:
                        addDir(name,baseurl1+url,38,'')
               

def NETMOVMYEAR(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)">(.+?)</a>&nbsp').findall(link)
        for url,name in match:
                addDir(name,baseurl1+url,22,'')

def NETMOVMGENRE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<tr><td><a href="(.+?)">(.+?)</a></td></tr>').findall(link)
        for url,name in match:
                ok = ['Action Movies', 'Adventure Movies', 'Animation Movies', 'Comedy Movies', 'Crime Movies', 'Documentary Movies', 'Drama Movies', 'Family Movies','Fantasy Movies', 'History Movies', 'Horror Movies', 'Music Movies', 'Musical Movies', 'Mystery Movies', 'Romance Movies', 'Sci-Fi Movies', 'Short Movies', 'Sports Movies', 'Thriller Movies', 'War Movies', 'Western Movies']
                if name in ok:
                        addDir(name,baseurl1+url,38,'')

def NETMOVMSUB(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<tr><td><a href="(.+?)">(.+?)</a></td>').findall(link)
        for url,name in match:
                ok = '/subgenre/'
                if ok in url:
                        addDir(name,baseurl1+url,38,'')



def NETMOVMBSETS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<tr><td><a href="(.+?)">(.+?)</a></td></tr>').findall(link)
        for url,name in match:
                ok = ['Action Movies', 'Adventure Movies', 'Animation Movies', 'Comedy Movies', 'Crime Movies', 'Documentary Movies', 'Drama Movies', 'Family Movies','Fantasy Movies', 'History Movies', 'Horror Movies', 'Music Movies', 'Musical Movies', 'Mystery Movies', 'Romance Movies', 'Sci-Fi Movies', 'Short Movies', 'Sports Movies', 'Thriller Movies', 'War Movies', 'Western Movies']
                if name not in ok:
                        addDir(name,baseurl1+url,22,'')
        
       
def NETMOVMCAT(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<tr><td><a href="(.+?)">(.+?)</a>').findall(link)
        for url,name in match:
                ok = '/category/'
                if ok in url:
                        addDir(name,baseurl1+url,38,'')
                

                        
###################################################NETMOVTV#################################################################                

def NETMOVT(url):
        addDir('Latest Updates',baseurl1+'/TV.php',37,'')
        addDir('Featured',baseurl1+'/FeaturedShows.php',31,'')
        addDir('Most Popular',baseurl1+'/MostPopularShows.php',31,'')
        addDir('Newly Added',baseurl1+'/NewlyAddedShows.php',31,'')
        addDir('Genre',baseurl1+'/TVGenres.php',36,'')
        

def NMTINDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)"><img src="(.+?)" class="logosNoBorder" title="(.+?)" alt=".+?" align="left" /></a>').findall(link)
        for url,thumbnail,name in match:
                addDir(name,baseurl1+url,32,thumbnail)
        else:
                match=re.compile('<a href="(.+?)"><small>(.+?)</small></a>').findall(link)
                for url, name in match:
                        addDir('[B][COLOR maroon]%s %s %s[/COLOR][/B]' %('Page',name,'>>>'),baseurl1+url,31,'')

def NMTINDEX2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)"><img src="(.+?)" class="logosNoBorder" title="(.+?)" alt=".+?" align="left" /></a>').findall(link)
        for url,thumbnail,name in match:
                addDir(name,baseurl1+url,32,thumbnail)
        else:
                match=re.compile('- <a href="(.+?)>(.+?)</a>').findall(link)
                for url, name in match:
                        addDir('[B][COLOR maroon]%s %s %s[/COLOR][/B]' %('Page',name,'>>>'),baseurl1+url,37,'')

def NETMOVSEASONS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.+?)" title="(.+?)">.+?</a><br>').findall(link)
        for url,name in match:
                nono = 'Home'
                if nono not in url:
                        addDir(name,baseurl1+url,33,'')


def NETMOVEPISODES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<td class="borbot">(.+?)<a href="(.+?)">(.+?)</a> - <a href=".+?">(.+?)</a></td>\n<td class="borbot" align="right">(.+?)</td>').findall(link)
        for epi,url,epi1,name,aired in match:
                addDir(' %s: %s - %s(%s)' %(epi,epi1,name,aired),baseurl1+url,34,'')


def NETMOVTVHOSTS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('</td>\n<td class="highlight" width="120px">(.+?)</td> \n<td><a href="(.+)" target="_blank">').findall(net.http_GET(url).content)
        for name,url in match:
                ok = '/tv-source/'
                if ok in url:
                        addDir(name,baseurl1+url,35,'')
                if ok not in url:
                        addDir(name,url,100,'')

        
                              

def NETMOVTLINKS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('SRC="(.+?)" FRAMEBORDER=0').findall(net.http_GET(url).content)
        match1=re.compile('src="(.+?)" frameborder="0"').findall(net.http_GET(url).content)
        match2=re.compile('src="(.+?)" scrolling="no">').findall(net.http_GET(url).content)
        for url in match:
                RESOLVE(name,url)
        for url in match1:
                RESOLVE(name,url)
        for url in match2:
                RESOLVE(name,url)


def NETMOVTGENRE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<option value ="(.+?)">(.+?)</a></option>').findall(link)
        for url,name in match:
                ok = '/tv-genre/'
                if ok in url:
                        addDir(name,baseurl1+url,37,'')
                                
                                
                                

########################################################RESOLVE#############################################################       
def RESOLVE(name,url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
        print streamlink
        url = streamlink
        addLink(name,streamlink,'')
############################################################################################################################
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
########################################
if mode==None or url==None or len(url)<1:
        print ""
        NETMOV()
       
elif mode==21:
        print ""+url
        NETMOVM(url)
        
elif mode==22:
        print ""+url
        NMMINDEX(url)

elif mode==38:
        print ""+url
        NMMINDEX2(url)

elif mode==23:
        print ""+url
        NETMOVMHOSTS(url)

elif mode==24:
        print ""+url
        NETMOVMLINKS(url)

elif mode==25:
        print ""+url
        NETMOVMATOZ(url)

elif mode==26:
        print ""+url
        NETMOVMYEAR(url)

elif mode==27:
        print ""+url
        NETMOVMCAT(url)

elif mode==28:
        print ""+url
        NETMOVMGENRE(url)

elif mode==39:
        print ""+url
        NETMOVMSUB(url)

elif mode==29:
        print ""+url
        NETMOVMBSETS(url)

elif mode==30:
        print ""+url
        NETMOVT(url)

elif mode==31:
        print ""+url
        NMTINDEX(url)

elif mode==37:
        print ""+url
        NMTINDEX2(url)

elif mode==32:
        print ""+url
        NETMOVSEASONS(url)

elif mode==33:
        print ""+url
        NETMOVEPISODES(url)

elif mode==34:
        print ""+url
        NETMOVTVHOSTS(url)

elif mode==35:
        print ""+url
        NETMOVTLINKS(url)

elif mode==36:
        print ""+url
        NETMOVTGENRE(url)

#########################
elif mode==100:
        print ""+url
        RESOLVE(name,url)
#########################





xbmcplugin.endOfDirectory(int(sys.argv[1]))
